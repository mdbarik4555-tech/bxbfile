export type VisibilityMode = 'public' | 'unlisted' | 'private';
export type PublicationStatus = 'published' | 'draft' | 'suspended';
export type UserRole = 'user' | 'moderator' | 'admin' | 'owner';
export type FileAvailability = 'active' | 'maintenance' | 'deprecated' | 'restricted';

export type UploadLifecycleState = 
  | 'idle' 
  | 'validating' 
  | 'queued' 
  | 'uploading' 
  | 'finalizing' 
  | 'saving_metadata' 
  | 'ready' 
  | 'failed' 
  | 'cancelled' 
  | 'retrying';

export interface UserProfile {
  uid: string;
  username: string;
  usernameNormalized: string;
  displayName: string;
  avatarUrl?: string;
  bio?: string;
  createdAt: string;
  updatedAt: string;
  accountStatus: 'active' | 'suspended';
  profileVisibility: 'public' | 'private';
  role: UserRole;
  isOwner?: boolean;
  websiteUrl?: string;
  storageUsedBytes: number;
  filesCount: number;
}

export interface FileVersionHistory {
  version: string;
  releaseDate: string;
  releaseNotes: string;
  checksumSha256: string;
  downloadUrl: string;
  fileSize: number;
}

export interface FileItem {
  id: string;
  ownerUid: string;
  ownerUsername: string;
  ownerDisplayName: string;
  ownerAvatarUrl?: string;
  title: string;
  normalizedTitle: string;
  description: string;
  category: string;
  tags: string[];
  extension: string;
  contentType: string;
  fileSize: number;
  storagePath: string;
  downloadUrl: string;
  thumbnailUrl?: string;
  screenshotUrls?: string[];
  proofVideoUrl?: string;
  youtubeUrl?: string;
  version?: string;
  platform?: string;
  visibility: VisibilityMode;
  publicationStatus: PublicationStatus;
  availabilityStatus?: FileAvailability;
  createdAt: string;
  updatedAt: string;
  downloadStartCount: number;
  viewCount: number;
  checksumSha256?: string;
  moderationStatus: 'approved' | 'pending' | 'flagged' | 'restricted';
  instructions?: string;
  releaseNotes?: string;
  license?: string;
  creatorWebsite?: string;
  versionHistory?: FileVersionHistory[];

  // Paid Download System (Parts 11 & 12)
  isPaid?: boolean;
  price?: number; // In smallest currency unit or standard (e.g. ₹49)
  currency?: string; // 'INR', 'USD'
  salesCount?: number;
  folderId?: string;
  storageEngine?: 'firebase-cloud-storage' | 'bxb-server-storage' | 'bxb-12gb-chunk-engine';

  // Security, Password Gate, Countdown & Sharing Controls
  hasPassword?: boolean;
  countdownSeconds?: number | null; // 0 = disabled, 10, 15, 20, or custom duration, or null to inherit
  expiresAt?: string | null; // ISO string
  maxDownloads?: number | null;
  isRevoked?: boolean;
  redirectUrl?: string; // Protected destination or redirect link
  linkToken?: string;
  customLogoUrl?: string;
}

export interface FileMedia {
  id: string;
  fileId: string;
  ownerUid: string;
  mediaType: 'image' | 'video';
  storagePath: string;
  url: string;
  caption?: string;
  fileSize: number;
  createdAt: string;
}

export interface Report {
  id: string;
  reporterUid: string;
  reporterUsername?: string;
  targetFileId: string;
  targetFileTitle?: string;
  reason: string;
  description: string;
  details?: string;
  status: 'pending' | 'reviewed' | 'dismissed' | 'actioned';
  createdAt: string;
}

export interface DownloadEvent {
  id: string;
  fileId: string;
  ownerUid: string;
  timestamp: string;
}

export interface UploadProgressState {
  progress: number;
  bytesTransferred: number;
  totalBytes: number;
  status: UploadLifecycleState;
  error?: string;
  storageEngine?: 'firebase-cloud-storage' | 'bxb-server-storage' | 'bxb-12gb-chunk-engine';
  networkSpeedBps?: number;
  fileId?: string;
}

export interface UploadQueueItem {
  id: string;
  file: File;
  title: string;
  category: string;
  tags: string[];
  version: string;
  platform: string;
  visibility: VisibilityMode;
  isPaid?: boolean;
  price?: number;
  currency?: string;
  progress: number;
  bytesTransferred?: number;
  totalBytes?: number;
  status: UploadLifecycleState;
  error?: string;
  result?: FileItem;
  abortController?: AbortController;
}

// Daily Tokens (Part 7)
export interface TokenLedgerItem {
  id: string;
  userId: string;
  operationId: string;
  operationType: 'daily_allowance' | 'upload_charge' | 'apk_publish' | 'download_fee' | 'gift_award' | 'sandbox_preview' | 'admin_grant' | 'refund';
  amount: number; // Positive = credit, negative = debit
  balanceAfter: number;
  description: string;
  dateKey: string; // YYYY-MM-DD
  createdAt: string;
}

export interface UserDailyTokens {
  userId: string;
  dateKey: string;
  balance: number;
  allowance: number; // 1000 default
  unlimited: boolean; // For owners
  nextResetAt: string;
}

// Daily Uploads Quota (Part 8)
export interface DailyUploadQuota {
  userId: string;
  dateKey: string;
  uploadsCount: number;
  maxUploads: number; // 20 default
  unlimited: boolean; // For owners
  remaining: number;
  nextResetAt: string;
}

// Owner Configuration (Part 6)
export interface OwnerConfig {
  ownerEmail1: string;
  ownerEmail2: string;
  configured: boolean;
  source: 'env' | 'database' | 'default';
  updatedAt: string;
}

// Owner Notifications (Part 9)
export interface OwnerNotification {
  id: string;
  type: 'user_login' | 'payment_received' | 'abuse_report' | 'system_alert';
  title: string;
  message: string;
  timestamp: string;
  isRead: boolean;
  actorUid?: string;
  actorUsername?: string;
  actorEmail?: string;
  actorAvatarUrl?: string;
  metadata?: Record<string, any>;
}

// Invitations & Gifts (Part 10)
export interface InvitationCode {
  id: string;
  code: string;
  createdByUid: string;
  tokenAward: number;
  maxRedemptions: number;
  currentRedemptions: number;
  expiresAt: string;
  createdAt: string;
  isActive: boolean;
  notes?: string;
}

export interface GiftRedemption {
  id: string;
  code: string;
  redeemedByUid: string;
  username: string;
  tokenAward: number;
  redeemedAt: string;
}

export interface SystemAnnouncement {
  id: string;
  title: string;
  content: string;
  priority: 'low' | 'normal' | 'high' | 'urgent';
  active: boolean;
  createdAt: string;
  expiresAt?: string;
}

// Paid Downloads & Entitlements (Parts 11 & 12)
export interface PaymentOrder {
  orderId: string;
  fileId: string;
  fileTitle: string;
  buyerUid: string;
  buyerEmail?: string;
  amount: number; // In currency units e.g. 49
  currency: string; // 'INR', 'USD'
  status: 'created' | 'completed' | 'failed' | 'cancelled';
  createdAt: string;
}

export interface VerifiedPayment {
  paymentId: string;
  orderId: string;
  fileId: string;
  buyerUid: string;
  buyerEmail?: string;
  amount: number;
  currency: string;
  signature: string;
  verifiedAt: string;
  sellerUid: string;
}

export interface DownloadEntitlement {
  id: string; // `${buyerUid}_${fileId}`
  buyerUid: string;
  fileId: string;
  orderId: string;
  paymentId: string;
  grantedAt: string;
  expiresAt?: string;
}

// Folders & Organization (Section 10)
export interface FolderItem {
  id: string;
  ownerUid: string;
  name: string;
  parentFolderId?: string | null;
  color?: string;
  createdAt: string;
  updatedAt: string;
  fileCount?: number;
}

// Visit New Owner Section (Section 8)
export interface VisitNewUser {
  uid: string;
  username: string;
  displayName: string;
  email?: string;
  photoURL?: string;
  isFirstTime: boolean;
  firstLoginAt: string;
  lastLoginAt: string;
  loginCount: number;
  accountStatus: 'active' | 'suspended' | 'verified';
  filesCount: number;
  role: UserRole;
}

export interface OwnerDirectMessage {
  id: string;
  recipientUid: string;
  recipientEmail?: string;
  recipientUsername: string;
  senderEmail: string;
  messageType: 'text' | 'announcement' | 'support' | 'invitation' | 'gift';
  subject: string;
  content: string;
  giftCode?: string;
  tokenAward?: number;
  status: 'sent' | 'delivered' | 'read';
  createdAt: string;
  readAt?: string;
}

// Video Reels / Community Area (Section 12)
export interface ReelItem {
  id: string;
  creatorUid: string;
  creatorUsername: string;
  creatorDisplayName: string;
  creatorAvatar?: string;
  title: string;
  description: string;
  videoUrl: string;
  thumbnailUrl?: string;
  duration?: number;
  likesCount: number;
  commentsCount: number;
  proofBadge?: boolean;
  associatedFileId?: string;
  associatedFileTitle?: string;
  tags?: string[];
  createdAt: string;
  likedBy?: string[];
}

export interface ReelComment {
  id: string;
  reelId: string;
  authorUid: string;
  authorUsername: string;
  authorAvatar?: string;
  content: string;
  createdAt: string;
}

// Plugins & Tool Catalog (Section 17)
export interface ToolItem {
  id: string;
  name: string;
  category: 'analysis' | 'security' | 'media' | 'conversion' | 'diagnostics' | 'storage';
  description: string;
  version: string;
  requiredPermissions: string[];
  status: 'active' | 'configured' | 'setup_required';
  tags: string[];
  documentation: string;
}

// Large-File Chunk Upload Session (Sections 3 & 4)
export interface ChunkUploadSession {
  uploadId: string;
  fileId: string;
  fileName: string;
  fileSize: number;
  totalChunks: number;
  chunkSize: number;
  chunksReceived: number[];
  ownerUid: string;
  createdAt: string;
  status: 'in_progress' | 'completed' | 'failed' | 'aborted';
}

export const CATEGORIES = [
  { id: 'apk', name: 'Android APKs', icon: 'Smartphone', desc: 'Android packages & mobile apps' },
  { id: 'windows', name: 'Windows Apps', icon: 'Monitor', desc: 'Desktop software & utilities' },
  { id: 'web-apps', name: 'Web Applications', icon: 'Globe', desc: 'Frontend bundles & HTML5 tools' },
  { id: 'games', name: 'Games & Engines', icon: 'Gamepad2', desc: 'Indie titles, mods & game builds' },
  { id: 'ai-tools', name: 'AI & ML Tools', icon: 'Cpu', desc: 'Models, datasets & AI scripts' },
  { id: 'utilities', name: 'Utilities & CLI', icon: 'Wrench', desc: 'System tools, scripts & helpers' },
  { id: 'projects', name: 'Developer Projects', icon: 'Code', desc: 'Source archives, templates & boilerplates' },
  { id: 'documents', name: 'Documents & PDFs', icon: 'FileText', desc: 'Guides, whitepapers & documentation' },
  { id: 'media', name: 'Media Resources', icon: 'Film', desc: 'Audio stems, graphic assets & video footage' },
  { id: 'other', name: 'Other Files', icon: 'Package', desc: 'Archives, data blobs & miscellaneous' },
] as const;

export const SUPPORTED_EXTENSIONS = [
  'apk', 'zip', 'rar', '7z', 'tar', 'gz',
  'pdf', 'txt', 'json', 'xml', 'md', 'csv',
  'html', 'css', 'js', 'ts',
  'png', 'jpg', 'jpeg', 'webp', 'gif', 'svg',
  'mp4', 'webm', 'mp3', 'wav', 'ogg',
  'exe', 'msi', 'deb', 'dmg', 'iso'
];

// ==========================================
// SITE CONFIGURATION, BRANDING & LIVE EDITOR
// ==========================================
export interface BrandConfig {
  siteName: string;
  tagline: string;
  logoUrl: string;
  darkLogoUrl: string;
  faviconUrl: string;
  appIconUrl: string;
  primaryAccent: string;
  secondaryAccent: string;
}

export interface LiveEditorConfig {
  heroHeading: string;
  heroSubtitle: string;
  navLinks: Array<{ label: string; url: string; external?: boolean }>;
  footerText: string;
  announcementBanner: {
    active: boolean;
    title: string;
    text: string;
    type: 'info' | 'warning' | 'urgent';
    link?: string;
  };
  maintenanceMode: {
    enabled: boolean;
    message: string;
  };
  seoTitle: string;
  seoDescription: string;
}

export interface CountdownDefaultsConfig {
  enabled: boolean;
  defaultSeconds: number; // 0, 10, 15, 20, or custom duration
  policy: 'all' | 'selected'; // all downloads or selected files
  allowOverride: boolean;
}

export interface SharingDefaultsConfig {
  defaultVisibility: VisibilityMode;
  allowPassword: boolean;
  allowExpiring: boolean;
  allowDownloadLimits: boolean;
}

export interface AdSenseConfig {
  publisherId: string; // e.g. "ca-pub-1234567890123456"
  enabled: boolean;
  status: 'not_configured' | 'pending' | 'review' | 'active' | 'disabled';
  placements: {
    headerLeaderboard: boolean;
    downloadPageBanner: boolean;
    sidebarRectangle: boolean;
    reelsInFeed: boolean;
  };
  adsTxt: string;
  consentRequired: boolean;
}

export interface SiteConfig {
  brand: BrandConfig;
  liveEditor: LiveEditorConfig;
  countdownDefaults: CountdownDefaultsConfig;
  sharingDefaults: SharingDefaultsConfig;
  adsense: AdSenseConfig;
  updatedAt: string;
  updatedBy: string;
}

export interface RevisionRecord {
  id: string;
  timestamp: string;
  authorEmail: string;
  summary: string;
  snapshot: Partial<SiteConfig>;
}

export interface AuditLogRecord {
  id: string;
  timestamp: string;
  actorEmail: string;
  action: string;
  details: string;
}

export interface DiagnosticsData {
  timestamp: string;
  uptimeSeconds: number;
  nodeVersion: string;
  platform: string;
  memory: {
    rssMb: number;
    heapTotalMb: number;
    heapUsedMb: number;
  };
  storage: {
    uploadsBytes: number;
    chunksBytes: number;
    totalFilesCount: number;
    totalDownloads: number;
  };
  chunkSessions: number;
  uploadErrorsCount: number;
  downloadErrorsCount: number;
}

