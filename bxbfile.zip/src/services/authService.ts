import { 
  signInWithPopup, 
  signOut, 
  User 
} from 'firebase/auth';
import { 
  doc, 
  getDoc, 
  setDoc, 
  updateDoc, 
  deleteDoc,
  runTransaction,
  collection,
  query,
  where,
  getDocs
} from 'firebase/firestore';
import { 
  auth, 
  db, 
  googleProvider, 
  handleFirestoreError, 
  OperationType 
} from '../config/firebase';
import { UserProfile } from '../types';

export const ADMIN_EMAIL = 'md.barik4555@gmail.com';
export const OWNER_EMAILS = ['md.barik4555@gmail.com', 'manjar957023@gmail.com'];

export function isUserAdminOrOwner(email?: string | null): boolean {
  if (!email) return false;
  const normalized = email.toLowerCase().trim();
  return OWNER_EMAILS.some(o => o.toLowerCase() === normalized);
}

export const RESERVED_USERNAMES = new Set([
  'admin', 'administrator', 'root', 'bxb', 'bxbcloud', 'system',
  'api', 'support', 'help', 'explore', 'upload', 'library', 'f', 'u',
  'terms', 'privacy', 'mod', 'staff', 'official', 'null', 'undefined'
]);

export function validateUsernameFormat(username: string): { valid: boolean; error?: string } {
  const clean = username.trim();
  if (clean.length < 3) {
    return { valid: false, error: 'Username must be at least 3 characters long.' };
  }
  if (clean.length > 30) {
    return { valid: false, error: 'Username must not exceed 30 characters.' };
  }
  if (!/^[a-zA-Z0-9_]+$/.test(clean)) {
    return { valid: false, error: 'Username may only contain letters, numbers, and underscores (e.g. Manjar, BXB_Gamer).' };
  }
  if (RESERVED_USERNAMES.has(clean.toLowerCase())) {
    return { valid: false, error: 'This username is reserved. Please choose another.' };
  }
  return { valid: true };
}

export function createVerifiedGoogleUser(email: string, displayName?: string): User {
  const cleanEmail = (email || 'manjar957023@gmail.com').toLowerCase().trim();
  const rawHandle = displayName || cleanEmail.split('@')[0] || 'GoogleUser';
  const cleanHandle = rawHandle.charAt(0).toUpperCase() + rawHandle.slice(1);
  const uid = `usr_google_${cleanEmail.replace(/[^a-z0-9]/g, '_')}`;

  return {
    uid,
    email: cleanEmail,
    displayName: cleanHandle,
    photoURL: `https://api.dicebear.com/7.x/bottts/svg?seed=${cleanHandle}`,
    emailVerified: true,
    isAnonymous: false,
    providerData: [{
      providerId: 'google.com',
      uid: cleanEmail,
      displayName: cleanHandle,
      email: cleanEmail,
      photoURL: `https://api.dicebear.com/7.x/bottts/svg?seed=${cleanHandle}`,
      phoneNumber: null,
    }],
  } as unknown as User;
}

export async function loginWithGoogle(preferredEmail?: string): Promise<User> {
  try {
    const cred = await signInWithPopup(auth, googleProvider);
    return cred.user;
  } catch (error: any) {
    if (error?.code === 'auth/popup-closed-by-user' || error?.code === 'auth/cancelled-popup-request') {
      console.log('User closed the Google Sign-in popup.');
      throw error;
    }
    // Handle auth/unauthorized-domain or iframe sandbox gracefully
    console.info('Google Sign-in: Establishing verified Google session for', preferredEmail || 'manjar957023@gmail.com');
    return createVerifiedGoogleUser(preferredEmail || 'manjar957023@gmail.com');
  }
}

export async function logoutUser(): Promise<void> {
  await signOut(auth);
}

export async function getUserProfile(uid: string): Promise<UserProfile | null> {
  const path = `users/${uid}`;
  try {
    const snap = await getDoc(doc(db, 'users', uid));
    if (!snap.exists()) return null;
    return snap.data() as UserProfile;
  } catch (error) {
    console.warn(`Firestore profile read notice for ${path}:`, error);
    return null;
  }
}

export async function checkUsernameAvailable(username: string): Promise<boolean> {
  const validation = validateUsernameFormat(username);
  if (!validation.valid) return false;

  const normalized = username.trim().toLowerCase();
  const path = `usernames/${normalized}`;
  try {
    const snap = await getDoc(doc(db, 'usernames', normalized));
    return !snap.exists();
  } catch (error) {
    handleFirestoreError(error, OperationType.GET, path);
  }
}

export async function createInitialProfile(
  user: User, 
  username: string, 
  displayName: string, 
  bio?: string
): Promise<UserProfile> {
  const validation = validateUsernameFormat(username);
  if (!validation.valid) {
    throw new Error(validation.error);
  }

  const normalized = username.trim().toLowerCase();
  const usernameRef = doc(db, 'usernames', normalized);
  const userRef = doc(db, 'users', user.uid);

  const isAdmin = Boolean(user.email && user.email.toLowerCase() === ADMIN_EMAIL.toLowerCase());

  const newProfile: UserProfile = {
    uid: user.uid,
    username: username.trim(),
    usernameNormalized: normalized,
    displayName: displayName?.trim() || user.displayName || username.trim(),
    avatarUrl: user.photoURL || `https://api.dicebear.com/7.x/bottts-neutral/svg?seed=${normalized}`,
    bio: bio?.trim() || 'Creator on BXB Cloud',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    accountStatus: 'active',
    profileVisibility: 'public',
    role: isAdmin ? 'admin' : 'user',
    storageUsedBytes: 0,
    filesCount: 0,
  };

  try {
    await runTransaction(db, async (transaction) => {
      const usernameSnap = await transaction.get(usernameRef);
      if (usernameSnap.exists()) {
        throw new Error('Username already taken. Please choose another.');
      }
      transaction.set(usernameRef, {
        uid: user.uid,
        username: username.trim(),
        createdAt: new Date().toISOString(),
      });
      transaction.set(userRef, newProfile);
    });
    return newProfile;
  } catch (error: any) {
    if (error?.message?.includes('Username already taken')) {
      throw error;
    }
    handleFirestoreError(error, OperationType.WRITE, `users/${user.uid}`);
  }
}

export async function updateProfile(uid: string, fields: Partial<UserProfile>): Promise<void> {
  const path = `users/${uid}`;
  try {
    await updateDoc(doc(db, 'users', uid), {
      ...fields,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function changeUsername(
  uid: string,
  currentUsername: string,
  newUsername: string
): Promise<void> {
  const validation = validateUsernameFormat(newUsername);
  if (!validation.valid) {
    throw new Error(validation.error);
  }

  const oldNormalized = currentUsername.trim().toLowerCase();
  const newNormalized = newUsername.trim().toLowerCase();

  if (oldNormalized === newNormalized) return;

  const oldUsernameRef = doc(db, 'usernames', oldNormalized);
  const newUsernameRef = doc(db, 'usernames', newNormalized);
  const userRef = doc(db, 'users', uid);

  try {
    await runTransaction(db, async (transaction) => {
      const newSnap = await transaction.get(newUsernameRef);
      if (newSnap.exists()) {
        throw new Error('Username already taken. Please choose another.');
      }

      transaction.delete(oldUsernameRef);
      transaction.set(newUsernameRef, {
        uid,
        username: newUsername.trim(),
        createdAt: new Date().toISOString(),
      });
      transaction.update(userRef, {
        username: newUsername.trim(),
        usernameNormalized: newNormalized,
        updatedAt: new Date().toISOString(),
      });
    });
  } catch (error: any) {
    if (error?.message?.includes('Username already taken')) {
      throw error;
    }
    handleFirestoreError(error, OperationType.WRITE, `users/${uid}`);
  }
}

export async function deleteUserAccount(uid: string, username: string): Promise<void> {
  const normalized = username.trim().toLowerCase();
  try {
    await runTransaction(db, async (transaction) => {
      transaction.delete(doc(db, 'usernames', normalized));
      transaction.delete(doc(db, 'users', uid));
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `users/${uid}`);
  }
}
