/**
 * Minecraft Lab Validation Engine (Section 24 Specification)
 * Validates manifest.json, UUID compliance, modules, and archive security against path traversal.
 */

export interface ValidationError {
  file: string;
  line: number | null;
  message: string;
  severity: 'error' | 'warning' | 'info';
}

export class MinecraftValidator {
  /**
   * Validates Bedrock / Java pack manifest.json schema
   */
  static validateManifest(json: any): ValidationError[] {
    const errors: ValidationError[] = [];

    if (!json || typeof json !== 'object') {
      return [{ file: 'manifest.json', line: 1, message: 'Invalid or empty JSON document', severity: 'error' }];
    }

    if (!json.format_version) {
      errors.push({ file: 'manifest.json', line: null, message: 'format_version missing', severity: 'error' });
    }

    if (!json.header) {
      errors.push({ file: 'manifest.json', line: null, message: 'header section missing', severity: 'error' });
    } else {
      if (!json.header.name) {
        errors.push({ file: 'manifest.json', line: null, message: 'header.name missing', severity: 'error' });
      }
      if (!json.header.uuid) {
        errors.push({ file: 'manifest.json', line: null, message: 'header.uuid missing', severity: 'error' });
      } else if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test(json.header.uuid)) {
        errors.push({ file: 'manifest.json', line: null, message: 'header.uuid format invalid (Must be RFC 4122 UUID)', severity: 'error' });
      }
      if (!Array.isArray(json.header.version) || json.header.version.length < 3) {
        errors.push({ file: 'manifest.json', line: null, message: 'header.version must be [major, minor, patch] array', severity: 'error' });
      }
    }

    if (!json.modules || !Array.isArray(json.modules) || json.modules.length === 0) {
      errors.push({ file: 'manifest.json', line: null, message: 'modules array missing or empty', severity: 'error' });
    } else {
      for (let i = 0; i < json.modules.length; i++) {
        const mod = json.modules[i];
        if (!mod.type) {
          errors.push({ file: 'manifest.json', line: null, message: `Module [${i}] type missing`, severity: 'error' });
        } else if (!['resources', 'data', 'client_data', 'script', 'world_template'].includes(mod.type)) {
          errors.push({ file: 'manifest.json', line: null, message: `Unknown module type: "${mod.type}"`, severity: 'warning' });
        }
        if (!mod.uuid) {
          errors.push({ file: 'manifest.json', line: null, message: `Module [${i}] uuid missing`, severity: 'error' });
        }
      }
    }

    return errors;
  }

  /**
   * Validates zip archive entries against directory traversal and oversized packages
   */
  static validateZipStructure(entries: { name: string; size: number }[]): ValidationError[] {
    const errors: ValidationError[] = [];

    const hasManifest = entries.some(e => e.name.toLowerCase().endsWith('manifest.json'));
    if (!hasManifest) {
      errors.push({ file: 'archive', line: null, message: 'No manifest.json found in archive root or subdirectories', severity: 'error' });
    }

    for (const entry of entries) {
      if (entry.name.includes('..') || entry.name.startsWith('/') || entry.name.includes('\\..')) {
        errors.push({ file: entry.name, line: null, message: 'Path traversal detected — blocked for security', severity: 'error' });
      }
      if (entry.size > 100 * 1024 * 1024) {
        errors.push({ file: entry.name, line: null, message: `File exceeds 100MB standalone limit (${(entry.size / (1024 * 1024)).toFixed(1)} MB)`, severity: 'error' });
      }
    }

    return errors;
  }
}
