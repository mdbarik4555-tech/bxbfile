import { 
  collection, 
  doc, 
  getDoc, 
  getDocs, 
  setDoc, 
  updateDoc, 
  deleteDoc, 
  query, 
  where, 
  orderBy, 
  limit, 
  increment,
  runTransaction
} from 'firebase/firestore';
import { 
  ref, 
  uploadBytesResumable, 
  getDownloadURL, 
  deleteObject, 
  UploadTask 
} from 'firebase/storage';
import { 
  db, 
  storage, 
  handleFirestoreError, 
  OperationType 
} from '../config/firebase';
import { 
  FileItem, 
  FileMedia, 
  UploadProgressState, 
  UploadLifecycleState,
  VisibilityMode,
  PublicationStatus,
  FileVersionHistory
} from '../types';
import { calculateSha256, getFileExtension } from '../utils/format';

export interface UploadOptions {
  file: File;
  userId: string;
  userEmail?: string;
  userProfile: {
    username: string;
    displayName: string;
    avatarUrl?: string;
  };
  title: string;
  description: string;
  category: string;
  tags: string[];
  version?: string;
  platform?: string;
  visibility: VisibilityMode;
  publicationStatus?: PublicationStatus;
  isPaid?: boolean;
  price?: number;
  currency?: string;
  coverImage?: File;
  screenshots?: File[];
  proofVideo?: File;
  youtubeUrl?: string;
  creatorWebsite?: string;
  instructions?: string;
  releaseNotes?: string;
  license?: string;
  password?: string;
  countdownSeconds?: number | null;
  expiresAt?: string | null;
  maxDownloads?: number | null;
  redirectUrl?: string | null;
  customLogoUrl?: string | null;
  folderId?: string | null;
  onProgress?: (state: UploadProgressState) => void;
}

export class UploadController {
  private task: UploadTask | null = null;
  private xhr: XMLHttpRequest | null = null;
  private isCancelled = false;

  setTask(task: UploadTask) {
    this.task = task;
  }

  setXhr(xhr: XMLHttpRequest) {
    this.xhr = xhr;
  }

  cancel() {
    this.isCancelled = true;
    if (this.task) {
      this.task.cancel();
    }
    if (this.xhr) {
      this.xhr.abort();
    }
  }

  get cancelled() {
    return this.isCancelled;
  }
}

// Resilient Upload via Server API (guarantees completion without CORS/storage issues)
async function uploadViaServerApi(
  options: UploadOptions,
  controller?: UploadController
): Promise<FileItem> {
  const { 
    file, 
    userId, 
    userEmail,
    userProfile, 
    title, 
    description, 
    category, 
    tags, 
    version, 
    platform, 
    visibility,
    isPaid,
    price,
    currency,
    onProgress 
  } = options;

  return new Promise<FileItem>((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    if (controller) {
      controller.setXhr(xhr);
    }

    const formData = new FormData();
    formData.append('file', file);
    formData.append('userId', userId);
    if (userEmail) formData.append('userEmail', userEmail);
    formData.append('username', userProfile.username);
    formData.append('displayName', userProfile.displayName);
    formData.append('title', title);
    formData.append('description', description);
    formData.append('category', category);
    formData.append('tags', tags.join(','));
    formData.append('version', version || '1.0.0');
    formData.append('platform', platform || 'Universal');
    formData.append('visibility', visibility);
    formData.append('isPaid', String(Boolean(isPaid)));
    if (price) formData.append('price', String(price));
    if (currency) formData.append('currency', currency);
    if (options.password) formData.append('password', options.password);
    if (options.countdownSeconds !== undefined && options.countdownSeconds !== null) formData.append('countdownSeconds', String(options.countdownSeconds));
    if (options.expiresAt) formData.append('expiresAt', options.expiresAt);
    if (options.maxDownloads) formData.append('maxDownloads', String(options.maxDownloads));
    if (options.redirectUrl) formData.append('redirectUrl', options.redirectUrl);
    if (options.customLogoUrl) formData.append('customLogoUrl', options.customLogoUrl);
    if (options.folderId) formData.append('folderId', options.folderId);

    let lastLoaded = 0;
    let lastTime = Date.now();

    xhr.upload.addEventListener('progress', (e) => {
      if (e.lengthComputable) {
        const now = Date.now();
        const timeDiff = (now - lastTime) / 1000;
        const bytesDiff = e.loaded - lastLoaded;
        const speed = timeDiff > 0 ? bytesDiff / timeDiff : 0;
        lastLoaded = e.loaded;
        lastTime = now;

        const percent = Math.min(95, Math.round((e.loaded / e.total) * 100));
        if (onProgress) {
          onProgress({
            progress: percent,
            bytesTransferred: e.loaded,
            totalBytes: e.total,
            status: percent >= 95 ? 'finalizing' : 'uploading',
            storageEngine: 'bxb-server-storage',
            networkSpeedBps: Math.round(speed),
          });
        }
      }
    });

    xhr.addEventListener('load', async () => {
      if (xhr.status >= 200 && xhr.status < 300) {
        try {
          const res = JSON.parse(xhr.responseText);
          const serverFile = res.file as FileItem;

          // Also persist metadata to Firestore so both database and server catalogs stay synced
          try {
            if (onProgress) {
              onProgress({
                progress: 98,
                bytesTransferred: file.size,
                totalBytes: file.size,
                status: 'saving_metadata',
                storageEngine: 'bxb-server-storage',
              });
            }
            await setDoc(doc(db, 'files', serverFile.id), {
              ...serverFile,
              updatedAt: new Date().toISOString(),
            });
          } catch (fsErr) {
            console.warn('Firestore metadata sync skipped:', fsErr);
          }

          if (onProgress) {
            onProgress({
              progress: 100,
              bytesTransferred: file.size,
              totalBytes: file.size,
              status: 'ready',
              storageEngine: 'bxb-server-storage',
              fileId: serverFile.id,
            });
          }
          resolve(serverFile);
        } catch (err) {
          reject(new Error('Invalid response from server upload.'));
        }
      } else {
        try {
          const errRes = JSON.parse(xhr.responseText);
          reject(new Error(errRes.error || `Upload failed with HTTP ${xhr.status}`));
        } catch {
          reject(new Error(`Server error: HTTP ${xhr.status}`));
        }
      }
    });

    xhr.addEventListener('error', () => {
      reject(new Error('Network error during file upload. Check your connection.'));
    });

    xhr.addEventListener('abort', () => {
      reject(new Error('Upload cancelled by user.'));
    });

    xhr.open('POST', '/api/upload');
    xhr.send(formData);
  });
}

// Resilient 12 GB Chunked Resumable Upload (Sections 3 & 4)
async function uploadViaChunkedApi(
  options: UploadOptions,
  controller?: UploadController
): Promise<FileItem> {
  const { 
    file, 
    userId, 
    userEmail, 
    userProfile, 
    title, 
    description, 
    category, 
    tags, 
    version, 
    platform, 
    visibility, 
    isPaid, 
    price, 
    currency, 
    onProgress 
  } = options;

  // Dynamically size chunks to ensure high performance on 100 MB - 12 GB files
  const chunkSize = file.size > 500 * 1024 * 1024 
    ? 25 * 1024 * 1024 
    : file.size > 50 * 1024 * 1024 
      ? 10 * 1024 * 1024 
      : 5 * 1024 * 1024;
  const totalChunks = Math.max(1, Math.ceil(file.size / chunkSize));

  // 1. Initialize resumable session on backend
  const initRes = await fetch('/api/upload/chunk-init', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      fileName: file.name,
      fileSize: file.size,
      totalChunks,
      chunkSize,
      userId,
      userEmail,
      username: userProfile.username,
      displayName: userProfile.displayName,
      title,
      description,
      category,
      tags,
      version: version || '1.0.0',
      platform: platform || 'Universal',
      visibility,
      isPaid: Boolean(isPaid),
      price: price || 0,
      currency: currency || 'INR',
      folderId: options.folderId || null,
      password: options.password,
      countdownSeconds: options.countdownSeconds,
      expiresAt: options.expiresAt,
      maxDownloads: options.maxDownloads,
      redirectUrl: options.redirectUrl,
      customLogoUrl: options.customLogoUrl,
    })
  });

  if (!initRes.ok) {
    const err = await initRes.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to initialize 12 GB upload session.');
  }

  const { uploadId } = await initRes.json();
  let totalBytesTransferred = 0;
  let lastTime = Date.now();
  let lastLoaded = 0;

  for (let i = 0; i < totalChunks; i++) {
    if (controller?.cancelled) {
      await fetch('/api/upload/chunk-abort', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ uploadId })
      }).catch(() => {});
      throw new Error('Upload cancelled by user.');
    }

    const start = i * chunkSize;
    const end = Math.min(file.size, (i + 1) * chunkSize);
    const chunkBlob = file.slice(start, end);

    let attempts = 0;
    let chunkSuccess = false;
    let lastError: any = null;

    while (!chunkSuccess && attempts < 3) {
      attempts++;
      try {
        const formData = new FormData();
        formData.append('uploadId', uploadId);
        formData.append('chunkIndex', String(i));
        formData.append('chunk', chunkBlob, `chunk_${i}.part`);

        await new Promise<void>((resolve, reject) => {
          const xhr = new XMLHttpRequest();
          if (controller) controller.setXhr(xhr);

          xhr.upload.addEventListener('progress', (e) => {
            if (e.lengthComputable) {
              const currentTotal = totalBytesTransferred + e.loaded;
              const now = Date.now();
              const timeDiff = (now - lastTime) / 1000;
              const bytesDiff = currentTotal - lastLoaded;
              const speed = timeDiff > 0.4 ? bytesDiff / timeDiff : 0;
              if (timeDiff >= 0.5) {
                lastTime = now;
                lastLoaded = currentTotal;
              }
              const percent = Math.min(95, Math.round((currentTotal / file.size) * 100));
              if (onProgress) {
                onProgress({
                  progress: percent,
                  bytesTransferred: currentTotal,
                  totalBytes: file.size,
                  status: percent >= 95 ? 'finalizing' : 'uploading',
                  storageEngine: 'bxb-12gb-chunk-engine',
                  networkSpeedBps: Math.round(speed),
                });
              }
            }
          });

          xhr.addEventListener('load', () => {
            if (xhr.status >= 200 && xhr.status < 300) {
              resolve();
            } else {
              try {
                const err = JSON.parse(xhr.responseText);
                reject(new Error(err.error || `Chunk ${i + 1} upload failed with HTTP ${xhr.status}`));
              } catch {
                reject(new Error(`Chunk ${i + 1}/${totalChunks} upload failed.`));
              }
            }
          });

          xhr.addEventListener('error', () => reject(new Error('Network interrupted during chunk transfer. Retrying possible.')));
          xhr.addEventListener('abort', () => reject(new Error('Upload cancelled by user.')));

          // CRITICAL FIX: Pass uploadId and chunkIndex in URL query so diskStorage immediately locates target directory
          xhr.open('POST', `/api/upload/chunk-part?uploadId=${encodeURIComponent(uploadId)}&chunkIndex=${i}`);
          xhr.send(formData);
        });

        chunkSuccess = true;
      } catch (err: any) {
        lastError = err;
        if (controller?.cancelled) throw err;
        if (attempts < 3) {
          await new Promise(r => setTimeout(r, 400 * attempts));
        }
      }
    }

    if (!chunkSuccess) {
      throw lastError || new Error(`Failed to upload chunk ${i + 1} after 3 attempts.`);
    }

    totalBytesTransferred += chunkBlob.size;
  }

  // Finalizing & Assembling
  if (onProgress) {
    onProgress({
      progress: 96,
      bytesTransferred: file.size,
      totalBytes: file.size,
      status: 'finalizing',
      storageEngine: 'bxb-12gb-chunk-engine',
    });
  }

  const completeRes = await fetch('/api/upload/chunk-complete', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ uploadId })
  });

  if (!completeRes.ok) {
    const err = await completeRes.json();
    throw new Error(err.error || 'Failed to assemble file chunks on server.');
  }

  const completeData = await completeRes.json();
  const serverFile = completeData.file as FileItem;

  // Persist metadata to Firestore so client SDK readers see it instantly
  try {
    if (onProgress) {
      onProgress({
        progress: 98,
        bytesTransferred: file.size,
        totalBytes: file.size,
        status: 'saving_metadata',
        storageEngine: 'bxb-12gb-chunk-engine',
      });
    }
    await setDoc(doc(db, 'files', serverFile.id), {
      ...serverFile,
      updatedAt: new Date().toISOString(),
    });
  } catch (fsErr) {
    console.warn('Firestore metadata sync skipped:', fsErr);
  }

  if (onProgress) {
    onProgress({
      progress: 100,
      bytesTransferred: file.size,
      totalBytes: file.size,
      status: 'ready',
      storageEngine: 'bxb-12gb-chunk-engine',
      fileId: serverFile.id,
    });
  }

  return serverFile;
}

export async function uploadAndPublishFile(
  options: UploadOptions,
  controller?: UploadController
): Promise<FileItem> {
  const { 
    file, 
    userId, 
    userEmail,
    userProfile, 
    title, 
    description, 
    category, 
    tags, 
    version, 
    platform, 
    visibility,
    publicationStatus = 'published',
    isPaid = false,
    price = 0,
    currency = 'INR',
    coverImage,
    screenshots,
    proofVideo,
    youtubeUrl,
    creatorWebsite,
    instructions,
    releaseNotes,
    license,
    onProgress 
  } = options;

  // 1. Lifecycle State: VALIDATING
  if (onProgress) {
    onProgress({
      progress: 2,
      bytesTransferred: 0,
      totalBytes: file.size,
      status: 'validating',
    });
  }

  // Pre-upload quota check (Section 3: UNLIMITED file count, up to 12 GB per file)
  try {
    const quotaRes = await fetch(`/api/uploads/quota?userId=${encodeURIComponent(userId)}&userEmail=${encodeURIComponent(userEmail || '')}`);
    if (quotaRes.ok) {
      const quotaData = await quotaRes.json();
      if (file.size > quotaData.maxFileSizeBytes) {
        throw new Error(`File exceeds the maximum configured individual size limit of ${quotaData.maxFileSizeReadable}.`);
      }
    }
  } catch (err: any) {
    if (err?.message?.includes('maximum configured individual size')) {
      throw err;
    }
  }

  // 2. Resilient Upload Execution
  // For files larger than 15 MB, use the chunked streaming engine to avoid high memory pressure
  let fileItem: FileItem;
  try {
    if (file.size > 15 * 1024 * 1024) {
      try {
        fileItem = await uploadViaChunkedApi(options, controller);
      } catch (chunkErr: any) {
        if (chunkErr?.message?.includes('cancelled')) throw chunkErr;
        console.warn('Chunked engine encountered issue, falling back to direct stream upload...', chunkErr);
        fileItem = await uploadViaServerApi(options, controller);
      }
    } else {
      try {
        fileItem = await uploadViaServerApi(options, controller);
      } catch (serverErr: any) {
        if (serverErr?.message?.includes('cancelled')) throw serverErr;
        console.warn('Direct upload falling back to chunked engine...', serverErr);
        fileItem = await uploadViaChunkedApi(options, controller);
      }
    }
    return fileItem;
  } catch (backendErr: any) {
    if (backendErr?.message?.includes('cancelled')) throw backendErr;
    console.warn('Backend upload engines failed, falling back to Firebase Storage...', backendErr);

    // Fallback to direct Firebase Storage
    const checksum = await calculateSha256(file);
    const fileId = `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`;
    const ext = getFileExtension(file.name);
    const cleanFileName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
    const storagePath = `users/${userId}/files/${fileId}/${cleanFileName}`;
    const storageReference = ref(storage, storagePath);

    if (onProgress) {
      onProgress({
        progress: 15,
        bytesTransferred: Math.round(file.size * 0.15),
        totalBytes: file.size,
        status: 'uploading',
        storageEngine: 'firebase-cloud-storage',
      });
    }

    const uploadTask = uploadBytesResumable(storageReference, file, {
      contentType: file.type || 'application/octet-stream',
      customMetadata: {
        originalName: file.name,
        checksumSha256: checksum,
        ownerUid: userId,
      }
    });

    if (controller) {
      controller.setTask(uploadTask);
    }

    const downloadUrl = await new Promise<string>((resolve, reject) => {
      uploadTask.on(
        'state_changed',
        (snapshot) => {
          const percent = Math.round((snapshot.bytesTransferred / snapshot.totalBytes) * 75) + 10;
          if (onProgress) {
            onProgress({
              progress: percent,
              bytesTransferred: snapshot.bytesTransferred,
              totalBytes: snapshot.totalBytes,
              status: percent >= 85 ? 'finalizing' : 'uploading',
              storageEngine: 'firebase-cloud-storage',
            });
          }
        },
        (error) => reject(error),
        async () => {
          try {
            const url = await getDownloadURL(uploadTask.snapshot.ref);
            resolve(url);
          } catch (err) {
            reject(err);
          }
        }
      );
    });

    if (onProgress) {
      onProgress({
        progress: 95,
        bytesTransferred: file.size,
        totalBytes: file.size,
        status: 'saving_metadata',
      });
    }

    fileItem = {
      id: fileId,
      ownerUid: userId,
      ownerUsername: userProfile.username,
      ownerDisplayName: userProfile.displayName,
      ownerAvatarUrl: userProfile.avatarUrl,
      title: title.trim(),
      normalizedTitle: title.trim().toLowerCase(),
      description: description.trim(),
      category,
      tags,
      extension: ext,
      contentType: file.type || 'application/octet-stream',
      fileSize: file.size,
      storagePath,
      downloadUrl,
      version: version?.trim() || '1.0.0',
      platform: platform?.trim() || 'Universal',
      visibility,
      publicationStatus,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      downloadStartCount: 0,
      viewCount: 0,
      checksumSha256: checksum,
      moderationStatus: 'approved',
      instructions: instructions?.trim(),
      releaseNotes: releaseNotes?.trim(),
      license: license?.trim(),
      creatorWebsite: creatorWebsite?.trim(),
      isPaid,
      price: isPaid ? price : 0,
      currency: isPaid ? currency : 'INR',
      salesCount: 0,
    };

    await setDoc(doc(db, 'files', fileId), fileItem);
  }

  if (onProgress) {
    onProgress({
      progress: 100,
      bytesTransferred: file.size,
      totalBytes: file.size,
      status: 'ready',
      fileId: fileItem.id,
    });
  }

  return fileItem;
}

// Fetch file metadata
export async function getFileById(fileId: string): Promise<FileItem | null> {
  // First check Firestore
  try {
    const snap = await getDoc(doc(db, 'files', fileId));
    if (snap.exists()) {
      return snap.data() as FileItem;
    }
  } catch (err) {
    console.warn('Firestore file lookup failed, checking local catalog:', err);
  }

  // Fallback to server catalog
  try {
    const res = await fetch(`/api/download/${fileId}?infoOnly=true`);
    if (res.ok) {
      const data = await res.json();
      return data as FileItem;
    }
  } catch {
    // Ignore
  }

  return null;
}

// Fetch files list with filters
export async function getPublicFiles(options?: {
  category?: string;
  search?: string;
  platform?: string;
  dateFilter?: string;
  sortBy?: 'newest' | 'downloads' | 'size' | 'recent' | 'name';
  limitCount?: number;
  maxResults?: number;
}): Promise<FileItem[]> {
  const { category, search, platform, dateFilter, sortBy = 'newest', limitCount, maxResults = 30 } = options || {};
  const effectiveLimit = limitCount || maxResults;

  try {
    const filesRef = collection(db, 'files');
    let q = query(filesRef, where('visibility', '==', 'public'), limit(effectiveLimit));

    if (category && category !== 'all') {
      q = query(filesRef, where('visibility', '==', 'public'), where('category', '==', category), limit(effectiveLimit));
    }

    const snap = await getDocs(q);
    let items: FileItem[] = [];
    snap.forEach((d) => items.push(d.data() as FileItem));

    // Platform filter
    if (platform && platform !== 'all') {
      items = items.filter(f => f.platform?.toLowerCase().includes(platform.toLowerCase()));
    }

    // Client-side text filter
    if (search && search.trim()) {
      const s = search.toLowerCase().trim();
      items = items.filter(
        (f) =>
          f.normalizedTitle?.includes(s) ||
          f.title?.toLowerCase().includes(s) ||
          f.tags?.some((t) => t.toLowerCase().includes(s)) ||
          f.ownerUsername?.toLowerCase().includes(s)
      );
    }

    if (sortBy === 'downloads') {
      items.sort((a, b) => (b.downloadStartCount || 0) - (a.downloadStartCount || 0));
    } else if (sortBy === 'name') {
      items.sort((a, b) => (a.title || '').localeCompare(b.title || ''));
    } else if (sortBy === 'size') {
      items.sort((a, b) => (b.fileSize || 0) - (a.fileSize || 0));
    } else {
      items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
    }

    return items;
  } catch (error) {
    console.warn('Firestore query error:', error);
    return [];
  }
}

// User uploaded files
export async function getUserFiles(userId: string): Promise<FileItem[]> {
  try {
    const filesRef = collection(db, 'files');
    const q = query(filesRef, where('ownerUid', '==', userId), orderBy('createdAt', 'desc'));
    const snap = await getDocs(q);
    const items: FileItem[] = [];
    snap.forEach((d) => items.push(d.data() as FileItem));
    return items;
  } catch (error) {
    console.warn('Failed to fetch user files:', error);
    return [];
  }
}

// Record download start
export async function recordDownloadStart(fileId: string, _ownerUid?: string): Promise<void> {
  try {
    await updateDoc(doc(db, 'files', fileId), {
      downloadStartCount: increment(1),
    });
  } catch {
    // Non-blocking
  }
}

// Delete file
export async function deleteFile(file: FileItem): Promise<void> {
  try {
    // Delete Firestore document
    await deleteDoc(doc(db, 'files', file.id));
    // Attempt storage deletion
    if (file.storagePath && file.storagePath.startsWith('users/')) {
      try {
        await deleteObject(ref(storage, file.storagePath));
      } catch (stErr) {
        console.warn('Storage object deletion skipped:', stErr);
      }
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `files/${file.id}`);
  }
}

// Update file metadata
export async function updateFileMetadata(fileId: string, fields: Partial<FileItem>): Promise<void> {
  try {
    await updateDoc(doc(db, 'files', fileId), {
      ...fields,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `files/${fileId}`);
  }
}

export async function getRelatedFiles(fileOrId: FileItem | string, categoryParam?: string): Promise<FileItem[]> {
  const targetId = typeof fileOrId === 'string' ? fileOrId : fileOrId.id;
  const targetCategory = typeof fileOrId === 'string' ? categoryParam : fileOrId.category;

  if (!targetCategory) return [];

  try {
    const filesRef = collection(db, 'files');
    const q = query(
      filesRef,
      where('visibility', '==', 'public'),
      where('category', '==', targetCategory),
      limit(5)
    );
    const snap = await getDocs(q);
    const related: FileItem[] = [];
    snap.forEach((d) => {
      if (d.id !== targetId) {
        related.push(d.data() as FileItem);
      }
    });
    return related.slice(0, 4);
  } catch {
    return [];
  }
}

// Fetch public files created by a specific username
export async function getUserPublicFiles(username: string): Promise<FileItem[]> {
  try {
    const filesRef = collection(db, 'files');
    const q = query(
      filesRef,
      where('ownerUsername', '==', username),
      where('visibility', '==', 'public')
    );
    const snap = await getDocs(q);
    const items: FileItem[] = [];
    snap.forEach((d) => items.push(d.data() as FileItem));
    return items.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  } catch (err) {
    console.warn('Failed to query creator public files:', err);
    return [];
  }
}

// Replace binary for existing file (version bump & checksum update)
export async function replaceFileBinary(
  existingFile: FileItem,
  newBinary: File,
  newVersion: string,
  releaseNotes: string,
  onProgress?: (state: UploadProgressState) => void
): Promise<FileItem> {
  if (onProgress) {
    onProgress({
      progress: 10,
      bytesTransferred: 0,
      totalBytes: newBinary.size,
      status: 'validating',
    });
  }

  const checksum = await calculateSha256(newBinary);

  // Upload new binary
  const cleanName = newBinary.name.replace(/[^a-zA-Z0-9._-]/g, '_');
  const storagePath = `users/${existingFile.ownerUid}/files/${existingFile.id}/${cleanName}`;
  const storageRef = ref(storage, storagePath);

  if (onProgress) {
    onProgress({
      progress: 30,
      bytesTransferred: 0,
      totalBytes: newBinary.size,
      status: 'uploading',
    });
  }

  const uploadTask = uploadBytesResumable(storageRef, newBinary);
  const newUrl = await new Promise<string>((resolve, reject) => {
    uploadTask.on(
      'state_changed',
      (snap) => {
        const percent = Math.round((snap.bytesTransferred / snap.totalBytes) * 60) + 30;
        if (onProgress) {
          onProgress({
            progress: percent,
            bytesTransferred: snap.bytesTransferred,
            totalBytes: snap.totalBytes,
            status: 'uploading',
          });
        }
      },
      reject,
      async () => {
        const url = await getDownloadURL(uploadTask.snapshot.ref);
        resolve(url);
      }
    );
  });

  const updatedFile: FileItem = {
    ...existingFile,
    version: newVersion,
    checksumSha256: checksum,
    fileSize: newBinary.size,
    downloadUrl: newUrl,
    storagePath,
    releaseNotes,
    updatedAt: new Date().toISOString(),
  };

  await setDoc(doc(db, 'files', existingFile.id), updatedFile);

  if (onProgress) {
    onProgress({
      progress: 100,
      bytesTransferred: newBinary.size,
      totalBytes: newBinary.size,
      status: 'ready',
    });
  }

  return updatedFile;
}

// ==========================================
// FOLDERS & ORGANIZATION SERVICES (Section 10)
// ==========================================
export async function getFolders(userId: string) {
  try {
    const res = await fetch(`/api/folders?userId=${encodeURIComponent(userId)}`);
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn('Failed to fetch folders from API:', err);
  }
  return [];
}

export async function createFolder(userId: string, name: string, color?: string) {
  const res = await fetch('/api/folders', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId, name, color }),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to create folder');
  }
  return await res.json();
}

export async function deleteFolder(userId: string, folderId: string) {
  const res = await fetch(`/api/folders/${folderId}?userId=${encodeURIComponent(userId)}`, {
    method: 'DELETE',
  });
  if (!res.ok) throw new Error('Failed to delete folder');
  return true;
}

export async function moveFileToFolder(fileId: string, userId: string, folderId: string | null) {
  const res = await fetch(`/api/files/${fileId}/move`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId, folderId }),
  });
  if (!res.ok) throw new Error('Failed to move file');
  return await res.json();
}

// ==========================================
// REELS & COMMUNITY SERVICES (Section 12)
// ==========================================
export async function getReels() {
  try {
    const res = await fetch('/api/reels');
    if (res.ok) return await res.json();
  } catch (err) {
    console.warn('Failed to fetch reels:', err);
  }
  return [];
}

export async function createReel(data: any) {
  const res = await fetch('/api/reels', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  if (!res.ok) {
    const err = await res.json();
    throw new Error(err.error || 'Failed to post reel');
  }
  return await res.json();
}

export async function toggleLikeReel(reelId: string, userId: string) {
  const res = await fetch(`/api/reels/${reelId}/like`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId }),
  });
  if (!res.ok) throw new Error('Failed to like reel');
  return await res.json();
}

export async function commentOnReel(reelId: string, commentData: any) {
  const res = await fetch(`/api/reels/${reelId}/comment`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(commentData),
  });
  if (!res.ok) throw new Error('Failed to post comment');
  return await res.json();
}


