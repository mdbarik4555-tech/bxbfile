import { 
  collection, 
  doc, 
  getDocs, 
  setDoc, 
  updateDoc, 
  query, 
  where, 
  orderBy, 
  limit 
} from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../config/firebase';
import { Report } from '../types';

export async function submitReport(
  targetFileId: string,
  reporterUid: string,
  reason: string,
  description: string
): Promise<Report> {
  const reportId = `${Date.now()}-${Math.random().toString(36).substring(2, 7)}`;
  const report: Report = {
    id: reportId,
    reporterUid,
    targetFileId,
    reason,
    description,
    status: 'pending',
    createdAt: new Date().toISOString(),
  };

  const path = `reports/${reportId}`;
  try {
    await setDoc(doc(db, 'reports', reportId), report);
    return report;
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function getReports(): Promise<Report[]> {
  const path = 'reports';
  try {
    const q = query(
      collection(db, 'reports'),
      orderBy('createdAt', 'desc'),
      limit(50)
    );
    const snap = await getDocs(q);
    return snap.docs.map(d => d.data() as Report);
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, path);
  }
}

export async function updateReportStatus(
  reportId: string, 
  status: 'reviewed' | 'dismissed' | 'actioned'
): Promise<void> {
  const path = `reports/${reportId}`;
  try {
    await updateDoc(doc(db, 'reports', reportId), { status });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}

export async function setFileModerationStatus(
  fileId: string, 
  moderationStatus: 'approved' | 'flagged' | 'restricted'
): Promise<void> {
  const path = `files/${fileId}`;
  try {
    await updateDoc(doc(db, 'files', fileId), {
      moderationStatus,
      updatedAt: new Date().toISOString(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, path);
  }
}
