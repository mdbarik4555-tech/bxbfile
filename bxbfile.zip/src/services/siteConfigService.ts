import { SiteConfig, RevisionRecord, AuditLogRecord, DiagnosticsData } from '../types';

export async function fetchPublicSiteConfig(): Promise<SiteConfig> {
  const res = await fetch('/api/site-settings');
  if (!res.ok) {
    throw new Error('Failed to load site configuration');
  }
  return res.json();
}

export async function fetchOwnerSiteSettings(callerEmail: string): Promise<SiteConfig & { revisions: RevisionRecord[]; auditLogs: AuditLogRecord[] }> {
  const res = await fetch(`/api/owner/site-settings?callerEmail=${encodeURIComponent(callerEmail)}`);
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to fetch owner site settings');
  }
  return res.json();
}

export async function saveSiteSettings(
  callerEmail: string, 
  settings: Partial<SiteConfig>, 
  publish: boolean, 
  summary: string
): Promise<{ success: boolean; isPublish: boolean; config: SiteConfig }> {
  const res = await fetch('/api/owner/site-settings', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ callerEmail, settings, publish, summary }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to save site settings');
  }
  return res.json();
}

export async function rollbackSiteSettings(
  callerEmail: string, 
  revisionId: string
): Promise<{ success: boolean; message: string; config: SiteConfig }> {
  const res = await fetch('/api/owner/site-settings/rollback', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ callerEmail, revisionId }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to rollback site settings');
  }
  return res.json();
}

export async function uploadBrandingAsset(
  callerEmail: string,
  file: File,
  assetType: 'logo' | 'darkLogo' | 'favicon' | 'appIcon'
): Promise<{ success: boolean; url: string; assetType: string; message: string }> {
  const formData = new FormData();
  formData.append('callerEmail', callerEmail);
  formData.append('assetType', assetType);
  formData.append('asset', file);

  const res = await fetch('/api/owner/branding/upload', {
    method: 'POST',
    body: formData,
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to upload branding asset');
  }
  return res.json();
}

export async function restoreDefaultBranding(callerEmail: string): Promise<any> {
  const res = await fetch('/api/owner/branding/restore-default', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ callerEmail }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to restore default branding');
  }
  return res.json();
}

export async function fetchDiagnostics(callerEmail: string): Promise<DiagnosticsData> {
  const res = await fetch(`/api/owner/diagnostics?callerEmail=${encodeURIComponent(callerEmail)}`);
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to fetch diagnostics');
  }
  return res.json();
}

export async function fetchSystemEvents(callerEmail: string): Promise<any[]> {
  const res = await fetch(`/api/owner/events?callerEmail=${encodeURIComponent(callerEmail)}`);
  if (!res.ok) {
    return [];
  }
  return res.json();
}

export async function updateUserAccountStatus(
  callerEmail: string, 
  uid: string, 
  status: 'active' | 'suspended' | 'verified'
): Promise<any> {
  const res = await fetch(`/api/owner/users/${encodeURIComponent(uid)}/status`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ callerEmail, status }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to update user status');
  }
  return res.json();
}

export async function ownerModerationDelete(
  callerEmail: string,
  fileId: string,
  reason: string
): Promise<any> {
  const res = await fetch(`/api/owner/files/${encodeURIComponent(fileId)}/delete`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ callerEmail, reason }),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to delete file');
  }
  return res.json();
}

// Security, Password Verification & Countdown Helpers for Clients
export async function verifyFilePassword(
  fileId: string, 
  password: string
): Promise<{ success: boolean; authorized: boolean; token?: string; redirectUrl?: string | null }> {
  const res = await fetch(`/api/files/${encodeURIComponent(fileId)}/verify-password`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ password }),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Invalid password or verification failed');
  }
  return data;
}

export async function startCountdownSession(
  fileId: string
): Promise<{ success: boolean; sessionId: string; duration: number; startedAt: number }> {
  const res = await fetch(`/api/files/${encodeURIComponent(fileId)}/countdown-start`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Failed to initiate download countdown');
  }
  return data;
}

export async function completeCountdownSession(
  fileId: string,
  sessionId: string
): Promise<{ success: boolean; ticket: string; expiresAt: number }> {
  const res = await fetch(`/api/files/${encodeURIComponent(fileId)}/countdown-complete`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ sessionId }),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Countdown not completed');
  }
  return data;
}

export async function revokeFileLink(fileId: string, callerEmail?: string, userId?: string) {
  const res = await fetch(`/api/files/${encodeURIComponent(fileId)}/revoke-link`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ callerEmail, userId }),
  });
  return res.json();
}

export async function regenerateFileLink(fileId: string, callerEmail?: string, userId?: string) {
  const res = await fetch(`/api/files/${encodeURIComponent(fileId)}/regenerate-link`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ callerEmail, userId }),
  });
  return res.json();
}

export async function updateFileSecurity(
  fileId: string, 
  params: {
    callerEmail?: string;
    userId?: string;
    password?: string;
    removePassword?: boolean;
    countdownSeconds?: number | null;
    expiresAt?: string | null;
    maxDownloads?: number | null;
    redirectUrl?: string | null;
    visibility?: string;
  }
) {
  const res = await fetch(`/api/files/${encodeURIComponent(fileId)}/update-security`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(params),
  });
  const data = await res.json();
  if (!res.ok) {
  return data;
}

// ==========================================
// OWNER POSTS & BULK MODERATION SERVICES
// ==========================================
export async function fetchOwnerPosts(callerEmail: string): Promise<any[]> {
  const res = await fetch(`/api/owner/posts?callerEmail=${encodeURIComponent(callerEmail)}`);
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || 'Failed to fetch owner posts catalog');
  }
  const data = await res.json();
  return data.posts || [];
}

export async function bulkModeratePosts(
  callerEmail: string,
  action: 'delete' | 'promote' | 'unpromote' | 'copyright_strike' | 'remove_strike' | 'pin' | 'unpin',
  fileIds: string[],
  payload?: any
): Promise<any> {
  const res = await fetch('/api/owner/posts/bulk', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ callerEmail, action, fileIds, payload }),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || `Bulk moderation action "${action}" failed`);
  }
  return data;
}

export async function executeWordReplace(
  callerEmail: string,
  findWord: string,
  replaceWith: string
): Promise<{ success: boolean; findWord: string; replaceWith: string; replacedCount: number }> {
  const res = await fetch('/api/owner/word-replace', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ callerEmail, findWord, replaceWith }),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Word replacement failed');
  }
  return data;
}

// ==========================================
// WEBSITE HOSTING SERVICES (Host Web)
// ==========================================
export interface HostedWebPayload {
  slug: string;
  title: string;
  htmlContent: string;
  cssContent?: string;
  jsContent?: string;
  authorUid?: string;
  authorEmail?: string;
  authorUsername?: string;
}

export async function publishHostedWebsite(payload: HostedWebPayload) {
  const res = await fetch('/api/web/publish', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Failed to publish website');
  }
  return data;
}

export async function fetchHostedWebsites(authorEmail?: string) {
  const url = authorEmail ? `/api/web/list?authorEmail=${encodeURIComponent(authorEmail)}` : '/api/web/list';
  const res = await fetch(url);
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Failed to fetch hosted websites');
  }
  return data.sites || [];
}

export async function deleteHostedWebsite(slug: string, callerEmail: string) {
  const res = await fetch(`/api/web/${encodeURIComponent(slug)}/delete`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ callerEmail }),
  });
  const data = await res.json();
  if (!res.ok) {
    throw new Error(data.error || 'Failed to delete hosted website');
  }
  return data;
}

