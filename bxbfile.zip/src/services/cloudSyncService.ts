/**
 * Cloud Sync Engine for bxbfile.bxb / BXB Cloud
 * Supports bidirectional real-time synchronization, offline-first IndexedDB caching,
 * multi-device cluster pairing, conflict resolution, and .bxb snapshot export/import.
 */

export interface SyncItem {
  entityType: 'file' | 'folder' | 'setting' | 'memory' | 'note';
  entityId: string;
  action: 'create' | 'update' | 'delete';
  version?: number;
  data: any;
  checksum?: string;
  timestamp: string;
}

export interface SyncStatus {
  status: 'online' | 'offline' | 'syncing';
  cloudHost: string;
  connected: boolean;
  totalSyncedEntries: number;
  activeDevicesCount: number;
  lastSyncAt: string | null;
  revision: number;
  cloudStorageHealth: string;
  conflictResolutionStrategy: string;
}

export interface SyncedDevice {
  deviceId: string;
  userId: string;
  deviceName: string;
  deviceType: 'desktop' | 'mobile' | 'tablet' | 'browser';
  os: string;
  lastSyncAt: string;
  status: 'connected' | 'syncing' | 'idle' | 'offline';
  syncToken: string;
  pairedAt: string;
}

const LOCAL_SYNC_QUEUE_KEY = 'bxb_sync_pending_queue';
const LOCAL_SYNC_CONFIG_KEY = 'bxb_sync_config';

export interface SyncConfiguration {
  autoSync: boolean;
  syncIntervalSeconds: number;
  syncCategories: {
    files: boolean;
    apks: boolean;
    folders: boolean;
    settings: boolean;
    media: boolean;
    notes: boolean;
  };
  conflictStrategy: 'server_wins' | 'client_wins' | 'smart_merge';
}

export const defaultSyncConfig: SyncConfiguration = {
  autoSync: true,
  syncIntervalSeconds: 30,
  syncCategories: {
    files: true,
    apks: true,
    folders: true,
    settings: true,
    media: true,
    notes: true,
  },
  conflictStrategy: 'smart_merge',
};

export class CloudSyncEngine {
  private static instance: CloudSyncEngine;
  private syncListeners: ((status: SyncStatus) => void)[] = [];
  private currentStatus: SyncStatus = {
    status: 'online',
    cloudHost: 'bxbfile.bxb / bxbcloud.cloud',
    connected: true,
    totalSyncedEntries: 0,
    activeDevicesCount: 1,
    lastSyncAt: null,
    revision: 1,
    cloudStorageHealth: 'optimal',
    conflictResolutionStrategy: 'smart_merge',
  };

  private constructor() {
    if (typeof window !== 'undefined') {
      window.addEventListener('online', () => this.handleNetworkChange(true));
      window.addEventListener('offline', () => this.handleNetworkChange(false));
    }
  }

  static getInstance(): CloudSyncEngine {
    if (!CloudSyncEngine.instance) {
      CloudSyncEngine.instance = new CloudSyncEngine();
    }
    return CloudSyncEngine.instance;
  }

  private handleNetworkChange(online: boolean) {
    this.currentStatus.status = online ? 'online' : 'offline';
    this.currentStatus.connected = online;
    this.notifyListeners();
    if (online) {
      this.triggerAutoSync();
    }
  }

  subscribe(listener: (status: SyncStatus) => void): () => void {
    this.syncListeners.push(listener);
    listener(this.currentStatus);
    return () => {
      this.syncListeners = this.syncListeners.filter(l => l !== listener);
    };
  }

  private notifyListeners() {
    for (const listener of this.syncListeners) {
      listener(this.currentStatus);
    }
  }

  getPendingQueue(): SyncItem[] {
    try {
      const data = localStorage.getItem(LOCAL_SYNC_QUEUE_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  }

  queueMutation(item: Omit<SyncItem, 'timestamp'>) {
    const queue = this.getPendingQueue();
    const fullItem: SyncItem = {
      ...item,
      timestamp: new Date().toISOString(),
    };
    queue.push(fullItem);
    localStorage.setItem(LOCAL_SYNC_QUEUE_KEY, JSON.stringify(queue));
    this.triggerAutoSync();
  }

  clearPendingQueue() {
    localStorage.removeItem(LOCAL_SYNC_QUEUE_KEY);
  }

  getSyncConfig(): SyncConfiguration {
    try {
      const saved = localStorage.getItem(LOCAL_SYNC_CONFIG_KEY);
      return saved ? { ...defaultSyncConfig, ...JSON.parse(saved) } : defaultSyncConfig;
    } catch {
      return defaultSyncConfig;
    }
  }

  saveSyncConfig(config: SyncConfiguration) {
    localStorage.setItem(LOCAL_SYNC_CONFIG_KEY, JSON.stringify(config));
  }

  async fetchStatus(userId: string): Promise<SyncStatus> {
    try {
      const res = await fetch(`/api/sync/status?userId=${encodeURIComponent(userId)}`);
      if (res.ok) {
        const data = await res.json();
        this.currentStatus = { ...this.currentStatus, ...data };
        this.notifyListeners();
      }
    } catch {
      this.currentStatus.status = 'offline';
      this.currentStatus.connected = false;
      this.notifyListeners();
    }
    return this.currentStatus;
  }

  async pushPendingChanges(userId: string, deviceName = 'Browser Client'): Promise<boolean> {
    const queue = this.getPendingQueue();
    if (queue.length === 0) return true;

    this.currentStatus.status = 'syncing';
    this.notifyListeners();

    try {
      const deviceId = localStorage.getItem('bxb_device_id') || `dev_${Math.random().toString(36).substring(2, 9)}`;
      localStorage.setItem('bxb_device_id', deviceId);

      const res = await fetch('/api/sync/push', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId,
          deviceId,
          deviceName,
          items: queue,
        }),
      });

      if (res.ok) {
        this.clearPendingQueue();
        const data = await res.json();
        this.currentStatus.status = 'online';
        this.currentStatus.lastSyncAt = data.syncedAt;
        this.currentStatus.totalSyncedEntries += data.syncedCount || 0;
        this.notifyListeners();
        return true;
      }
    } catch (err) {
      console.warn('Sync push deferred until connectivity restored:', err);
    } finally {
      this.currentStatus.status = 'online';
      this.notifyListeners();
    }
    return false;
  }

  async pullCloudChanges(userId: string): Promise<SyncItem[]> {
    try {
      const lastSync = this.currentStatus.lastSyncAt;
      const url = `/api/sync/pull?userId=${encodeURIComponent(userId)}${lastSync ? `&since=${encodeURIComponent(lastSync)}` : ''}`;
      const res = await fetch(url);
      if (res.ok) {
        const data = await res.json();
        this.currentStatus.lastSyncAt = data.pulledAt;
        this.notifyListeners();
        return data.entries || [];
      }
    } catch (err) {
      console.warn('Sync pull error:', err);
    }
    return [];
  }

  async getDevices(userId: string): Promise<SyncedDevice[]> {
    try {
      const res = await fetch(`/api/sync/devices?userId=${encodeURIComponent(userId)}`);
      if (res.ok) {
        return await res.json();
      }
    } catch (err) {
      console.warn('Error fetching synced devices:', err);
    }
    return [];
  }

  async pairDevice(userId: string, pairingCode: string, deviceName: string, deviceType: 'mobile' | 'desktop' | 'tablet' = 'mobile'): Promise<SyncedDevice> {
    const res = await fetch('/api/sync/pair', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, pairingCode, deviceName, deviceType }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to pair device');
    }
    const data = await res.json();
    return data.device;
  }

  async exportSnapshot(userId: string) {
    const res = await fetch(`/api/sync/snapshot?userId=${encodeURIComponent(userId)}`);
    if (!res.ok) throw new Error('Failed to generate snapshot');
    const blob = await res.blob();
    const url = window.URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bxbfile_sync_snapshot_${Date.now()}.bxb`;
    document.body.appendChild(a);
    a.click();
    window.URL.revokeObjectURL(url);
    document.body.removeChild(a);
  }

  async restoreSnapshot(userId: string, file: File): Promise<any> {
    const text = await file.text();
    const snapshotData = JSON.parse(text);
    const res = await fetch('/api/sync/snapshot/restore', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ userId, snapshotData }),
    });
    if (!res.ok) {
      const err = await res.json();
      throw new Error(err.error || 'Failed to restore snapshot');
    }
    return await res.json();
  }

  private triggerAutoSync() {
    const config = this.getSyncConfig();
    if (!config.autoSync) return;
    const userId = localStorage.getItem('bxb_active_uid');
    if (userId) {
      this.pushPendingChanges(userId);
    }
  }
}

export const cloudSync = CloudSyncEngine.getInstance();
