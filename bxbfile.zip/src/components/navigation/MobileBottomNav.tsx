import React from 'react';
import { Home, RefreshCw, PlusCircle, FolderArchive, Sparkles } from 'lucide-react';
import { useAuth } from '../../context/AuthContext';

interface MobileBottomNavProps {
  currentView: string;
  onNavigate: (view: string, param?: string) => void;
}

export const MobileBottomNav: React.FC<MobileBottomNavProps> = ({ currentView, onNavigate }) => {
  const { user } = useAuth();

  return (
    <div className="fixed bottom-0 left-0 right-0 z-40 lg:hidden border-t border-slate-800/90 bg-[#090b10]/95 backdrop-blur-xl px-4 py-2 flex items-center justify-around shadow-2xl safe-area-pb">
      <button
        onClick={() => onNavigate('home')}
        className={`flex flex-col items-center gap-1 transition ${
          currentView === 'home' ? 'text-cyan-400' : 'text-slate-400 hover:text-slate-200'
        }`}
      >
        <Home className="w-5 h-5" />
        <span className="text-[10px] font-medium">Home</span>
      </button>

      <button
        onClick={() => onNavigate('sync')}
        className={`flex flex-col items-center gap-1 transition ${
          currentView === 'sync' ? 'text-cyan-400 font-bold' : 'text-slate-400 hover:text-slate-200'
        }`}
      >
        <RefreshCw className="w-5 h-5" />
        <span className="text-[10px] font-medium">Sync</span>
      </button>

      {/* Floating Center Upload Button */}
      <button
        onClick={() => onNavigate('upload')}
        className="flex flex-col items-center -mt-5 group"
      >
        <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-400 to-blue-600 text-white flex items-center justify-center shadow-lg shadow-cyan-500/35 border-2 border-[#090b10] group-hover:scale-105 active:scale-95 transition">
          <PlusCircle className="w-6 h-6 stroke-[2.5]" />
        </div>
        <span className="text-[10px] font-semibold text-cyan-400 mt-0.5">Upload</span>
      </button>

      <button
        onClick={() => onNavigate('jarvis')}
        className={`flex flex-col items-center gap-1 transition ${
          currentView === 'jarvis' ? 'text-amber-400 font-bold' : 'text-slate-400 hover:text-slate-200'
        }`}
      >
        <Sparkles className="w-5 h-5 text-amber-400" />
        <span className="text-[10px] font-medium text-amber-300">JARVIS</span>
      </button>

      <button
        onClick={() => onNavigate('options1000')}
        className={`flex flex-col items-center gap-1 transition ${
          currentView === 'options1000' ? 'text-purple-400 font-bold' : 'text-slate-400 hover:text-slate-200'
        }`}
      >
        <span className="text-xs font-mono font-black text-purple-400">1000</span>
        <span className="text-[10px] font-medium text-purple-300">Options</span>
      </button>

      <button
        onClick={() => onNavigate('library')}
        className={`flex flex-col items-center gap-1 transition ${
          currentView === 'library' ? 'text-cyan-400' : 'text-slate-400 hover:text-slate-200'
        }`}
      >
        <FolderArchive className="w-5 h-5" />
        <span className="text-[10px] font-medium">Library</span>
      </button>
    </div>
  );
};
