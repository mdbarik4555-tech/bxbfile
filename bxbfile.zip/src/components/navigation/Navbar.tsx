import React, { useState, useEffect } from 'react';
import { 
  Cloud, 
  UploadCloud, 
  Search, 
  User as UserIcon, 
  LogOut, 
  Shield, 
  FolderArchive, 
  Sparkles, 
  Menu, 
  X, 
  Layers, 
  Sun, 
  Moon,
  Zap,
  Gift,
  Bell,
  Crown,
  Loader2,
  CheckCircle2,
  Settings,
  RefreshCw,
  Globe,
  HardDrive
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { ProfileSettingsModal } from '../profile/ProfileSettingsModal';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string, param?: string) => void;
  onSearchSubmit: (query: string) => void;
}

export const Navbar: React.FC<NavbarProps> = ({ currentView, onNavigate, onSearchSubmit }) => {
  const { 
    user, 
    userProfile, 
    isAdmin, 
    isOwner, 
    dailyTokens, 
    uploadQuota, 
    signIn, 
    signOut,
    switchAccount,
    redeemGiftCode,
    setAuthModalOpen
  } = useAuth();

  const [searchInput, setSearchInput] = useState('');
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [isLightMode, setIsLightMode] = useState(false);
  const [settingsModalOpen, setSettingsModalOpen] = useState(false);
  const [domainModalOpen, setDomainModalOpen] = useState(false);
  const [activeDomain, setActiveDomain] = useState(() => localStorage.getItem('bxb_custom_domain') || 'bxbfile.bxb');
  const [customDomainInput, setCustomDomainInput] = useState('');

  // Gift Code Modal
  const [giftModalOpen, setGiftModalOpen] = useState(false);
  const [giftCodeInput, setGiftCodeInput] = useState('');
  const [giftSubmitting, setGiftSubmitting] = useState(false);
  const [giftResult, setGiftResult] = useState<{ msg: string; success: boolean } | null>(null);

  // Owner Notifications count
  const [unreadCount, setUnreadCount] = useState(0);

  useEffect(() => {
    if (isOwner && user?.email) {
      fetch(`/api/notifications?callerEmail=${encodeURIComponent(user.email)}`)
        .then(r => r.ok ? r.json() : [])
        .then((items: any[]) => {
          const unread = items.filter(i => !i.isRead).length;
          setUnreadCount(unread);
        })
        .catch(() => {});
    }
  }, [isOwner, user]);

  const toggleTheme = () => {
    const next = !isLightMode;
    setIsLightMode(next);
    if (next) {
      document.documentElement.classList.add('light-mode');
    } else {
      document.documentElement.classList.remove('light-mode');
    }
  };

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      onSearchSubmit(searchInput.trim());
      onNavigate('explore');
    }
  };

  const handleRedeemGift = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!giftCodeInput.trim()) return;

    setGiftSubmitting(true);
    setGiftResult(null);

    try {
      const res = await redeemGiftCode(giftCodeInput.trim());
      setGiftResult({ msg: res.message, success: true });
      setTimeout(() => {
        setGiftModalOpen(false);
        setGiftCodeInput('');
        setGiftResult(null);
      }, 2000);
    } catch (err: any) {
      setGiftResult({ msg: err.message || 'Redemption failed', success: false });
    } finally {
      setGiftSubmitting(false);
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full border-b border-slate-800/80 bg-[#090b10]/90 backdrop-blur-xl">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-3">
        {/* Brand */}
        <div 
          onClick={() => onNavigate('home')} 
          className="flex items-center gap-2.5 cursor-pointer group shrink-0"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white shadow-lg shadow-cyan-500/25 group-hover:scale-105 transition-transform">
            <Cloud className="w-5 h-5" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-base sm:text-lg font-black tracking-wider text-white">bxbfile</span>
              <span className="text-base sm:text-lg font-black tracking-wider bg-gradient-to-r from-cyan-400 to-blue-500 bg-clip-text text-transparent font-mono">
                .bxb
              </span>
              <button
                onClick={(e) => { e.stopPropagation(); setDomainModalOpen(true); }}
                className="hidden sm:inline-flex items-center px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-cyan-950/90 text-cyan-300 border border-cyan-800/80 hover:border-cyan-400 hover:text-white transition gap-1 cursor-pointer"
                title="Change or connect web domain"
              >
                <Globe className="w-2.5 h-2.5 text-cyan-400" />
                <span>{activeDomain}</span>
              </button>
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse shadow-sm shadow-emerald-400" title="Cloud Sync Active"></span>
            </div>
            <p className="text-[9px] font-mono tracking-widest text-slate-400 uppercase -mt-0.5 hidden sm:block">
              12 GB Engine • Cloud Sync • JARVIS AI
            </p>
          </div>
        </div>

        {/* Global Search Bar (Desktop) */}
        <form onSubmit={handleSearch} className="hidden xl:flex flex-1 max-w-xs relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchInput}
            onChange={(e) => setSearchInput(e.target.value)}
            placeholder="Search APKs, projects, media..."
            className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-900/90 border border-slate-700/70 focus:border-cyan-400 focus:outline-none focus:ring-1 focus:ring-cyan-400 text-xs text-white placeholder-slate-400 font-sans transition"
          />
        </form>

        {/* Navigation Links */}
        <nav className="hidden lg:flex items-center gap-1">
          <button
            onClick={() => onNavigate('home')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              currentView === 'home' ? 'text-cyan-400 bg-cyan-500/10' : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            Home
          </button>
          <button
            onClick={() => onNavigate('explore')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition ${
              currentView === 'explore' ? 'text-cyan-400 bg-cyan-500/10' : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            Explore
          </button>
          <button
            onClick={() => onNavigate('sync')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1.5 ${
              currentView === 'sync' ? 'text-cyan-400 bg-cyan-500/10 font-bold' : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <RefreshCw className="w-3.5 h-3.5 text-cyan-400 animate-spin-slow" />
            <span>Cloud Sync</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
          </button>
          <button
            onClick={() => onNavigate('jarvis')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
              currentView === 'jarvis'
                ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-md shadow-cyan-500/30'
                : 'text-cyan-300 bg-cyan-950/40 border border-cyan-800/60 hover:bg-cyan-900/40'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>JARVIS AI</span>
          </button>
          <button
            onClick={() => onNavigate('options1000')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
              currentView === 'options1000'
                ? 'bg-gradient-to-r from-purple-500 to-pink-600 text-white shadow-md shadow-purple-500/30'
                : 'text-purple-300 bg-purple-950/40 border border-purple-800/60 hover:bg-purple-900/40'
            }`}
          >
            <Zap className="w-3.5 h-3.5 text-yellow-300" />
            <span>1000 Options</span>
          </button>
          <button
            onClick={() => setSettingsModalOpen(true)}
            className="px-2.5 py-1.5 rounded-lg text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800/60 flex items-center gap-1.5 transition"
            title="Open Profile Settings with 100 Options"
          >
            <Settings className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden xl:inline">100 Profile Options</span>
          </button>
          <button
            onClick={() => onNavigate('community')}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1 ${
              currentView === 'community' ? 'text-cyan-400 bg-cyan-500/10' : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <span>Reels</span>
          </button>
          <button
            onClick={() => onNavigate('tools')}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1 ${
              currentView === 'tools' ? 'text-cyan-400 bg-cyan-500/10' : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <span>Tools</span>
          </button>
          <button
            onClick={() => onNavigate('sandbox')}
            className={`px-2.5 py-1.5 rounded-lg text-xs font-semibold transition flex items-center gap-1 ${
              currentView === 'sandbox' ? 'text-cyan-400 bg-cyan-500/10' : 'text-slate-300 hover:text-white hover:bg-slate-800/60'
            }`}
          >
            <Layers className="w-3.5 h-3.5 text-cyan-400" />
            <span>Sandbox</span>
          </button>
        </nav>

        {/* Right Actions */}
        <div className="flex items-center gap-2">
          {/* User Quota & Daily Token Badge (Part 7 & 8) */}
          {user && (
            <div className="hidden sm:flex items-center gap-1.5 text-xs">
              {/* Cloud Storage Status */}
              <div 
                title="Unlimited Free Cloud Storage & High-Speed Uploads on bxbfile.bxb"
                className={`px-2.5 py-1 rounded-xl border flex items-center gap-1 font-mono font-bold ${
                  isOwner 
                    ? 'bg-amber-500/10 border-amber-500/30 text-amber-400' 
                    : 'bg-emerald-500/10 border-emerald-500/30 text-emerald-300'
                }`}
              >
                {isOwner ? <Crown className="w-3.5 h-3.5 text-amber-400" /> : <HardDrive className="w-3.5 h-3.5 text-emerald-400" />}
                <span>{isOwner ? 'Supreme Owner' : '12 GB Free'}</span>
              </div>

              {/* Gift Code Redeem Button (Part 10) */}
              <button
                onClick={() => setGiftModalOpen(true)}
                className="p-1.5 rounded-xl bg-slate-900 border border-slate-700/80 hover:border-purple-500/50 text-purple-400 hover:text-purple-300 transition"
                title="Redeem Gift or Invitation Code"
              >
                <Gift className="w-4 h-4" />
              </button>
            </div>
          )}

          {/* Owner Notifications Bell (Part 9) */}
          {isOwner && (
            <button
              onClick={() => onNavigate('admin')}
              className="relative p-2 rounded-xl bg-slate-900 border border-slate-700/80 hover:border-cyan-400 text-slate-300 hover:text-cyan-300 transition"
              title="Owner Alert Center"
            >
              <Bell className="w-4 h-4" />
              {unreadCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-red-500 text-white text-[10px] font-bold flex items-center justify-center animate-pulse">
                  {unreadCount > 9 ? '9+' : unreadCount}
                </span>
              )}
            </button>
          )}

          {/* Theme Toggle */}
          <button
            onClick={toggleTheme}
            aria-label="Toggle Theme"
            className="p-2 rounded-xl bg-slate-900 border border-slate-700/80 hover:border-cyan-400 text-slate-300 hover:text-cyan-300 transition"
          >
            {isLightMode ? <Moon className="w-4 h-4 text-cyan-400" /> : <Sun className="w-4 h-4 text-amber-400" />}
          </button>

          {/* Upload Button */}
          <button
            onClick={() => onNavigate('upload')}
            className={`px-3.5 py-2 rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-lg transition glow-btn active:scale-95 ${
              currentView === 'upload'
                ? 'bg-gradient-to-r from-cyan-600 to-blue-700 text-white shadow-cyan-500/30'
                : 'bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white shadow-cyan-500/20'
            }`}
            title="Upload Files up to 12 GB"
          >
            <UploadCloud className="w-4 h-4" />
            <span className="hidden sm:inline">Upload</span>
          </button>

          {/* Host Web Button */}
          <button
            onClick={() => onNavigate('host_web')}
            className={`px-3.5 py-2 rounded-xl font-bold text-xs flex items-center gap-1.5 shadow-lg transition glow-btn active:scale-95 ${
              currentView === 'host_web'
                ? 'bg-gradient-to-r from-purple-600 to-pink-600 text-white shadow-purple-500/30'
                : 'bg-gradient-to-r from-purple-500 to-pink-500 hover:from-purple-400 hover:to-pink-400 text-white shadow-purple-500/20'
            }`}
            title="Host Web - HTML & Website Publishing with Small Link"
          >
            <Globe className="w-4 h-4" />
            <span className="hidden sm:inline">Host Web</span>
          </button>

          {/* User Profile or Google Sign In */}
          {user ? (
            <div className="relative">
              <button
                onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                className="flex items-center gap-1.5 p-1 rounded-xl bg-slate-900 border border-slate-700/80 hover:border-cyan-500/50 transition"
              >
                {userProfile?.avatarUrl || user.photoURL ? (
                  <img
                    src={userProfile?.avatarUrl || user.photoURL!}
                    alt="avatar"
                    className="w-7 h-7 rounded-lg object-cover"
                  />
                ) : (
                  <div className="w-7 h-7 rounded-lg bg-cyan-600 text-white font-bold flex items-center justify-center text-xs">
                    {userProfile?.username?.[0]?.toUpperCase() || 'U'}
                  </div>
                )}
                <span className="text-xs font-mono font-medium text-slate-200 hidden md:inline pr-1">
                  @{userProfile?.username || 'user'}
                </span>
              </button>

              {/* Dropdown Menu */}
              {userDropdownOpen && (
                <div 
                  className="absolute right-0 mt-2 w-56 glass-panel-glow rounded-2xl p-2 shadow-2xl border border-slate-700/80 text-xs text-white z-50 animate-fade-in"
                  onClick={() => setUserDropdownOpen(false)}
                >
                  <div className="px-3 py-2 border-b border-slate-800 mb-1">
                    <p className="font-bold truncate text-white flex items-center gap-1.5">
                      {userProfile?.displayName || user.displayName}
                      {isOwner && (
                        <span className="px-1.5 py-0.5 rounded text-[10px] bg-amber-500/20 text-amber-400 font-bold border border-amber-500/40">
                          OWNER
                        </span>
                      )}
                    </p>
                    <p className="text-[10px] text-cyan-400 font-mono">@{userProfile?.username || 'creator'}</p>
                    <div className="mt-1 text-[10px] text-slate-400 flex items-center justify-between">
                      <span>Daily Tokens:</span>
                      <strong className="text-cyan-300 font-mono">{isOwner ? 'Unlimited' : `${dailyTokens?.balance ?? 1000}`}</strong>
                    </div>
                    <div className="text-[10px] text-slate-400 flex items-center justify-between">
                      <span>Configured Files:</span>
                      <strong className="text-cyan-300 font-mono">Unlimited</strong>
                    </div>
                  </div>

                  <button
                    onClick={() => onNavigate('library')}
                    className="w-full text-left px-3 py-2 rounded-xl hover:bg-slate-800/80 flex items-center gap-2 transition"
                  >
                    <FolderArchive className="w-4 h-4 text-cyan-400" />
                    <span>My Cloud Library</span>
                  </button>

                  <button
                    onClick={() => setSettingsModalOpen(true)}
                    className="w-full text-left px-3 py-2 rounded-xl hover:bg-slate-800/80 flex items-center gap-2 text-cyan-300 transition"
                  >
                    <Settings className="w-4 h-4" />
                    <span>Profile &amp; 100 Settings</span>
                  </button>

                  {userProfile && (
                    <button
                      onClick={() => onNavigate('userProfile', userProfile.username)}
                      className="w-full text-left px-3 py-2 rounded-xl hover:bg-slate-800/80 flex items-center gap-2 transition"
                    >
                      <UserIcon className="w-4 h-4 text-purple-400" />
                      <span>Public Profile</span>
                    </button>
                  )}

                  <button
                    onClick={() => setGiftModalOpen(true)}
                    className="w-full text-left px-3 py-2 rounded-xl hover:bg-slate-800/80 flex items-center gap-2 text-purple-300 transition"
                  >
                    <Gift className="w-4 h-4" />
                    <span>Redeem Gift Code</span>
                  </button>

                  {isAdmin && (
                    <button
                      onClick={() => onNavigate('admin')}
                      className="w-full text-left px-3 py-2 rounded-xl hover:bg-slate-800/80 text-emerald-400 flex items-center gap-2 transition"
                    >
                      <Shield className="w-4 h-4" />
                      <span>{isOwner ? 'Owner & System Center' : 'Moderator Admin'}</span>
                    </button>
                  )}

                  <div className="border-t border-slate-800 mt-1 pt-1 space-y-0.5">
                    <button
                      onClick={() => switchAccount()}
                      className="w-full text-left px-3 py-2 rounded-xl hover:bg-slate-800/80 text-cyan-400 flex items-center gap-2 transition"
                    >
                      <RefreshCw className="w-4 h-4" />
                      <span>Switch Google Account</span>
                    </button>

                    <button
                      onClick={() => signOut()}
                      className="w-full text-left px-3 py-2 rounded-xl hover:bg-red-500/20 text-red-400 flex items-center gap-2 transition"
                    >
                      <LogOut className="w-4 h-4" />
                      <span>Sign Out</span>
                    </button>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <button
              onClick={() => setAuthModalOpen(true)}
              className="py-2 px-3.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 border border-cyan-400/40 text-xs font-bold text-white flex items-center gap-2 transition shadow-lg shadow-cyan-500/20"
            >
              <svg className="w-3.5 h-3.5" viewBox="0 0 24 24">
                <path
                  fill="#EA4335"
                  d="M12 5c1.6 0 3 .6 4.1 1.6l3.1-3.1C17.3 1.8 14.8 1 12 1 7.5 1 3.7 3.6 1.9 7.3l3.7 2.9C6.5 7.4 9 5 12 5z"
                />
                <path
                  fill="#4285F4"
                  d="M23.5 12.3c0-.8-.1-1.7-.2-2.3H12v4.6h6.5c-.3 1.5-1.1 2.8-2.4 3.7l3.7 2.9c2.2-2 3.7-5.1 3.7-8.9z"
                />
                <path
                  fill="#FBBC05"
                  d="M5.6 14.8c-.2-.7-.4-1.5-.4-2.3 0-.8.1-1.6.4-2.3L1.9 7.3C.7 9.7 0 12.3 0 15.1s.7 5.4 1.9 7.8l3.7-3.1z"
                />
                <path
                  fill="#34A853"
                  d="M12 23.5c3.2 0 6-1.1 8-3l-3.7-2.9c-1.1.7-2.5 1.2-4.3 1.2-3 0-5.5-2.4-6.4-5.2L1.9 16.7C3.7 20.4 7.5 23.5 12 23.5z"
                />
              </svg>
              <span>Sign In</span>
            </button>
          )}

          {/* Mobile menu trigger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 lg:hidden"
          >
            {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Gift Redemption Modal (Part 10) */}
      {giftModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-sm glass-panel-glow rounded-3xl p-6 text-white relative shadow-2xl">
            <button
              onClick={() => setGiftModalOpen(false)}
              className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <X className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2.5 mb-4">
              <div className="w-9 h-9 rounded-xl bg-purple-500/20 border border-purple-500/30 flex items-center justify-center text-purple-400">
                <Gift className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-sm">Redeem Gift / Invite Code</h3>
                <p className="text-[11px] text-slate-400">Claim platform tokens for uploads &amp; tools</p>
              </div>
            </div>

            {giftResult && (
              <div className={`mb-3 p-3 rounded-xl text-xs flex items-center gap-2 ${
                giftResult.success 
                  ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-300' 
                  : 'bg-red-500/10 border border-red-500/30 text-red-300'
              }`}>
                {giftResult.success && <CheckCircle2 className="w-4 h-4 shrink-0" />}
                <span>{giftResult.msg}</span>
              </div>
            )}

            <form onSubmit={handleRedeemGift} className="space-y-3">
              <div>
                <input
                  type="text"
                  required
                  value={giftCodeInput}
                  onChange={(e) => setGiftCodeInput(e.target.value.toUpperCase())}
                  placeholder="e.g. BXB-LAUNCH-1000"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs font-mono uppercase text-white focus:border-purple-400 focus:outline-none"
                />
              </div>

              <div className="flex items-center justify-between gap-2 text-[11px] text-slate-400">
                <span>Default codes:</span>
                <button
                  type="button"
                  onClick={() => setGiftCodeInput('BXB-LAUNCH-1000')}
                  className="text-cyan-400 font-mono hover:underline"
                >
                  BXB-LAUNCH-1000
                </button>
              </div>

              <button
                type="submit"
                disabled={giftSubmitting || !giftCodeInput.trim()}
                className="w-full py-2.5 rounded-xl bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white font-semibold text-xs flex items-center justify-center gap-2 transition disabled:opacity-50"
              >
                {giftSubmitting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                <span>Claim Tokens</span>
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Mobile Drawer Menu */}
      {mobileMenuOpen && (
        <div className="lg:hidden border-t border-slate-800 bg-[#090b10] p-4 space-y-3 animate-fade-in">
          <form onSubmit={handleSearch} className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Search files..."
              className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white"
            />
          </form>

          {user && (
            <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800 flex items-center justify-between text-xs">
              <div className="flex items-center gap-1.5 text-cyan-400 font-mono">
                <Zap className="w-4 h-4" />
                <span>Tokens: {isOwner ? 'Unlimited' : `${dailyTokens?.balance ?? 1000}`}</span>
              </div>
              <div className="text-slate-400 font-mono">
                Uploads: {isOwner ? 'Unlimited' : `${uploadQuota?.uploadsCount ?? 0} / 20`}
              </div>
            </div>
          )}

          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              onClick={() => { onNavigate('home'); setMobileMenuOpen(false); }}
              className="p-2.5 rounded-xl bg-slate-900/80 text-xs font-semibold text-slate-200 text-left"
            >
              Home
            </button>
            <button
              onClick={() => { onNavigate('sync'); setMobileMenuOpen(false); }}
              className="p-2.5 rounded-xl bg-cyan-950/50 border border-cyan-800 text-xs font-semibold text-cyan-300 text-left flex items-center justify-between"
            >
              <span>Cloud Sync</span>
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
            </button>
            <button
              onClick={() => { onNavigate('jarvis'); setMobileMenuOpen(false); }}
              className="p-2.5 rounded-xl bg-gradient-to-r from-cyan-900/40 to-blue-900/40 border border-cyan-500/40 text-xs font-bold text-amber-300 text-left col-span-2 flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-amber-300" />
              <span>JARVIS AI Multiverse Center</span>
            </button>
            <button
              onClick={() => { onNavigate('options1000'); setMobileMenuOpen(false); }}
              className="p-2.5 rounded-xl bg-gradient-to-r from-purple-950/60 to-pink-950/60 border border-purple-500/40 text-xs font-bold text-purple-200 text-left col-span-2 flex items-center justify-between"
            >
              <div className="flex items-center gap-2">
                <Zap className="w-4 h-4 text-yellow-300" />
                <span>1,000 Multiverse Options</span>
              </div>
              <span className="px-2 py-0.5 rounded text-[10px] bg-purple-500/20 text-purple-300 font-mono">1000</span>
            </button>
            <button
              onClick={() => { setSettingsModalOpen(true); setMobileMenuOpen(false); }}
              className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 text-xs font-bold text-cyan-300 text-left col-span-2 flex items-center gap-2"
            >
              <Settings className="w-4 h-4 text-cyan-400" />
              <span>Profile &amp; Settings (100 Options)</span>
            </button>
            <button
              onClick={() => { setDomainModalOpen(true); setMobileMenuOpen(false); }}
              className="p-2.5 rounded-xl bg-slate-900/80 border border-slate-800 text-xs font-bold text-slate-200 text-left col-span-2 flex items-center justify-between"
            >
              <div className="flex items-center gap-2">
                <Globe className="w-4 h-4 text-cyan-400" />
                <span>Domain Manager: {activeDomain}</span>
              </div>
              <span className="text-[10px] text-cyan-400 font-mono">Switch</span>
            </button>
            <button
              onClick={() => { onNavigate('explore'); setMobileMenuOpen(false); }}
              className="p-2.5 rounded-xl bg-slate-900/80 text-xs font-semibold text-slate-200 text-left"
            >
              Explore All
            </button>
            <button
              onClick={() => { onNavigate('community'); setMobileMenuOpen(false); }}
              className="p-2.5 rounded-xl bg-slate-900/80 text-xs font-semibold text-cyan-300 text-left"
            >
              Reels
            </button>
            <button
              onClick={() => { onNavigate('tools'); setMobileMenuOpen(false); }}
              className="p-2.5 rounded-xl bg-slate-900/80 text-xs font-semibold text-cyan-300 text-left"
            >
              Tools
            </button>
            <button
              onClick={() => { onNavigate('library'); setMobileMenuOpen(false); }}
              className="p-2.5 rounded-xl bg-slate-900/80 text-xs font-semibold text-slate-200 text-left"
            >
              My Library
            </button>
            <button
              onClick={() => { onNavigate('sandbox'); setMobileMenuOpen(false); }}
              className="p-2.5 rounded-xl bg-slate-900/80 text-xs font-semibold text-slate-200 text-left"
            >
              Web Sandbox
            </button>
          </div>
        </div>
      )}

      {/* Profile & 100 Settings Modal */}
      {settingsModalOpen && (
        <ProfileSettingsModal
          isOpen={settingsModalOpen}
          onClose={() => setSettingsModalOpen(false)}
        />
      )}

      {/* Web Domain Switcher & Custom Domain Manager Modal */}
      {domainModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-md glass-panel-glow rounded-3xl p-6 sm:p-8 text-white relative shadow-2xl border border-cyan-500/30">
            <button
              onClick={() => setDomainModalOpen(false)}
              className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400">
                <Globe className="w-5 h-5" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-white">Domain &amp; Name Manager</h3>
                <p className="text-xs text-slate-400">Active Routing: bxbfile.bxb &amp; BXB File.Cloud</p>
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-slate-300 uppercase tracking-wider block mb-2">
                  Select Active Mirror Domain
                </label>
                <div className="space-y-2">
                  {[
                    { domain: 'bxbfile.bxb', label: 'Primary Brand (Default)', note: 'Official Multiverse Hub' },
                    { domain: 'cloud.bxbfile.bxb', label: 'Cloud CDN Mirror', note: 'Fast Global Routing' },
                    { domain: 'multiverse.bxbfile.bxb', label: 'JARVIS Multiverse Portal', note: 'AI Command Center' },
                    { domain: 'cdn.bxbfile.bxb', label: '12 GB Direct CDN', note: 'Unrestricted Downloads' },
                    { domain: 'apk.bxbfile.bxb', label: 'Android APK Distribution', note: 'Package Modding Hub' },
                  ].map((item) => (
                    <button
                      key={item.domain}
                      onClick={() => {
                        setActiveDomain(item.domain);
                        localStorage.setItem('bxb_custom_domain', item.domain);
                      }}
                      className={`w-full p-3 rounded-2xl border text-left transition flex items-center justify-between ${
                        activeDomain === item.domain
                          ? 'bg-cyan-500/20 border-cyan-400 text-white shadow-md shadow-cyan-500/10'
                          : 'bg-slate-900/60 border-slate-800 text-slate-300 hover:border-slate-700'
                      }`}
                    >
                      <div>
                        <p className="text-xs font-bold font-mono text-cyan-300">{item.domain}</p>
                        <p className="text-[11px] text-slate-400">{item.label} • {item.note}</p>
                      </div>
                      {activeDomain === item.domain && (
                        <CheckCircle2 className="w-4 h-4 text-cyan-400 shrink-0" />
                      )}
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom Domain Input */}
              <div className="pt-2 border-t border-slate-800">
                <label className="text-xs font-bold text-slate-300 block mb-1">
                  Bind Your Custom Domain
                </label>
                <div className="flex gap-2">
                  <input
                    type="text"
                    value={customDomainInput}
                    onChange={(e) => setCustomDomainInput(e.target.value)}
                    placeholder="files.yourdomain.com"
                    className="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 font-mono focus:outline-none focus:border-cyan-500"
                  />
                  <button
                    onClick={() => {
                      if (customDomainInput.trim()) {
                        const clean = customDomainInput.trim().toLowerCase();
                        setActiveDomain(clean);
                        localStorage.setItem('bxb_custom_domain', clean);
                        setCustomDomainInput('');
                      }
                    }}
                    className="px-3 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 text-white text-xs font-bold shadow hover:from-cyan-400 hover:to-blue-500 transition"
                  >
                    Apply
                  </button>
                </div>
                <p className="text-[10px] text-slate-500 mt-1 font-mono">
                  DNS Config: Add CNAME pointing to bxbfile.bxb (SSL auto-provisioned)
                </p>
              </div>

              <button
                onClick={() => setDomainModalOpen(false)}
                className="w-full py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-bold transition"
              >
                Done
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
};
