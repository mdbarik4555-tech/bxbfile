import React, { useState } from 'react';
import { X, ShieldAlert, ExternalLink, RefreshCw, Smartphone, Monitor } from 'lucide-react';
import { FileItem } from '../../types';

interface SandboxPreviewModalProps {
  file: FileItem;
  isOpen: boolean;
  onClose: () => void;
}

export const SandboxPreviewModal: React.FC<SandboxPreviewModalProps> = ({ file, isOpen, onClose }) => {
  const [deviceMode, setDeviceMode] = useState<'desktop' | 'mobile'>('desktop');
  const [key, setKey] = useState(1);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-2 sm:p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="w-full max-w-5xl h-[90vh] glass-panel-glow rounded-3xl flex flex-col text-white relative shadow-2xl overflow-hidden">
        {/* Top bar */}
        <div className="px-5 py-3.5 border-b border-slate-800/90 flex items-center justify-between bg-slate-950/80">
          <div className="flex items-center gap-3">
            <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 animate-pulse"></span>
            <div>
              <h3 className="text-sm font-bold flex items-center gap-2">
                <span>Sandboxed Project Runner:</span>
                <span className="text-cyan-300 font-mono">{file.title}</span>
              </h3>
              <p className="text-[10px] text-slate-400 flex items-center gap-1">
                <ShieldAlert className="w-3 h-3 text-amber-400" />
                Isolated origin environment: no parent cookies or credentials exposed
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="flex items-center bg-slate-900 rounded-xl p-1 border border-slate-800">
              <button
                onClick={() => setDeviceMode('desktop')}
                className={`p-1.5 rounded-lg text-xs transition ${
                  deviceMode === 'desktop' ? 'bg-cyan-500/20 text-cyan-300' : 'text-slate-400'
                }`}
                title="Desktop View"
              >
                <Monitor className="w-4 h-4" />
              </button>
              <button
                onClick={() => setDeviceMode('mobile')}
                className={`p-1.5 rounded-lg text-xs transition ${
                  deviceMode === 'mobile' ? 'bg-cyan-500/20 text-cyan-300' : 'text-slate-400'
                }`}
                title="Mobile View"
              >
                <Smartphone className="w-4 h-4" />
              </button>
            </div>

            <button
              onClick={() => setKey(k => k + 1)}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 transition"
              title="Reload sandbox"
            >
              <RefreshCw className="w-4 h-4" />
            </button>

            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 border border-slate-800 transition"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Sandboxed iframe container */}
        <div className="flex-1 bg-[#05070a] p-3 sm:p-6 flex items-center justify-center overflow-auto">
          <div
            className={`transition-all duration-300 bg-white rounded-2xl overflow-hidden shadow-2xl ${
              deviceMode === 'mobile'
                ? 'w-[375px] h-[667px] border-8 border-slate-800 shadow-cyan-500/10'
                : 'w-full h-full border border-slate-800'
            }`}
          >
            <iframe
              key={key}
              src={file.downloadUrl}
              title={`Preview of ${file.title}`}
              sandbox="allow-scripts allow-forms"
              className="w-full h-full border-none bg-white"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
