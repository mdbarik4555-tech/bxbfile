import React, { useState } from 'react';
import { 
  X, 
  Copy, 
  Check, 
  Share2, 
  QrCode, 
  Globe, 
  Lock, 
  EyeOff,
  ExternalLink 
} from 'lucide-react';
import { FileItem } from '../../types';

interface ShareModalProps {
  file: FileItem;
  isOpen: boolean;
  onClose: () => void;
}

export const ShareModal: React.FC<ShareModalProps> = ({ file, isOpen, onClose }) => {
  const [copied, setCopied] = useState(false);
  const [showQr, setShowQr] = useState(false);

  if (!isOpen) return null;

  const shareUrl = `${window.location.origin}/f/${file.id}`;

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(shareUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2500);
    } catch {
      // Fallback
    }
  };

  const handleNativeShare = async () => {
    if (navigator.share) {
      try {
        await navigator.share({
          title: `${file.title} — BXB Cloud`,
          text: `Download ${file.title} on BXB Cloud:`,
          url: shareUrl,
        });
      } catch {
        // User dismissed
      }
    } else {
      handleCopy();
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-md glass-panel-glow rounded-3xl p-6 text-white relative shadow-2xl">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800/80 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <Share2 className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold">Share File Page</h3>
            <div className="flex items-center gap-1.5 text-xs text-slate-400">
              {file.visibility === 'public' && (
                <>
                  <Globe className="w-3.5 h-3.5 text-emerald-400" />
                  <span className="text-emerald-400 font-medium">Public</span> — Anyone with link can view &amp; download
                </>
              )}
              {file.visibility === 'unlisted' && (
                <>
                  <EyeOff className="w-3.5 h-3.5 text-amber-400" />
                  <span className="text-amber-400 font-medium">Unlisted</span> — Hidden from discovery, accessible by link
                </>
              )}
              {file.visibility === 'private' && (
                <>
                  <Lock className="w-3.5 h-3.5 text-rose-400" />
                  <span className="text-rose-400 font-medium">Private</span> — Only you have authorization to view &amp; download
                </>
              )}
            </div>
          </div>
        </div>

        {file.visibility === 'private' && (
          <div className="mb-4 p-3 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-300 text-xs">
            Notice: This file is currently <strong>Private</strong>. External visitors cannot download it until you change visibility to Public or Unlisted in your Library.
          </div>
        )}

        <div className="space-y-4">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
              Permanent Shareable URL
            </label>
            <div className="flex items-center gap-2 p-1.5 bg-slate-900/90 border border-slate-700/80 rounded-xl">
              <input
                type="text"
                readOnly
                value={shareUrl}
                className="w-full px-3 py-1.5 bg-transparent text-xs font-mono text-cyan-300 focus:outline-none select-all"
              />
              <button
                onClick={handleCopy}
                className="px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black font-semibold text-xs flex items-center gap-1.5 shrink-0 transition"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied!' : 'Copy'}</span>
              </button>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-1">
            <button
              onClick={handleNativeShare}
              className="py-2.5 px-3 rounded-xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-xs font-medium flex items-center justify-center gap-2 transition"
            >
              <Share2 className="w-4 h-4 text-cyan-400" />
              <span>Native Share</span>
            </button>
            <button
              onClick={() => setShowQr(!showQr)}
              className="py-2.5 px-3 rounded-xl bg-slate-800/80 hover:bg-slate-700 border border-slate-700 text-xs font-medium flex items-center justify-center gap-2 transition"
            >
              <QrCode className="w-4 h-4 text-cyan-400" />
              <span>{showQr ? 'Hide QR' : 'Show QR Code'}</span>
            </button>
          </div>

          {showQr && (
            <div className="p-4 rounded-2xl bg-white flex flex-col items-center justify-center gap-3 animate-fade-in">
              {/* Dynamic QR code image generator using reliable quickchart endpoint */}
              <img
                src={`https://api.qrserver.com/v1/create-qr-code/?size=180x180&data=${encodeURIComponent(shareUrl)}`}
                alt="QR Code for Download"
                className="w-40 h-40 rounded-lg"
              />
              <p className="text-[11px] text-slate-800 font-mono text-center">
                Scan with mobile camera to open &amp; download
              </p>
            </div>
          )}

          <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between text-xs text-slate-400">
            <span>Stable ID: <code className="text-slate-300 font-mono">{file.id}</code></span>
            <a
              href={shareUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
            >
              <span>Test Page</span>
              <ExternalLink className="w-3 h-3" />
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};
