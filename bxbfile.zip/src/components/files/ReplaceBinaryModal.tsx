import React, { useState } from 'react';
import { X, UploadCloud, Loader2, Check, RefreshCw } from 'lucide-react';
import { FileItem, UploadProgressState } from '../../types';
import { replaceFileBinary } from '../../services/fileService';
import { formatBytes } from '../../utils/format';

interface ReplaceBinaryModalProps {
  file: FileItem;
  isOpen: boolean;
  onClose: () => void;
  onReplaced: (updated: FileItem) => void;
}

export const ReplaceBinaryModal: React.FC<ReplaceBinaryModalProps> = ({
  file,
  isOpen,
  onClose,
  onReplaced,
}) => {
  const [newFile, setNewFile] = useState<File | null>(null);
  const [newVersion, setNewVersion] = useState('');
  const [releaseNotes, setReleaseNotes] = useState('');
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState<UploadProgressState | null>(null);
  const [error, setError] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newFile || !newVersion.trim()) return;

    setUploading(true);
    setError(null);

    try {
      const updated = await replaceFileBinary(
        file,
        newFile,
        newVersion.trim(),
        releaseNotes.trim() || 'New revision build',
        (p) => setProgress(p)
      );
      onReplaced(updated);
      onClose();
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Binary replacement failed.');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
      <div className="w-full max-w-md glass-panel-glow rounded-3xl p-6 text-white relative shadow-2xl">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800/80 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <div className="flex items-center gap-3 mb-5">
          <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
            <RefreshCw className="w-5 h-5" />
          </div>
          <div>
            <h3 className="text-lg font-bold">Replace File Binary</h3>
            <p className="text-xs text-slate-400">Archive current v{file.version} &amp; release new revision</p>
          </div>
        </div>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs">
          <div>
            <label className="block font-semibold uppercase text-slate-400 mb-1">Select Replacement Binary *</label>
            <input
              type="file"
              required
              onChange={(e) => {
                if (e.target.files && e.target.files[0]) {
                  setNewFile(e.target.files[0]);
                }
              }}
              className="w-full text-slate-400 file:mr-3 file:py-2 file:px-3 file:rounded-xl file:border-0 file:text-xs file:font-semibold file:bg-cyan-500 file:text-black hover:file:bg-cyan-400"
            />
            {newFile && (
              <p className="mt-1 text-[11px] font-mono text-cyan-300">
                {newFile.name} &bull; {formatBytes(newFile.size)}
              </p>
            )}
          </div>

          <div>
            <label className="block font-semibold uppercase text-slate-400 mb-1">New Version Identifier *</label>
            <input
              type="text"
              required
              placeholder="e.g. 2.0.0 or 1.1.0-hotfix"
              value={newVersion}
              onChange={(e) => setNewVersion(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-cyan-400 focus:outline-none"
            />
          </div>

          <div>
            <label className="block font-semibold uppercase text-slate-400 mb-1">Revision Release Notes</label>
            <textarea
              rows={3}
              placeholder="What's changed in this revision..."
              value={releaseNotes}
              onChange={(e) => setReleaseNotes(e.target.value)}
              className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-cyan-400 focus:outline-none resize-none"
            />
          </div>

          {progress && progress.status === 'uploading' && (
            <div className="space-y-1">
              <div className="flex justify-between text-[11px] text-cyan-400">
                <span>Uploading replacement...</span>
                <span>{progress.progress}%</span>
              </div>
              <div className="w-full h-1.5 rounded-full bg-slate-800 overflow-hidden">
                <div className="h-full bg-cyan-400" style={{ width: `${progress.progress}%` }} />
              </div>
            </div>
          )}

          <div className="pt-2">
            <button
              type="submit"
              disabled={uploading || !newFile || !newVersion.trim()}
              className="w-full py-3 rounded-xl font-semibold bg-gradient-to-r from-cyan-500 to-blue-600 text-white flex items-center justify-center gap-2 transition disabled:opacity-50"
            >
              {uploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <UploadCloud className="w-4 h-4" />}
              <span>Upload Revision &amp; Update Public Page</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
