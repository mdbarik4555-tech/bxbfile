import React, { useState } from 'react';
import { X, Save, Loader2, Globe, EyeOff, Lock, Clock, Link as LinkIcon, RefreshCw, Ban, ShieldCheck, Key } from 'lucide-react';
import { FileItem, VisibilityMode, CATEGORIES } from '../../types';
import { updateFileMetadata } from '../../services/fileService';
import { updateFileSecurity, revokeFileLink, regenerateFileLink } from '../../services/siteConfigService';
import { useAuth } from '../../context/AuthContext';

interface EditFileModalProps {
  file: FileItem;
  isOpen: boolean;
  onClose: () => void;
  onUpdated: (updatedFile: FileItem) => void;
}

export const EditFileModal: React.FC<EditFileModalProps> = ({ file, isOpen, onClose, onUpdated }) => {
  const { user } = useAuth();
  const [title, setTitle] = useState(file.title);
  const [description, setDescription] = useState(file.description);
  const [category, setCategory] = useState(file.category);
  const [tagsStr, setTagsStr] = useState(file.tags.join(', '));
  const [version, setVersion] = useState(file.version || '1.0.0');
  const [platform, setPlatform] = useState(file.platform || 'Universal');
  const [visibility, setVisibility] = useState<VisibilityMode>(file.visibility);
  const [instructions, setInstructions] = useState(file.instructions || '');
  const [releaseNotes, setReleaseNotes] = useState(file.releaseNotes || '');
  
  // Security & Protection Controls (Section B, C, D)
  const [hasPassword, setHasPassword] = useState(Boolean(file.hasPassword));
  const [newPassword, setNewPassword] = useState('');
  const [removePassword, setRemovePassword] = useState(false);
  const [countdownSeconds, setCountdownSeconds] = useState<string>(
    file.countdownSeconds !== undefined && file.countdownSeconds !== null ? String(file.countdownSeconds) : 'inherit'
  );
  const [expiresAt, setExpiresAt] = useState(file.expiresAt || '');
  const [maxDownloads, setMaxDownloads] = useState(file.maxDownloads ? String(file.maxDownloads) : '');
  const [redirectUrl, setRedirectUrl] = useState(file.redirectUrl || '');
  const [isRevoked, setIsRevoked] = useState(Boolean(file.isRevoked));
  
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [securityMessage, setSecurityMessage] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    setSaving(true);
    setError(null);

    const tags = tagsStr
      .split(',')
      .map((t) => t.trim().toLowerCase())
      .filter(Boolean);

    const countdownVal = countdownSeconds === 'inherit' 
      ? null 
      : parseInt(countdownSeconds, 10);

    const updates: Partial<FileItem> = {
      title: title.trim(),
      normalizedTitle: title.trim().toLowerCase(),
      description: description.trim(),
      category,
      tags,
      version: version.trim(),
      platform: platform.trim(),
      visibility,
      instructions: instructions.trim(),
      releaseNotes: releaseNotes.trim(),
      countdownSeconds: isNaN(countdownVal as any) ? null : countdownVal,
      expiresAt: expiresAt || undefined,
      maxDownloads: maxDownloads ? parseInt(maxDownloads, 10) : null,
      redirectUrl: redirectUrl ? redirectUrl.trim() : undefined,
    };

    try {
      // 1. Update basic metadata in Firestore
      await updateFileMetadata(file.id, updates);

      // 2. Update security settings on backend (password hashing, countdown, revocation)
      const secRes = await updateFileSecurity(file.id, {
        callerEmail: user?.email || undefined,
        userId: user?.uid,
        password: newPassword.trim() || undefined,
        removePassword,
        countdownSeconds: countdownVal,
        expiresAt: expiresAt || null,
        maxDownloads: maxDownloads ? parseInt(maxDownloads, 10) : null,
        redirectUrl: redirectUrl ? redirectUrl.trim() : null,
        visibility,
      });

      const updatedCombined: FileItem = {
        ...file,
        ...updates,
        hasPassword: removePassword ? false : (newPassword.trim() ? true : file.hasPassword),
        isRevoked,
      };

      onUpdated(updatedCombined);
      onClose();
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Failed to update file.';
      setError(msg);
    } finally {
      setSaving(false);
    }
  };

  const handleToggleRevoke = async () => {
    try {
      if (isRevoked) {
        const res = await regenerateFileLink(file.id, user?.email || undefined, user?.uid);
        setIsRevoked(false);
        setSecurityMessage('Download link regenerated! New access token active.');
      } else {
        const res = await revokeFileLink(file.id, user?.email || undefined, user?.uid);
        setIsRevoked(true);
        setSecurityMessage('Download link revoked. New access is blocked on server.');
      }
      setTimeout(() => setSecurityMessage(null), 3000);
    } catch {
      setError('Failed to update revocation state.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in overflow-y-auto">
      <div className="w-full max-w-xl my-8 glass-panel-glow rounded-3xl p-6 text-white relative shadow-2xl max-h-[90vh] flex flex-col">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800/80 transition"
        >
          <X className="w-5 h-5" />
        </button>

        <h3 className="text-xl font-bold mb-1">Edit File Details &amp; Access Policy</h3>
        <p className="text-xs text-slate-400 mb-4 font-mono">File ID: {file.id}</p>

        {error && (
          <div className="mb-4 p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs">
            {error}
          </div>
        )}

        {securityMessage && (
          <div className="mb-4 p-3 rounded-xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>{securityMessage}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4 text-xs overflow-y-auto pr-1 flex-1">
          <div>
            <label className="block font-semibold uppercase text-slate-400 mb-1">Title</label>
            <input
              type="text"
              required
              maxLength={120}
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-cyan-400 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold uppercase text-slate-400 mb-1">Category</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-cyan-400 focus:outline-none"
              >
                {CATEGORIES.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block font-semibold uppercase text-slate-400 mb-1">Platform</label>
              <input
                type="text"
                value={platform}
                onChange={(e) => setPlatform(e.target.value)}
                placeholder="e.g. Android 8.0+, Windows 11"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-cyan-400 focus:outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-semibold uppercase text-slate-400 mb-1">Version</label>
              <input
                type="text"
                value={version}
                onChange={(e) => setVersion(e.target.value)}
                placeholder="v1.0.0"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-cyan-400 focus:outline-none"
              />
            </div>

            <div>
              <label className="block font-semibold uppercase text-slate-400 mb-1">Tags (comma separated)</label>
              <input
                type="text"
                value={tagsStr}
                onChange={(e) => setTagsStr(e.target.value)}
                placeholder="apk, tool, mod, open-source"
                className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-cyan-400 focus:outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block font-semibold uppercase text-slate-400 mb-1">Visibility Policy</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => setVisibility('public')}
                className={`py-2 px-3 rounded-xl border flex flex-col items-center gap-1 transition ${
                  visibility === 'public'
                    ? 'bg-cyan-500/20 border-cyan-400 text-cyan-300'
                    : 'bg-slate-900/60 border-slate-700 text-slate-400'
                }`}
              >
                <Globe className="w-4 h-4" />
                <span className="font-semibold">Public</span>
              </button>
              <button
                type="button"
                onClick={() => setVisibility('unlisted')}
                className={`py-2 px-3 rounded-xl border flex flex-col items-center gap-1 transition ${
                  visibility === 'unlisted'
                    ? 'bg-amber-500/20 border-amber-400 text-amber-300'
                    : 'bg-slate-900/60 border-slate-700 text-slate-400'
                }`}
              >
                <EyeOff className="w-4 h-4" />
                <span className="font-semibold">Unlisted</span>
              </button>
              <button
                type="button"
                onClick={() => setVisibility('private')}
                className={`py-2 px-3 rounded-xl border flex flex-col items-center gap-1 transition ${
                  visibility === 'private'
                    ? 'bg-rose-500/20 border-rose-400 text-rose-300'
                    : 'bg-slate-900/60 border-slate-700 text-slate-400'
                }`}
              >
                <Lock className="w-4 h-4" />
                <span className="font-semibold">Private</span>
              </button>
            </div>
          </div>

          {/* PASSWORD PROTECTION CONFIGURATION */}
          <div className="p-3.5 rounded-2xl bg-purple-950/30 border border-purple-800/60 space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-bold text-white flex items-center gap-1.5">
                <Key className="w-4 h-4 text-purple-400" />
                <span>Password Protection (PBKDF2 Server Gate)</span>
              </span>
              <span className={`px-2 py-0.2 rounded text-[10px] font-bold uppercase ${
                hasPassword && !removePassword ? 'bg-purple-500/20 text-purple-300' : 'bg-slate-800 text-slate-500'
              }`}>
                {hasPassword && !removePassword ? 'Protected' : 'Open'}
              </span>
            </div>

            <div className="space-y-2">
              <input
                type="password"
                placeholder={hasPassword ? 'Enter new password to update (or leave blank)' : 'Set access password'}
                value={newPassword}
                onChange={(e) => {
                  setNewPassword(e.target.value);
                  setRemovePassword(false);
                }}
                className="w-full px-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-white font-mono"
              />

              {hasPassword && (
                <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                  <input
                    type="checkbox"
                    checked={removePassword}
                    onChange={(e) => {
                      setRemovePassword(e.target.checked);
                      if (e.target.checked) setNewPassword('');
                    }}
                    className="rounded text-purple-600 bg-slate-900 border-slate-700"
                  />
                  <span>Remove password protection entirely</span>
                </label>
              )}
            </div>
          </div>

          {/* COUNTDOWN & DESTINATION URL */}
          <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block font-semibold uppercase text-slate-400 mb-1 flex items-center gap-1">
                  <Clock className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Countdown Override</span>
                </label>
                <select
                  value={countdownSeconds}
                  onChange={(e) => setCountdownSeconds(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-white"
                >
                  <option value="inherit">Inherit System Default</option>
                  <option value="0">Disabled (0s)</option>
                  <option value="10">10 Seconds</option>
                  <option value="15">15 Seconds</option>
                  <option value="20">20 Seconds</option>
                  <option value="30">30 Seconds</option>
                </select>
              </div>

              <div>
                <label className="block font-semibold uppercase text-slate-400 mb-1">Max Download Limit</label>
                <input
                  type="number"
                  placeholder="Unlimited"
                  value={maxDownloads}
                  onChange={(e) => setMaxDownloads(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono"
                />
              </div>
            </div>

            <div>
              <label className="block font-semibold uppercase text-slate-400 mb-1 flex items-center gap-1">
                <LinkIcon className="w-3.5 h-3.5 text-emerald-400" />
                <span>Protected Destination / Redirect Link</span>
              </label>
              <input
                type="url"
                value={redirectUrl}
                onChange={(e) => setRedirectUrl(e.target.value)}
                placeholder="https://... (redirects after password & countdown)"
                className="w-full px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-white"
              />
            </div>
          </div>

          {/* LINK REVOCATION / REGENERATION */}
          <div className="p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800 flex items-center justify-between">
            <div>
              <span className="font-bold text-white block">Link Access Status</span>
              <span className={`text-[11px] ${isRevoked ? 'text-red-400 font-semibold' : 'text-emerald-400'}`}>
                {isRevoked ? 'Link Revoked — Access Denied' : 'Link Active & Accessible'}
              </span>
            </div>

            <button
              type="button"
              onClick={handleToggleRevoke}
              className={`px-3 py-1.5 rounded-xl font-semibold flex items-center gap-1.5 transition ${
                isRevoked 
                  ? 'bg-cyan-600 hover:bg-cyan-500 text-white' 
                  : 'bg-red-950/40 hover:bg-red-900/60 text-red-300 border border-red-800/60'
              }`}
            >
              {isRevoked ? (
                <>
                  <RefreshCw className="w-3.5 h-3.5" />
                  <span>Regenerate Link</span>
                </>
              ) : (
                <>
                  <Ban className="w-3.5 h-3.5" />
                  <span>Revoke Link</span>
                </>
              )}
            </button>
          </div>

          <div>
            <label className="block font-semibold uppercase text-slate-400 mb-1">Description</label>
            <textarea
              rows={2}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-cyan-400 focus:outline-none resize-none"
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={saving}
              className="w-full py-3 rounded-xl font-semibold bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/25 transition glow-btn"
            >
              {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
              <span>Save &amp; Enforce Changes</span>
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
