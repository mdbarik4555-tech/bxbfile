import React, { useState } from 'react';
import { 
  Download, 
  Share2, 
  ShieldCheck, 
  Eye, 
  Check, 
  Sparkles,
  ArrowUpRight 
} from 'lucide-react';
import { FileItem } from '../../types';
import { FileIcon } from '../ui/FileIcon';
import { formatBytes, formatRelativeTime, truncateMiddle } from '../../utils/format';
import { recordDownloadStart } from '../../services/fileService';

interface FileCardProps {
  file: FileItem;
  onOpen: (file: FileItem) => void;
  onShare: (file: FileItem) => void;
  onAuthorClick?: (username: string) => void;
}

export const FileCard: React.FC<FileCardProps> = ({ file, onOpen, onShare, onAuthorClick }) => {
  const [downloading, setDownloading] = useState(false);

  const handleDownload = async (e: React.MouseEvent) => {
    e.stopPropagation();
    setDownloading(true);
    try {
      await recordDownloadStart(file.id, file.ownerUid);
      // Trigger genuine browser download
      const link = document.createElement('a');
      link.href = file.downloadUrl;
      link.download = file.title;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err) {
      console.error('Download error:', err);
    } finally {
      setTimeout(() => setDownloading(false), 2000);
    }
  };

  return (
    <div
      onClick={() => onOpen(file)}
      className="group relative flex flex-col justify-between rounded-2xl glass-panel hover:glass-panel-glow border border-slate-800/80 hover:border-cyan-500/40 p-4 transition-all duration-300 cursor-pointer shadow-lg hover:-translate-y-1"
    >
      {/* Top Banner / Thumbnail if available */}
      {file.thumbnailUrl ? (
        <div className="relative w-full h-32 mb-3 rounded-xl overflow-hidden bg-slate-900 border border-slate-800">
          <img
            src={file.thumbnailUrl}
            alt={file.title}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
            loading="lazy"
          />
          <div className="absolute top-2 right-2">
            <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-black/70 backdrop-blur-md text-cyan-300 border border-cyan-500/30">
              {file.extension.toUpperCase()}
            </span>
          </div>
        </div>
      ) : null}

      <div>
        {/* Header row */}
        <div className="flex items-start gap-3 mb-2.5">
          {!file.thumbnailUrl && <FileIcon extension={file.extension} size="md" />}
          <div className="min-w-0 flex-1">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[10px] font-semibold uppercase tracking-wider text-cyan-400 bg-cyan-950/60 border border-cyan-800/60 px-2 py-0.5 rounded-md">
                {file.category}
              </span>
              {file.platform && (
                <span className="text-[10px] text-slate-400 bg-slate-800/80 px-1.5 py-0.5 rounded">
                  {file.platform}
                </span>
              )}
            </div>
            <h4 className="text-sm font-bold text-white group-hover:text-cyan-300 transition truncate mt-1">
              {file.title}
            </h4>
          </div>
        </div>

        {/* Short Description */}
        <p className="text-xs text-slate-400 line-clamp-2 mb-3 leading-relaxed">
          {file.description || 'No description provided.'}
        </p>

        {/* SHA-256 Badge if present */}
        {file.checksumSha256 && (
          <div className="flex items-center gap-1.5 text-[10px] text-emerald-400 bg-emerald-950/30 border border-emerald-900/40 rounded-lg px-2 py-1 mb-3 font-mono">
            <ShieldCheck className="w-3 h-3 shrink-0" />
            <span className="truncate">SHA256: {truncateMiddle(file.checksumSha256, 14)}</span>
          </div>
        )}
      </div>

      {/* Footer info & actions */}
      <div className="pt-3 border-t border-slate-800/80">
        <div className="flex items-center justify-between text-xs text-slate-400 mb-3">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onAuthorClick?.(file.ownerUsername);
            }}
            className="flex items-center gap-1.5 hover:text-cyan-300 transition"
          >
            {file.ownerAvatarUrl ? (
              <img
                src={file.ownerAvatarUrl}
                alt={file.ownerUsername}
                className="w-4 h-4 rounded-full object-cover"
              />
            ) : (
              <div className="w-4 h-4 rounded-full bg-cyan-600 text-[9px] flex items-center justify-center text-white font-bold">
                {file.ownerUsername[0]?.toUpperCase()}
              </div>
            )}
            <span className="font-mono text-[11px]">@{file.ownerUsername}</span>
          </button>

          <span className="text-[11px] font-mono text-slate-400">
            {formatBytes(file.fileSize)}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleDownload}
            disabled={downloading}
            className="flex-1 py-2 px-3 rounded-xl bg-gradient-to-r from-cyan-500/20 to-blue-500/20 hover:from-cyan-500/30 hover:to-blue-500/30 border border-cyan-500/40 text-cyan-300 font-semibold text-xs flex items-center justify-center gap-1.5 transition active:scale-95"
          >
            {downloading ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-emerald-400">Starting...</span>
              </>
            ) : (
              <>
                <Download className="w-3.5 h-3.5" />
                <span>Download ({file.downloadStartCount || 0})</span>
              </>
            )}
          </button>

          <button
            onClick={(e) => {
              e.stopPropagation();
              onShare(file);
            }}
            aria-label="Share File"
            className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700 transition"
          >
            <Share2 className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>
    </div>
  );
};
