import React, { useEffect } from 'react';
import { useSiteConfig } from '../context/SiteConfigContext';

interface AdSenseBannerProps {
  placement: 'headerLeaderboard' | 'downloadPageBanner' | 'sidebarRectangle' | 'reelsInFeed';
  className?: string;
  slotId?: string;
}

export const AdSenseBanner: React.FC<AdSenseBannerProps> = ({ placement, className = '', slotId }) => {
  const { adsense } = useSiteConfig();

  const isPlacementEnabled = adsense.enabled && adsense.placements?.[placement];
  const pubId = adsense.publisherId || 'ca-pub-0000000000000000';

  useEffect(() => {
    if (isPlacementEnabled && typeof window !== 'undefined') {
      try {
        // Push ad slot to Google Ads queue if window.adsbygoogle is available
        const win = window as any;
        if (win.adsbygoogle) {
          (win.adsbygoogle = win.adsbygoogle || []).push({});
        }
      } catch (e) {
        // Suppress adsbygoogle push error if already pushed
      }
    }
  }, [isPlacementEnabled]);

  if (!isPlacementEnabled) {
    return null;
  }

  // Dimension presets for various placements
  const formatMap = {
    headerLeaderboard: 'horizontal',
    downloadPageBanner: 'rectangle',
    sidebarRectangle: 'vertical',
    reelsInFeed: 'fluid',
  };

  return (
    <div className={`adsense-container my-3 overflow-hidden rounded-xl border border-cyan-500/20 bg-slate-900/60 p-3 backdrop-blur-sm ${className}`}>
      <div className="flex items-center justify-between text-[10px] text-slate-500 font-mono uppercase tracking-wider mb-2">
        <span>Advertisement</span>
        <span className="text-cyan-400/70 font-semibold">{adsense.status === 'verified' ? 'Google AdSense' : 'Ad Preview'}</span>
      </div>

      <div className="flex items-center justify-center min-h-[90px] w-full bg-slate-950/40 rounded-lg border border-slate-800/80 p-2 overflow-hidden">
        {adsense.status === 'verified' && adsense.publisherId ? (
          <ins
            className="adsbygoogle block w-full text-center"
            style={{ display: 'block' }}
            data-ad-client={pubId}
            data-ad-slot={slotId || '1234567890'}
            data-ad-format={formatMap[placement]}
            data-full-width-responsive="true"
          />
        ) : (
          <div className="flex flex-col items-center justify-center py-4 text-center px-4">
            <div className="w-8 h-8 rounded-full bg-cyan-500/10 flex items-center justify-center text-cyan-400 mb-2 border border-cyan-500/30">
              <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <p className="text-xs font-mono font-medium text-slate-300">Google AdSense Placement: {placement}</p>
            <p className="text-[11px] text-slate-400 mt-0.5">Publisher ID: {adsense.publisherId || 'Not configured in Owner Suite'}</p>
          </div>
        )}
      </div>
    </div>
  );
};
