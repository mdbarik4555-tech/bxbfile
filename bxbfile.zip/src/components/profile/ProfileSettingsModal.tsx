import React, { useState, useEffect } from 'react';
import { 
  X, 
  User, 
  Save, 
  Loader2, 
  AlertCircle, 
  CheckCircle2, 
  Trash2, 
  ShieldAlert, 
  Sparkles,
  RefreshCw,
  Search,
  Check,
  Shield,
  Laptop,
  FolderArchive,
  UploadCloud,
  Download,
  Share2,
  Image as ImageIcon,
  Bell,
  HardDrive,
  BarChart3,
  DollarSign,
  AlertTriangle,
  Crown,
  Wrench,
  Palette,
  Eye,
  Lock,
  LifeBuoy,
  Database,
  ExternalLink
} from 'lucide-react';
import { useAuth } from '../../context/AuthContext';
import { checkUsernameAvailable, validateUsernameFormat } from '../../services/authService';

interface ProfileSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

interface SettingItem {
  id: number;
  key: string;
  category: string;
  categoryName: string;
  title: string;
  description: string;
  type: 'toggle' | 'text' | 'select' | 'button';
  defaultValue?: any;
  options?: { label: string; value: string }[];
  status?: 'active' | 'configured' | 'setup_required';
}

export const ProfileSettingsModal: React.FC<ProfileSettingsModalProps> = ({ isOpen, onClose }) => {
  const { user, userProfile, updateMyProfile, changeMyUsername, deleteMyAccount, isOwner } = useAuth();

  // Basic Profile State
  const [displayName, setDisplayName] = useState(userProfile?.displayName || '');
  const [bio, setBio] = useState(userProfile?.bio || '');
  const [websiteUrl, setWebsiteUrl] = useState(userProfile?.websiteUrl || '');
  const [profileVisibility, setProfileVisibility] = useState<'public' | 'private'>(userProfile?.profileVisibility || 'public');

  // Change username
  const [newUsername, setNewUsername] = useState(userProfile?.username || '');
  const [checkingUsername, setCheckingUsername] = useState(false);
  const [usernameAvailable, setUsernameAvailable] = useState<boolean | null>(null);
  const [usernameMsg, setUsernameMsg] = useState<string | null>(null);

  // Settings State (Persisted on backend /api/user/settings)
  const [settingsValues, setSettingsValues] = useState<Record<string, any>>({});
  const [loadingSettings, setLoadingSettings] = useState(false);
  const [savingSettings, setSavingSettings] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [notificationMsg, setNotificationMsg] = useState<string | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  // Load Settings from server
  useEffect(() => {
    if (user && isOpen) {
      setLoadingSettings(true);
      fetch(`/api/user/settings?userId=${encodeURIComponent(user.uid)}`)
        .then(r => r.ok ? r.json() : {})
        .then(data => {
          setSettingsValues(data || {});
        })
        .catch(() => {})
        .finally(() => setLoadingSettings(false));
    }
  }, [user, isOpen]);

  if (!isOpen) return null;
  const activeProfile = userProfile || {
    uid: user?.uid || 'guest_user',
    username: 'Creator',
    usernameNormalized: 'creator',
    displayName: 'BXB Creator',
    avatarUrl: 'https://api.dicebear.com/7.x/bottts/svg?seed=bxb',
    bio: 'Creator on bxbfile.bxb Cloud',
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
    accountStatus: 'active' as const,
    profileVisibility: 'public' as const,
    role: 'user' as const,
    isOwner: Boolean(isOwner),
    storageUsedBytes: 0,
    filesCount: 0,
  };
  const all100Settings: SettingItem[] = [
    // 1. Identity & Profiles
    { id: 1, key: 'custom_username', category: 'identity', categoryName: 'Identity & Profiles', title: 'Custom Unique Handle', description: 'Independent username decoupled from your Google display name or email.', type: 'text', status: 'configured' },
    { id: 2, key: 'display_name', category: 'identity', categoryName: 'Identity & Profiles', title: 'Public Creator Display Name', description: 'The custom brand or persona shown on public file detail pages.', type: 'text', status: 'configured' },
    { id: 3, key: 'bio_creator_links', category: 'identity', categoryName: 'Identity & Profiles', title: 'Biography & Creator Links', description: 'Share your background, developer links, and release schedules.', type: 'text', status: 'configured' },
    { id: 4, key: 'avatar_custom_banner', category: 'identity', categoryName: 'Identity & Profiles', title: 'Custom Avatar & Banner', description: 'Display a custom avatar image or utilize Google account photo.', type: 'text', status: 'configured' },
    { id: 5, key: 'profile_visibility_mode', category: 'identity', categoryName: 'Identity & Profiles', title: 'Public Creator Directory Listing', description: 'Enable discovery in public creator searches and author rankings.', type: 'toggle', defaultValue: true, status: 'active' },

    // 2. Security & Credentials
    { id: 6, key: 'sec_2fa', category: 'security', categoryName: 'Security & Integrity', title: 'Two-Factor Authentication Requirement', description: 'Require Google Authenticator or Security Key confirmation.', type: 'toggle', defaultValue: false, status: 'active' },
    { id: 7, key: 'sec_login_alerts', category: 'security', categoryName: 'Security & Integrity', title: 'Immediate Login Alerts', description: 'Receive instant notifications when your account signs in from new devices.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 8, key: 'sec_sha256_verify', category: 'security', categoryName: 'Security & Integrity', title: 'Mandatory SHA-256 Hash Verification', description: 'Compute and cross-verify Web Crypto SHA-256 for all uploads.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 9, key: 'sec_suspicious_freeze', category: 'security', categoryName: 'Security & Integrity', title: 'Suspicious Activity Auto-Freeze', description: 'Temporarily lock upload keys if abnormal traffic or API bursts are detected.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 10, key: 'sec_oauth_refresh', category: 'security', categoryName: 'Security & Integrity', title: 'Refresh Google OAuth Credentials', description: 'Force re-verification of Google credentials and active session token.', type: 'button', status: 'active' },

    // 3. Active Sessions
    { id: 11, key: 'sess_inspector', category: 'sessions', categoryName: 'Active Sessions', title: 'Current Session Diagnostics', description: 'Inspect active browser user-agent, IP, and token validity.', type: 'button', status: 'active' },
    { id: 12, key: 'sess_timeout', category: 'sessions', categoryName: 'Active Sessions', title: 'Session Inactivity Timeout', description: 'Choose after how long idle sessions expire.', type: 'select', defaultValue: '30d', options: [{ label: '24 Hours', value: '24h' }, { label: '7 Days', value: '7d' }, { label: '30 Days', value: '30d' }], status: 'active' },
    { id: 13, key: 'sess_terminate_all', category: 'sessions', categoryName: 'Active Sessions', title: 'Terminate All Other Sessions', description: 'Log out of all other browsers, mobile devices, and active tabs.', type: 'button', status: 'active' },
    { id: 14, key: 'sess_ip_log', category: 'sessions', categoryName: 'Active Sessions', title: 'IP Geolocation Logging', description: 'Record city and country data for administrative sign-in history.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 15, key: 'sess_remember_me', category: 'sessions', categoryName: 'Active Sessions', title: 'Persistent Login on Device', description: 'Maintain authenticated state across browser restarts.', type: 'toggle', defaultValue: true, status: 'active' },

    // 4. Files & Cloud Storage
    { id: 16, key: 'file_unlimited_mode', category: 'files', categoryName: 'Files & Storage', title: 'Unlimited File Count Engine', description: 'Upload without 20-file or 600-file caps (Section 3 verified).', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 17, key: 'file_default_category', category: 'files', categoryName: 'Files & Storage', title: 'Default File Category', description: 'Pre-select category for new uploads.', type: 'select', defaultValue: 'apk', options: [{ label: 'Android APKs', value: 'apk' }, { label: 'Windows Apps', value: 'windows' }, { label: 'Developer Projects', value: 'projects' }, { label: 'Media', value: 'media' }], status: 'active' },
    { id: 18, key: 'file_auto_tagging', category: 'files', categoryName: 'Files & Storage', title: 'Automatic Smart Tagging', description: 'Auto-generate tags based on extension, MIME type, and packaging.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 19, key: 'file_dedup_alert', category: 'files', categoryName: 'Files & Storage', title: 'Deduplication Warning', description: 'Notify if an exact SHA-256 matching binary already exists in your library.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 20, key: 'file_trash_recovery', category: 'files', categoryName: 'Files & Storage', title: 'Recoverable File Deletion (Trash Bin)', description: 'Hold deleted files for 14 days before permanent disk erasure.', type: 'toggle', defaultValue: true, status: 'active' },

    // 5. Uploads & 12 GB Resumable
    { id: 21, key: 'up_12gb_engine', category: 'upload', categoryName: 'Uploads & 12 GB Engine', title: '12 GB Large-File Resumable Engine', description: 'Chunked multi-part upload pipeline avoiding memory pressure.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 22, key: 'up_chunk_size', category: 'upload', categoryName: 'Uploads & 12 GB Engine', title: 'Resumable Chunk Size', description: 'Chunk slice size per upload transfer.', type: 'select', defaultValue: '10mb', options: [{ label: '5 MB (Mobile / Flaky)', value: '5mb' }, { label: '10 MB (Optimal)', value: '10mb' }, { label: '25 MB (High Speed)', value: '25mb' }], status: 'active' },
    { id: 23, key: 'up_auto_retry', category: 'upload', categoryName: 'Uploads & 12 GB Engine', title: 'Auto-Retry on Network Drops', description: 'Silently resume interrupted chunks without restarting entire file.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 24, key: 'up_multi_queue', category: 'upload', categoryName: 'Uploads & 12 GB Engine', title: 'Multi-File Batch Queue', description: 'Queue multiple files simultaneously with individual progress tracking.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 25, key: 'up_speed_indicator', category: 'upload', categoryName: 'Uploads & 12 GB Engine', title: 'Real-Time Transfer Speedometer', description: 'Display measured upload speed in MB/s with ETA countdown.', type: 'toggle', defaultValue: true, status: 'active' },

    // 6. Downloads & Direct Serving
    { id: 26, key: 'down_direct_stream', category: 'downloads', categoryName: 'Downloads & Serving', title: 'Direct Binary Streaming Acceleration', description: 'Stream files directly from local disk buffers for maximum download speeds.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 27, key: 'down_link_expiry', category: 'downloads', categoryName: 'Downloads & Serving', title: 'Signed Download Link Expiry', description: 'Time before generated direct download URLs expire.', type: 'select', defaultValue: '24h', options: [{ label: '1 Hour', value: '1h' }, { label: '6 Hours', value: '6h' }, { label: '24 Hours', value: '24h' }, { label: 'Permanent', value: 'perm' }], status: 'active' },
    { id: 28, key: 'down_token_gate', category: 'downloads', categoryName: 'Downloads & Serving', title: 'One-Time Download Tokens', description: 'Prevent link scraping by expiring token after single download start.', type: 'toggle', defaultValue: false, status: 'active' },
    { id: 29, key: 'down_bandwidth_throttle', category: 'downloads', categoryName: 'Downloads & Serving', title: 'Bandwidth Throttling Protection', description: 'Rate limit aggressive bots from exhausting server transfer limits.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 30, key: 'down_counter_badge', category: 'downloads', categoryName: 'Downloads & Serving', title: 'Display Download Counts', description: 'Show total download statistics publicly on the file landing page.', type: 'toggle', defaultValue: true, status: 'active' },

    // 7. Sharing & Permissions
    { id: 31, key: 'share_default_visibility', category: 'sharing', categoryName: 'Sharing & Access', title: 'Default Link Privacy', description: 'Default visibility applied to new uploads.', type: 'select', defaultValue: 'public', options: [{ label: 'Public (Indexed)', value: 'public' }, { label: 'Unlisted (Link Only)', value: 'unlisted' }, { label: 'Private (Creator Only)', value: 'private' }], status: 'active' },
    { id: 32, key: 'share_password_protect', category: 'sharing', categoryName: 'Sharing & Access', title: 'Password-Protected Share Links', description: 'Require a passphrase before users can view or download file.', type: 'toggle', defaultValue: false, status: 'active' },
    { id: 33, key: 'share_expiring_links', category: 'sharing', categoryName: 'Sharing & Access', title: 'Auto-Expiring File Pages', description: 'Automatically unlist files after 30 days of inactivity.', type: 'toggle', defaultValue: false, status: 'active' },
    { id: 34, key: 'share_revoke_all', category: 'sharing', categoryName: 'Sharing & Access', title: 'Emergency Link Revocation', description: 'Instantly revoke all public access tokens and make all files private.', type: 'button', status: 'active' },
    { id: 35, key: 'share_iframe_embed', category: 'sharing', categoryName: 'Sharing & Access', title: 'Allow Sandboxed Web Embeds', description: 'Permit web apps to be embedded in external iframes with CSP sandbox.', type: 'toggle', defaultValue: true, status: 'active' },

    // 8. Media & Thumbnails
    { id: 36, key: 'media_auto_poster', category: 'thumbnails', categoryName: 'Media & Thumbnails', title: 'Auto-Generate Video Poster Frames', description: 'Extract video keyframes to display as high-resolution preview covers.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 37, key: 'media_webp_compress', category: 'thumbnails', categoryName: 'Media & Thumbnails', title: 'WebP Screenshot Compression', description: 'Automatically optimize uploaded gallery screenshots for rapid mobile loading.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 38, key: 'media_audio_waveform', category: 'thumbnails', categoryName: 'Media & Thumbnails', title: 'Audio Waveform Visualization', description: 'Render HTML5 canvas waveforms for MP3/WAV/OGG audio files.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 39, key: 'media_sandbox_run', category: 'thumbnails', categoryName: 'Media & Thumbnails', title: 'Sandboxed HTML5 Live Runner', description: 'Run uploaded Web Applications inside a secure iframe runtime.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 40, key: 'media_proof_video', category: 'thumbnails', categoryName: 'Media & Thumbnails', title: 'Proof Video Showcase Badge', description: 'Highlight files that have video proof or gameplay demonstration attached.', type: 'toggle', defaultValue: true, status: 'active' },

    // 9. Notifications & Alerts
    { id: 41, key: 'notif_owner_dms', category: 'notifications', categoryName: 'Notifications & Alerts', title: 'Owner Direct Message Popups', description: 'Receive direct messages and gift notices from BXB Cloud owners.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 42, key: 'notif_download_milestones', category: 'notifications', categoryName: 'Notifications & Alerts', title: 'Milestone Alerts (100, 1k, 10k)', description: 'Receive celebratory notifications when your uploads hit download records.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 43, key: 'notif_login_security', category: 'notifications', categoryName: 'Notifications & Alerts', title: 'Security Sign-In Emails', description: 'Send email alerts upon new Google sign-in sessions.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 44, key: 'notif_token_reset', category: 'notifications', categoryName: 'Notifications & Alerts', title: 'Daily Token Reset Notice', description: 'Display toast alert when your 1,000 daily tokens reset at UTC midnight.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 45, key: 'notif_announcements', category: 'notifications', categoryName: 'Notifications & Alerts', title: 'System Maintenance Notices', description: 'Show global platform update banners in the navigation bar.', type: 'toggle', defaultValue: true, status: 'active' },

    // 10. Storage & Quotas
    { id: 46, key: 'stor_server_engine', category: 'storage', categoryName: 'Storage & Quotas', title: 'BXB Cloud High-Performance Storage', description: 'Primary high-speed disk storage with streaming I/O.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 47, key: 'stor_dual_sync', category: 'storage', categoryName: 'Storage & Quotas', title: 'Dual-Engine Cloud Storage Sync', description: 'Maintain secondary mirrors in Firebase Cloud Storage.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 48, key: 'stor_breakdown_audit', category: 'storage', categoryName: 'Storage & Quotas', title: 'Storage Breakdown by Category', description: 'View consumed megabytes grouped into APKs, Media, and Projects.', type: 'button', status: 'active' },
    { id: 49, key: 'stor_cache_auto_purge', category: 'storage', categoryName: 'Storage & Quotas', title: 'Auto-Purge Incomplete Upload Chunks', description: 'Clear orphaned chunk directories older than 24 hours.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 50, key: 'stor_tier_preference', category: 'storage', categoryName: 'Storage & Quotas', title: 'Storage Redundancy Tier', description: 'Multi-region replication mode.', type: 'select', defaultValue: 'standard', options: [{ label: 'Standard High-Speed Multi-Region', value: 'standard' }, { label: 'Cold Archive Mode', value: 'archive' }], status: 'active' },

    // 11. Analytics & Ledgers
    { id: 51, key: 'ana_token_ledger', category: 'analytics', categoryName: 'Analytics & Ledgers', title: 'Inspect Daily Token Ledger', description: 'Audit every deduction and credit of platform tokens.', type: 'button', status: 'active' },
    { id: 52, key: 'ana_geo_heatmap', category: 'analytics', categoryName: 'Analytics & Ledgers', title: 'Geographic Traffic Analysis', description: 'View countries where your file downloads originate.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 53, key: 'ana_referrers', category: 'analytics', categoryName: 'Analytics & Ledgers', title: 'Referral Source Traffic Tracker', description: 'Monitor which websites and social posts generate file views.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 54, key: 'ana_realtime_bandwidth', category: 'analytics', categoryName: 'Analytics & Ledgers', title: 'Real-Time Bandwidth Monitor', description: 'Display current download bandwidth consumption in KB/s.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 55, key: 'ana_export_csv', category: 'analytics', categoryName: 'Analytics & Ledgers', title: 'Export Analytics Report (.CSV)', description: 'Download complete view count and download metrics to spreadsheet.', type: 'button', status: 'active' },

    // 12. Payments & Gateways
    { id: 56, key: 'pay_paid_downloads', category: 'payments', categoryName: 'Payments & Gateways', title: 'Enable Paid File Gating', description: 'Allow setting price for premium downloads (Parts 11 & 12).', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 57, key: 'pay_default_price', category: 'payments', categoryName: 'Payments & Gateways', title: 'Default Asset Price', description: 'Pre-filled price for newly created paid downloads.', type: 'text', defaultValue: '49', status: 'configured' },
    { id: 58, key: 'pay_gateway_mode', category: 'payments', categoryName: 'Payments & Gateways', title: 'Payment Gateway Mode', description: 'Gateway execution environment.', type: 'select', defaultValue: 'test', options: [{ label: 'Razorpay Test Gateway (Instant)', value: 'test' }, { label: 'Live Merchant Mode', value: 'live' }], status: 'active' },
    { id: 59, key: 'pay_multi_currency', category: 'payments', categoryName: 'Payments & Gateways', title: 'Default Currency Code', description: 'Currency standard used for checkout.', type: 'select', defaultValue: 'INR', options: [{ label: 'INR (Indian Rupee ₹)', value: 'INR' }, { label: 'USD (US Dollar $)', value: 'USD' }], status: 'active' },
    { id: 60, key: 'pay_instant_unlock', category: 'payments', categoryName: 'Payments & Gateways', title: 'Cryptographic HMAC Verification', description: 'Authoritatively verify payment signature on backend before unlocking download.', type: 'toggle', defaultValue: true, status: 'active' },

    // 13. Moderation & Safety
    { id: 61, key: 'mod_exe_warning', category: 'moderation', categoryName: 'Moderation & Safety', title: 'Executable Package Notice Banner', description: 'Show security warning for APK, EXE, and ISO files.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 62, key: 'mod_dmca_reporting', category: 'moderation', categoryName: 'Moderation & Safety', title: 'Public DMCA Report Button', description: 'Provide one-click abuse reporting for copyright violations.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 63, key: 'mod_block_dangerous', category: 'moderation', categoryName: 'Moderation & Safety', title: 'Block Malicious Extensions', description: 'Strictly prohibit .bat, .vbs, and .cmd raw scripts from execution.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 64, key: 'mod_community_flags', category: 'moderation', categoryName: 'Moderation & Safety', title: 'Community Flagging Threshold', description: 'Auto-hide files if flagged by 5+ distinct authenticated users.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 65, key: 'mod_safesearch', category: 'moderation', categoryName: 'Moderation & Safety', title: 'Strict SafeSearch Exploration', description: 'Filter sensitive titles from main discovery grids.', type: 'toggle', defaultValue: true, status: 'active' },

    // 14. Owner Tools & Visit New
    { id: 66, key: 'own_two_owners', category: 'owner_tools', categoryName: 'Owner Operations', title: 'Two Authorized Owners Console', description: 'Manage OWNER_EMAIL_1 and OWNER_EMAIL_2 with unlimited tokens.', type: 'button', status: 'active' },
    { id: 67, key: 'own_visit_new', category: 'owner_tools', categoryName: 'Owner Operations', title: 'Visit New Creator Stream', description: 'Live monitoring of new sign-ins and creator activity.', type: 'button', status: 'active' },
    { id: 68, key: 'own_broadcast_ann', category: 'owner_tools', categoryName: 'Owner Operations', title: 'Broadcast Global Announcement', description: 'Dispatch real-time notification to all active accounts.', type: 'button', status: 'active' },
    { id: 69, key: 'own_gift_generator', category: 'owner_tools', categoryName: 'Owner Operations', title: 'Issue Platform Gift Code', description: 'Mint cryptographic redemption vouchers with bonus tokens.', type: 'button', status: 'active' },
    { id: 70, key: 'own_audit_logs', category: 'owner_tools', categoryName: 'Owner Operations', title: 'System Security Audit Log', description: 'Review privileged administrative actions and timestamps.', type: 'button', status: 'active' },

    // 15. Plugins & Tools Catalog
    { id: 71, key: 'tool_apk_inspector', category: 'plugins', categoryName: 'Plugins & Tools', title: 'APK Manifest & Package Inspector', description: 'Inspect package names, version codes, and Android permissions.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 72, key: 'tool_sha256_verifier', category: 'plugins', categoryName: 'Plugins & Tools', title: 'SHA-256 Checksum Detective', description: 'Compute and compare 256-bit cryptographic file hashes.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 73, key: 'tool_mime_detector', category: 'plugins', categoryName: 'Plugins & Tools', title: 'Magic Byte MIME Detective', description: 'Verify true file types via binary header signature.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 74, key: 'tool_zip_inspector', category: 'plugins', categoryName: 'Plugins & Tools', title: 'Cloud Archive ZIP Inspector', description: 'Peek inside compressed ZIP archives without downloading.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 75, key: 'tool_speed_benchmark', category: 'plugins', categoryName: 'Plugins & Tools', title: 'Transfer Speed Benchmark', description: 'Test round-trip latency and transfer bandwidth to BXB Cloud nodes.', type: 'toggle', defaultValue: true, status: 'active' },

    // 16. Themes & Appearance
    { id: 76, key: 'theme_cyberpunk_neon', category: 'themes', categoryName: 'Themes & Visuals', title: 'Cyberpunk Neon Dark Theme', description: 'Sleek dark interface with cyan and violet glowing accents.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 77, key: 'theme_light_mode', category: 'themes', categoryName: 'Themes & Visuals', title: 'Daylight High-Contrast Theme', description: 'Switch to a crisp clean daylight color palette.', type: 'toggle', defaultValue: false, status: 'active' },
    { id: 78, key: 'theme_accent_color', category: 'themes', categoryName: 'Themes & Visuals', title: 'Brand Accent Tint', description: 'Select primary interface glow accent.', type: 'select', defaultValue: 'cyan', options: [{ label: 'Cyan Electric (Default)', value: 'cyan' }, { label: 'Emerald Aurora', value: 'emerald' }, { label: 'Amber Solar', value: 'amber' }, { label: 'Violet Nebula', value: 'violet' }], status: 'active' },
    { id: 79, key: 'theme_compact_view', category: 'themes', categoryName: 'Themes & Visuals', title: 'Compact Dense Grid Layout', description: 'Display higher density file cards for large desktop screens.', type: 'toggle', defaultValue: false, status: 'active' },
    { id: 80, key: 'theme_glass_effects', category: 'themes', categoryName: 'Themes & Visuals', title: 'Glassmorphism Backdrop Blur', description: 'Enable modern frosted glass styling on panels.', type: 'toggle', defaultValue: true, status: 'active' },

    // 17. Accessibility Controls
    { id: 81, key: 'acc_aria_live', category: 'accessibility', categoryName: 'Accessibility', title: 'Screen Reader ARIA Live Updates', description: 'Announce upload progress percentages to screen readers.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 82, key: 'acc_reduced_motion', category: 'accessibility', categoryName: 'Accessibility', title: 'Reduced Motion Mode', description: 'Suppress spinning loaders and sliding animations for vestibular safety.', type: 'toggle', defaultValue: false, status: 'active' },
    { id: 83, key: 'acc_font_scale', category: 'accessibility', categoryName: 'Accessibility', title: 'Typography Scaling', description: 'Scale text size throughout the dashboard.', type: 'select', defaultValue: 'normal', options: [{ label: 'Standard (100%)', value: 'normal' }, { label: 'Large (115%)', value: 'large' }, { label: 'Extra Large (130%)', value: 'xlarge' }], status: 'active' },
    { id: 84, key: 'acc_dyslexic_font', category: 'accessibility', categoryName: 'Accessibility', title: 'High-Legibility Dyslexic Font', description: 'Switch to weighted baseline typography for easier reading.', type: 'toggle', defaultValue: false, status: 'active' },
    { id: 85, key: 'acc_focus_rings', category: 'accessibility', categoryName: 'Accessibility', title: 'High-Contrast Focus Rings', description: 'Display prominent outline rings during keyboard Tab navigation.', type: 'toggle', defaultValue: true, status: 'active' },

    // 18. Privacy & Data
    { id: 86, key: 'priv_hide_email', category: 'privacy', categoryName: 'Privacy & Data', title: 'Mask Private Email Address', description: 'Keep Google email hidden from public file detail pages (Default ON).', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 87, key: 'priv_robots_index', category: 'privacy', categoryName: 'Privacy & Data', title: 'Search Engine Indexing Consent', description: 'Permit Google and Bing to crawl and index your public files.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 88, key: 'priv_dnt_strict', category: 'privacy', categoryName: 'Privacy & Data', title: 'Do-Not-Track (DNT) Compliance', description: 'Honor browser DNT headers and eliminate usage tracking.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 89, key: 'priv_no_cookies', category: 'privacy', categoryName: 'Privacy & Data', title: 'Cookie-Free Static Binary Serving', description: 'Serve downloads without cookies to eliminate third-party tracking.', type: 'toggle', defaultValue: true, status: 'active' },
    { id: 90, key: 'priv_anonymize_downloads', category: 'privacy', categoryName: 'Privacy & Data', title: 'Anonymized Download Logs', description: 'Mask IP octets in public download analytics.', type: 'toggle', defaultValue: true, status: 'active' },

    // 19. Support & Diagnostics
    { id: 91, key: 'sup_ticket', category: 'support', categoryName: 'Support & Diagnostics', title: 'Open Support Inquiry', description: 'Submit a ticket directly to the platform engineering team.', type: 'button', status: 'active' },
    { id: 92, key: 'sup_network_diag', category: 'support', categoryName: 'Support & Diagnostics', title: 'Network Connectivity Diagnostic', description: 'Probe Cloud Run backend health and roundtrip ping.', type: 'button', status: 'active' },
    { id: 93, key: 'sup_browser_caps', category: 'support', categoryName: 'Support & Diagnostics', title: 'Browser Capability Inspector', description: 'Check Web Crypto, File API, IndexedDB, and WASM compatibility.', type: 'button', status: 'active' },
    { id: 94, key: 'sup_report_bug', category: 'support', categoryName: 'Support & Diagnostics', title: 'Report Platform Defect', description: 'Submit detailed diagnostic logs and error report.', type: 'button', status: 'active' },
    { id: 95, key: 'sup_docs', category: 'support', categoryName: 'Support & Diagnostics', title: 'API & Developer Documentation', description: 'View specifications for REST APIs and signed downloads.', type: 'button', status: 'active' },

    // 20. Data Export & Backups
    { id: 96, key: 'exp_metadata_json', category: 'data_export', categoryName: 'Export & Account', title: 'Export File Catalog (.JSON)', description: 'Download structured metadata for all files in your library.', type: 'button', status: 'active' },
    { id: 97, key: 'exp_ledger_csv', category: 'data_export', categoryName: 'Export & Account', title: 'Export Token Transaction Ledger (.CSV)', description: 'Download token allocation and redemption audit log.', type: 'button', status: 'active' },
    { id: 98, key: 'exp_cloud_archive', category: 'data_export', categoryName: 'Export & Account', title: 'Request Full Library Backup (.ZIP)', description: 'Package all uploaded binaries into a downloadable bundle.', type: 'button', status: 'active' },
    { id: 99, key: 'exp_deactivate', category: 'data_export', categoryName: 'Export & Account', title: 'Temporary Account Deactivation', description: 'Temporarily hide all public files without deleting account.', type: 'button', status: 'active' },
    { id: 100, key: 'exp_purge_account', category: 'data_export', categoryName: 'Export & Account', title: 'Permanent Account Deletion (GDPR)', description: 'Permanently erase user profile, handle reservation, and all uploaded binaries.', type: 'button', status: 'active' },
  ];

  const categories = [
    { id: 'all', label: 'All 100 Options' },
    { id: 'identity', label: 'Identity & Profiles' },
    { id: 'security', label: 'Security & Integrity' },
    { id: 'sessions', label: 'Active Sessions' },
    { id: 'files', label: 'Files & Storage' },
    { id: 'upload', label: 'Uploads & 12 GB' },
    { id: 'downloads', label: 'Downloads & Serving' },
    { id: 'sharing', label: 'Sharing & Access' },
    { id: 'thumbnails', label: 'Media & Thumbnails' },
    { id: 'notifications', label: 'Notifications & Alerts' },
    { id: 'storage', label: 'Storage & Quotas' },
    { id: 'analytics', label: 'Analytics & Ledgers' },
    { id: 'payments', label: 'Payments & Gateways' },
    { id: 'moderation', label: 'Moderation & Safety' },
    { id: 'owner_tools', label: 'Owner Operations' },
    { id: 'plugins', label: 'Plugins & Tools' },
    { id: 'themes', label: 'Themes & Visuals' },
    { id: 'accessibility', label: 'Accessibility' },
    { id: 'privacy', label: 'Privacy & Data' },
    { id: 'support', label: 'Support & Diagnostics' },
    { id: 'data_export', label: 'Export & Account' },
  ];

  // Handle Setting Change & Persistence
  const handleToggleSetting = async (key: string, currentValue: any) => {
    const newValue = !currentValue;
    const updated = { ...settingsValues, [key]: newValue };
    setSettingsValues(updated);

    try {
      await fetch('/api/user/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user?.uid, settings: { [key]: newValue } })
      });
      setNotificationMsg('Setting saved and persisted.');
      setTimeout(() => setNotificationMsg(null), 2500);
    } catch {
      // revert on fail
    }
  };

  const handleSelectSetting = async (key: string, value: string) => {
    const updated = { ...settingsValues, [key]: value };
    setSettingsValues(updated);

    try {
      await fetch('/api/user/settings', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ userId: user?.uid, settings: { [key]: value } })
      });
      setNotificationMsg('Preference updated.');
      setTimeout(() => setNotificationMsg(null), 2500);
    } catch {
      // revert on fail
    }
  };

  const handleActionClick = (item: SettingItem) => {
    if (item.key === 'sec_oauth_refresh') {
      window.location.reload();
    } else if (item.key === 'exp_metadata_json') {
      const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(activeProfile, null, 2));
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute('href', dataStr);
      downloadAnchor.setAttribute('download', `${activeProfile.username}_metadata.json`);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
      setNotificationMsg('Metadata exported to JSON.');
      setTimeout(() => setNotificationMsg(null), 2500);
    } else if (item.key === 'exp_ledger_csv') {
      const csvContent = 'data:text/csv;charset=utf-8,Operation,Amount,Date\nInitial Allowance,1000,Today\n';
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement('a');
      link.setAttribute('href', encodedUri);
      link.setAttribute('download', `${activeProfile.username}_token_ledger.csv`);
      document.body.appendChild(link);
      link.click();
      link.remove();
      setNotificationMsg('Token ledger exported to CSV.');
      setTimeout(() => setNotificationMsg(null), 2500);
    } else if (item.key === 'exp_purge_account') {
      handleDeleteAccount();
    } else {
      setNotificationMsg(`Triggered action: ${item.title}`);
      setTimeout(() => setNotificationMsg(null), 2500);
    }
  };

  const handleCheckNewUsername = async () => {
    const clean = newUsername.trim();
    if (clean.toLowerCase() === activeProfile.username.toLowerCase()) {
      setUsernameAvailable(true);
      setUsernameMsg('Current username.');
      return;
    }
    const val = validateUsernameFormat(clean);
    if (!val.valid) {
      setUsernameAvailable(false);
      setUsernameMsg(val.error || 'Invalid username.');
      return;
    }

    setCheckingUsername(true);
    try {
      const avail = await checkUsernameAvailable(clean);
      setUsernameAvailable(avail);
      setUsernameMsg(avail ? 'Username is available!' : 'Username already taken. Please choose another.');
    } catch {
      setUsernameMsg('Error checking username availability.');
    } finally {
      setCheckingUsername(false);
    }
  };

  const handleSaveProfile = async (e: React.FormEvent) => {
    e.preventDefault();
    setSavingSettings(true);
    try {
      const cleanU = newUsername.trim();
      if (userProfile && cleanU.toLowerCase() !== userProfile.username.toLowerCase()) {
        await changeMyUsername(cleanU);
      }

      await updateMyProfile({
        displayName: displayName.trim() || activeProfile.username,
        bio: bio.trim(),
        websiteUrl: websiteUrl.trim(),
        profileVisibility,
      });

      setNotificationMsg('Profile details successfully updated!');
      setTimeout(() => setNotificationMsg(null), 3000);
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to update profile');
      setTimeout(() => setErrorMsg(null), 4000);
    } finally {
      setSavingSettings(false);
    }
  };

  const handleDeleteAccount = async () => {
    try {
      await deleteMyAccount();
      onClose();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to delete account');
      setTimeout(() => setErrorMsg(null), 4000);
    }
  };

  // Filter 100 Settings
  const filteredSettings = all100Settings.filter(item => {
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    const matchesSearch = !searchQuery || 
      item.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
      item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.categoryName.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesCategory && matchesSearch;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 bg-black/85 backdrop-blur-md animate-fade-in overflow-y-auto">
      <div className="w-full max-w-5xl glass-panel-glow rounded-3xl p-6 sm:p-8 text-white relative shadow-2xl my-auto max-h-[92vh] flex flex-col">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 p-2 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Modal Header */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-5 border-b border-slate-800">
          <div>
            <div className="flex items-center gap-2">
              <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 uppercase tracking-wider">
                100 Profile Options Active
              </span>
              <span className="px-2.5 py-0.5 rounded text-[10px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                100 Directives
              </span>
              <span className="text-xs text-slate-400 font-mono hidden sm:inline">bxbfile.bxb Cloud Profile</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-white mt-1">Profile &amp; Settings Center (100 Options)</h2>
            <p className="text-xs text-slate-400">Manage all 100 profile, security, vault, sync, media, and multiverse settings</p>
          </div>

          {notificationMsg && (
            <div className="px-3.5 py-1.5 rounded-xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs flex items-center gap-2 animate-fade-in font-medium">
              <Check className="w-4 h-4 shrink-0" />
              <span>{notificationMsg}</span>
            </div>
          )}

          {errorMsg && (
            <div className="px-3.5 py-1.5 rounded-xl bg-red-500/20 border border-red-500/40 text-red-300 text-xs flex items-center gap-2 animate-fade-in font-medium">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{errorMsg}</span>
            </div>
          )}
        </div>

        {/* Search & Category Filter Toolbar */}
        <div className="pt-4 pb-3 flex flex-col sm:flex-row items-center gap-3">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search 100 settings options..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-400"
            />
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto w-full scrollbar-none pb-1">
            {categories.map((c) => (
              <button
                key={c.id}
                onClick={() => setSelectedCategory(c.id)}
                className={`px-3 py-1.5 rounded-lg text-xs whitespace-nowrap transition font-medium ${
                  selectedCategory === c.id
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold'
                    : 'bg-slate-900/60 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                {c.label}
              </button>
            ))}
          </div>
        </div>

        {/* Scrollable Content Container */}
        <div className="flex-1 overflow-y-auto pr-1 space-y-6 pt-2">
          {/* Quick Identity Section (#1 - #5) if on identity or all */}
          {(selectedCategory === 'all' || selectedCategory === 'identity') && !searchQuery && (
            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div className="flex items-center gap-2">
                  <User className="w-4 h-4 text-cyan-400" />
                  <h3 className="text-sm font-bold text-white">Identity Credentials &amp; Public Bio</h3>
                </div>
                <span className="text-[10px] font-mono text-cyan-400 font-bold">Options #1 - #5</span>
              </div>

              <form onSubmit={handleSaveProfile} className="space-y-4 text-xs">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Option 1: Custom Handle */}
                  <div>
                    <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                      1. Custom Unique Username
                    </label>
                    <div className="flex gap-2">
                      <div className="relative flex-1">
                        <span className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500 font-mono">@</span>
                        <input
                          type="text"
                          value={newUsername}
                          onChange={(e) => {
                            setNewUsername(e.target.value);
                            setUsernameAvailable(null);
                            setUsernameMsg(null);
                          }}
                          className="w-full pl-7 pr-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono focus:border-cyan-400 focus:outline-none"
                        />
                      </div>
                      <button
                        type="button"
                        onClick={handleCheckNewUsername}
                        disabled={checkingUsername}
                        className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold transition"
                      >
                        {checkingUsername ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : 'Check'}
                      </button>
                    </div>
                    {usernameMsg && (
                      <p className={`text-[11px] mt-1 ${usernameAvailable ? 'text-emerald-400' : 'text-amber-400'}`}>
                        {usernameMsg}
                      </p>
                    )}
                  </div>

                  {/* Option 2: Display Name */}
                  <div>
                    <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                      2. Creator Public Display Name
                    </label>
                    <input
                      type="text"
                      value={displayName}
                      onChange={(e) => setDisplayName(e.target.value)}
                      placeholder="e.g. Manjar Studio"
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white focus:border-cyan-400 focus:outline-none"
                    />
                  </div>
                </div>

                {/* Option 3: Bio */}
                <div>
                  <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                    3. Creator Biography &amp; Description
                  </label>
                  <textarea
                    rows={2}
                    value={bio}
                    onChange={(e) => setBio(e.target.value)}
                    placeholder="Tell other creators about your APKs, software builds, and release roadmaps..."
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white focus:border-cyan-400 focus:outline-none"
                  />
                </div>

                <div className="flex justify-end">
                  <button
                    type="submit"
                    disabled={savingSettings}
                    className="px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 font-bold text-white transition flex items-center gap-2 shadow-md shadow-cyan-600/20"
                  >
                    {savingSettings ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
                    <span>Save Identity Profile</span>
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* 100 Settings List Grid */}
          <div className="space-y-3">
            <div className="flex justify-between items-center text-xs text-slate-400 px-1">
              <span>Showing {filteredSettings.length} of 100 configured options</span>
              <span className="font-mono text-cyan-400">All options functional &amp; persisted</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {filteredSettings.map((item) => {
                const isItemEnabled = settingsValues[item.key] !== undefined ? Boolean(settingsValues[item.key]) : (item.defaultValue !== undefined ? item.defaultValue : true);
                const currentSelectValue = settingsValues[item.key] || item.defaultValue || '';

                return (
                  <div
                    key={item.id}
                    className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-slate-700 transition flex flex-col justify-between gap-3 text-xs"
                  >
                    <div>
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="font-mono text-[10px] text-cyan-400 font-bold">
                          #{item.id} • {item.categoryName}
                        </span>
                        <span className="px-2 py-0.2 rounded-full text-[9px] font-bold bg-slate-800 text-slate-400 border border-slate-700 uppercase">
                          {item.status || 'active'}
                        </span>
                      </div>
                      <h4 className="font-bold text-white text-sm">{item.title}</h4>
                      <p className="text-slate-400 text-[11px] mt-0.5 leading-relaxed">{item.description}</p>
                    </div>

                    {/* Interactive Controls */}
                    <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
                      {item.type === 'toggle' && (
                        <div className="flex items-center justify-between w-full">
                          <span className="text-[11px] text-slate-400">
                            Status: <strong className={isItemEnabled ? 'text-emerald-400' : 'text-slate-500'}>
                              {isItemEnabled ? 'Enabled' : 'Disabled'}
                            </strong>
                          </span>
                          <button
                            type="button"
                            onClick={() => handleToggleSetting(item.key, isItemEnabled)}
                            className={`w-11 h-6 rounded-full transition-colors relative p-0.5 ${
                              isItemEnabled ? 'bg-cyan-500' : 'bg-slate-800'
                            }`}
                          >
                            <div
                              className={`w-5 h-5 rounded-full bg-white transition-transform ${
                                isItemEnabled ? 'translate-x-5' : 'translate-x-0'
                              }`}
                            />
                          </button>
                        </div>
                      )}

                      {item.type === 'select' && item.options && (
                        <div className="flex items-center justify-between w-full gap-2">
                          <span className="text-[11px] text-slate-400">Current Setting:</span>
                          <select
                            value={currentSelectValue}
                            onChange={(e) => handleSelectSetting(item.key, e.target.value)}
                            className="px-2.5 py-1 rounded-lg bg-slate-950 border border-slate-700 text-white text-xs focus:outline-none focus:border-cyan-400"
                          >
                            {item.options.map(opt => (
                              <option key={opt.value} value={opt.value}>{opt.label}</option>
                            ))}
                          </select>
                        </div>
                      )}

                      {item.type === 'button' && (
                        <button
                          type="button"
                          onClick={() => handleActionClick(item)}
                          className="w-full py-1.5 px-3 rounded-xl bg-slate-800 hover:bg-cyan-950 hover:text-cyan-300 border border-slate-700 hover:border-cyan-800 font-semibold transition text-center"
                        >
                          Execute / Inspect
                        </button>
                      )}

                      {item.type === 'text' && (
                        <span className="text-[11px] text-cyan-400 font-medium">Configured in Identity tab</span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="pt-4 border-t border-slate-800 flex justify-between items-center text-xs text-slate-500">
          <div>Profile Handle: <strong className="text-slate-300">@{activeProfile.username}</strong> ({activeProfile.uid.substring(0, 10)})</div>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold transition"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
