import React, { useState, useEffect } from 'react';
import { useAuth } from '../../context/AuthContext';
import { checkUsernameAvailable, validateUsernameFormat } from '../../services/authService';
import { 
  UserCheck, 
  CheckCircle2, 
  AlertCircle, 
  Loader2, 
  Sparkles, 
  ShieldCheck,
  Tag
} from 'lucide-react';

const SUGGESTIONS = ['Manjar', 'BXB_Gamer', 'MyraAI', 'CloudCreator'];

export const OnboardingModal: React.FC = () => {
  const { user, needsOnboarding, completeOnboarding } = useAuth();
  const [username, setUsername] = useState('');
  const [displayName, setDisplayName] = useState('');
  const [bio, setBio] = useState('');
  const [agreed, setAgreed] = useState(false);
  const [checking, setChecking] = useState(false);
  const [isAvailable, setIsAvailable] = useState<boolean | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  // Set initial display name suggestion (optional and fully editable)
  useEffect(() => {
    if (user?.displayName && !displayName) {
      setDisplayName(user.displayName);
    }
  }, [user]);

  // Real-time debounced availability check
  useEffect(() => {
    const trimmed = username.trim();
    if (!trimmed) {
      setIsAvailable(null);
      setError(null);
      return;
    }

    const formatCheck = validateUsernameFormat(trimmed);
    if (!formatCheck.valid) {
      setIsAvailable(false);
      setError(formatCheck.error || 'Invalid username.');
      return;
    }

    setError(null);
    setChecking(true);
    const timer = setTimeout(async () => {
      try {
        const available = await checkUsernameAvailable(trimmed);
        setIsAvailable(available);
        if (!available) {
          setError('Username already taken. Please choose another.');
        } else {
          setError(null);
        }
      } catch {
        setError('Error verifying username. Please check your connection.');
      } finally {
        setChecking(false);
      }
    }, 350);

    return () => clearTimeout(timer);
  }, [username]);

  if (!needsOnboarding || !user) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!username.trim() || isAvailable !== true || !agreed) return;

    setSubmitting(true);
    setError(null);

    try {
      await completeOnboarding(
        username.trim(),
        displayName.trim() || username.trim(),
        bio.trim()
      );
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : 'Username already taken. Please choose another.';
      setError(msg);
      // Preserve user typed value and let them retry as required by Spec A.20
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="w-full max-w-lg glass-panel-glow rounded-3xl p-6 sm:p-8 text-white relative shadow-2xl">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/30">
            <Sparkles className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-xl sm:text-2xl font-bold tracking-tight">Create BXB Creator Handle</h2>
            <p className="text-xs sm:text-sm text-slate-400">
              Pick a unique handle independent of your Google account
            </p>
          </div>
        </div>

        {error && (
          <div className="mb-4 p-3.5 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs sm:text-sm flex items-start gap-2.5">
            <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
              Custom Username (Permanent Identifier) *
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-1/2 -translate-y-1/2 text-cyan-400 font-mono font-bold text-sm">
                @
              </span>
              <input
                type="text"
                required
                maxLength={30}
                value={username}
                onChange={(e) => setUsername(e.target.value.replace(/[^a-zA-Z0-9_]/g, ''))}
                placeholder="e.g. Manjar, BXB_Gamer, CloudCreator"
                className="w-full pl-8 pr-10 py-3 rounded-xl bg-slate-900/90 border border-slate-700/80 focus:border-cyan-400 focus:outline-none focus:ring-1 focus:ring-cyan-400 text-sm font-mono text-white placeholder-slate-500 transition"
              />
              <div className="absolute right-3.5 top-1/2 -translate-y-1/2">
                {checking && <Loader2 className="w-4 h-4 text-cyan-400 animate-spin" />}
                {!checking && isAvailable === true && (
                  <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                )}
                {!checking && isAvailable === false && (
                  <AlertCircle className="w-4 h-4 text-red-400" />
                )}
              </div>
            </div>

            {/* Optional suggestions */}
            <div className="flex items-center gap-1.5 mt-2 flex-wrap text-[11px] text-slate-400">
              <span className="flex items-center gap-1 text-slate-500">
                <Tag className="w-3 h-3" />
                <span>Examples:</span>
              </span>
              {SUGGESTIONS.map((sug) => (
                <button
                  key={sug}
                  type="button"
                  onClick={() => setUsername(sug)}
                  className="px-2 py-0.5 rounded-md bg-slate-800 hover:bg-slate-700 text-cyan-300 font-mono transition"
                >
                  {sug}
                </button>
              ))}
            </div>

            <p className="text-[11px] text-slate-400 mt-1.5">
              3-30 characters (letters, numbers, underscores). Your public creator profile will be at{' '}
              <span className="font-mono text-cyan-400">/u/{username.toLowerCase() || 'username'}</span>
            </p>
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
              Public Display Name (Can be changed anytime)
            </label>
            <input
              type="text"
              required
              maxLength={100}
              value={displayName}
              onChange={(e) => setDisplayName(e.target.value)}
              placeholder="e.g. Alex Henderson"
              className="w-full px-4 py-3 rounded-xl bg-slate-900/90 border border-slate-700/80 focus:border-cyan-400 focus:outline-none focus:ring-1 focus:ring-cyan-400 text-sm text-white placeholder-slate-500 transition"
            />
          </div>

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
              Bio / Tagline (Optional)
            </label>
            <textarea
              rows={2}
              maxLength={500}
              value={bio}
              onChange={(e) => setBio(e.target.value)}
              placeholder="Android dev, APK publisher, tools builder..."
              className="w-full px-4 py-2.5 rounded-xl bg-slate-900/90 border border-slate-700/80 focus:border-cyan-400 focus:outline-none focus:ring-1 focus:ring-cyan-400 text-sm text-white placeholder-slate-500 transition resize-none"
            />
          </div>

          <div className="pt-2">
            <label className="flex items-start gap-3 cursor-pointer group">
              <input
                type="checkbox"
                required
                checked={agreed}
                onChange={(e) => setAgreed(e.target.checked)}
                className="mt-1 w-4 h-4 rounded border-slate-700 text-cyan-500 focus:ring-cyan-400 focus:ring-offset-0 bg-slate-900"
              />
              <span className="text-xs text-slate-400 group-hover:text-slate-300 leading-relaxed">
                I agree to the <strong className="text-slate-200">BXB Cloud Terms of Service</strong> and{' '}
                <strong className="text-slate-200">Content Integrity Policy</strong>. I confirm I will not upload malware or infringed software.
              </span>
            </label>
          </div>

          <div className="pt-3">
            <button
              type="submit"
              disabled={submitting || checking || isAvailable !== true || !agreed}
              className="w-full py-3.5 px-4 rounded-xl font-semibold text-sm bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white shadow-lg shadow-cyan-500/25 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2 transition glow-btn"
            >
              {submitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Reserving Handle &amp; Saving Profile...</span>
                </>
              ) : (
                <>
                  <UserCheck className="w-4 h-4" />
                  <span>Claim Handle &amp; Open Dashboard</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
