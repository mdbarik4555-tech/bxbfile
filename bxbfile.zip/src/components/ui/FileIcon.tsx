import React from 'react';
import { 
  Smartphone, 
  Archive, 
  FileText, 
  Code, 
  Film, 
  Music, 
  Image as ImageIcon, 
  Monitor, 
  Package, 
  FileCode 
} from 'lucide-react';

interface FileIconProps {
  extension: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  className?: string;
}

export const FileIcon: React.FC<FileIconProps> = ({ extension, size = 'md', className = '' }) => {
  const ext = extension.toLowerCase().replace('.', '');

  let Icon = Package;
  let bgGradient = 'from-blue-600 to-cyan-500';
  let badgeLabel = ext.toUpperCase();

  if (ext === 'apk') {
    Icon = Smartphone;
    bgGradient = 'from-emerald-600 to-teal-400';
    badgeLabel = 'APK';
  } else if (['zip', 'rar', '7z', 'tar', 'gz'].includes(ext)) {
    Icon = Archive;
    bgGradient = 'from-amber-600 to-orange-500';
  } else if (['pdf', 'doc', 'docx', 'txt', 'md'].includes(ext)) {
    Icon = FileText;
    bgGradient = 'from-red-600 to-rose-400';
  } else if (['html', 'css', 'js', 'ts', 'jsx', 'tsx', 'json'].includes(ext)) {
    Icon = Code;
    bgGradient = 'from-cyan-600 to-blue-500';
  } else if (['png', 'jpg', 'jpeg', 'webp', 'gif', 'svg'].includes(ext)) {
    Icon = ImageIcon;
    bgGradient = 'from-purple-600 to-indigo-400';
  } else if (['mp4', 'webm', 'mov', 'mkv'].includes(ext)) {
    Icon = Film;
    bgGradient = 'from-violet-600 to-fuchsia-400';
  } else if (['mp3', 'wav', 'ogg', 'flac'].includes(ext)) {
    Icon = Music;
    bgGradient = 'from-pink-600 to-rose-500';
  } else if (['exe', 'msi', 'deb', 'dmg'].includes(ext)) {
    Icon = Monitor;
    bgGradient = 'from-sky-600 to-indigo-600';
  }

  const sizeClasses = {
    sm: 'w-8 h-8 rounded-lg text-xs',
    md: 'w-12 h-12 rounded-xl text-xs',
    lg: 'w-16 h-16 rounded-2xl text-sm',
    xl: 'w-20 h-20 rounded-2xl text-base',
  };

  const iconSizes = {
    sm: 14,
    md: 20,
    lg: 28,
    xl: 36,
  };

  return (
    <div 
      className={`relative flex items-center justify-center shrink-0 bg-gradient-to-br ${bgGradient} text-white shadow-lg ${sizeClasses[size]} ${className}`}
    >
      <Icon size={iconSizes[size]} strokeWidth={2.2} />
      <span className="absolute -bottom-1 -right-1 px-1.5 py-0.5 rounded text-[9px] font-mono font-bold bg-[#090b10] border border-white/20 text-cyan-300 uppercase shadow">
        {badgeLabel.slice(0, 4)}
      </span>
    </div>
  );
};
