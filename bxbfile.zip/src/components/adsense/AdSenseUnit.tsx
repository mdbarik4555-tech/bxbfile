import React from 'react';
import { useSiteConfig } from '../../context/SiteConfigContext';
import { Sparkles, Info } from 'lucide-react';

interface AdSenseUnitProps {
  placement: 'headerLeaderboard' | 'downloadPageBanner' | 'sidebarRectangle' | 'reelsInFeed';
  className?: string;
  previewMode?: boolean;
}

export const AdSenseUnit: React.FC<AdSenseUnitProps> = ({ 
  placement, 
  className = '', 
  previewMode = false 
}) => {
  const { adsense } = useSiteConfig();

  const isEnabled = adsense.enabled && adsense.placements[placement];
  const hasPublisher = Boolean(adsense.publisherId && adsense.publisherId.startsWith('ca-pub-'));

  if (!isEnabled && !previewMode) {
    return null;
  }

  const dimensions = {
    headerLeaderboard: 'w-full max-w-4xl h-24 sm:h-28',
    downloadPageBanner: 'w-full max-w-2xl h-32 sm:h-36',
    sidebarRectangle: 'w-full max-w-xs h-64',
    reelsInFeed: 'w-full max-w-md h-40',
  }[placement];

  const placementTitle = {
    headerLeaderboard: 'Header Leaderboard (728x90 / Responsive)',
    downloadPageBanner: 'Protected Download Page Sponsor Unit',
    sidebarRectangle: 'Medium Rectangle Sidebar (300x250)',
    reelsInFeed: 'Creator Community In-Feed Sponsor',
  }[placement];

  // If live and publisher configured, render real responsive container or script container
  if (isEnabled && hasPublisher && adsense.status === 'active' && !previewMode) {
    return (
      <div className={`my-4 flex flex-col items-center justify-center ${className}`}>
        <div className="text-[10px] uppercase font-mono tracking-wider text-slate-500 mb-1 flex items-center gap-1">
          <span>Advertisement</span>
          <span className="text-[9px] text-slate-600">• Google AdSense</span>
        </div>
        <div className={`${dimensions} rounded-2xl bg-slate-900/40 border border-slate-800/80 p-3 flex flex-col items-center justify-center text-center overflow-hidden relative shadow-inner`}>
          <ins 
            className="adsbygoogle"
            style={{ display: 'block', width: '100%', height: '100%' }}
            data-ad-client={adsense.publisherId}
            data-ad-slot="1234567890"
            data-ad-format="auto"
            data-full-width-responsive="true"
          />
        </div>
      </div>
    );
  }

  // Placeholder or Preview Mode (clearly distinguished to avoid invalid clicks)
  return (
    <div className={`my-4 flex flex-col items-center justify-center ${className}`}>
      <div className="text-[10px] uppercase font-mono tracking-wider text-slate-500 mb-1 flex items-center gap-1.5">
        <span className="px-1.5 py-0.5 rounded bg-cyan-950/80 border border-cyan-800/60 text-cyan-400 font-semibold">
          {previewMode ? 'Live Preview' : 'Ad Placement Placeholder'}
        </span>
        <span className="text-[9px] text-slate-600">Google AdSense Space</span>
      </div>
      <div className={`${dimensions} rounded-2xl bg-gradient-to-br from-slate-900/60 via-slate-950/80 to-slate-900/60 border border-dashed border-slate-700/70 p-4 flex flex-col items-center justify-center text-center relative overflow-hidden group hover:border-cyan-500/50 transition`}>
        <div className="w-8 h-8 rounded-xl bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 flex items-center justify-center mb-2">
          <Sparkles className="w-4 h-4" />
        </div>
        <p className="text-xs font-semibold text-slate-200">{placementTitle}</p>
        <p className="text-[10px] text-slate-500 font-mono mt-0.5">
          {hasPublisher ? `Assigned to ${adsense.publisherId}` : 'Awaiting Publisher ID verification in Owner Dashboard'}
        </p>
        <div className="absolute top-2 right-2 flex items-center gap-1 text-[9px] font-mono text-slate-500">
          <Info className="w-3 h-3" />
          <span>Non-clickable Preview</span>
        </div>
      </div>
    </div>
  );
};
