import React, { useState, useEffect } from 'react';
import { AuthProvider } from './context/AuthContext';
import { SiteConfigProvider, useSiteConfig } from './context/SiteConfigContext';
import { Navbar } from './components/navigation/Navbar';
import { MobileBottomNav } from './components/navigation/MobileBottomNav';
import { OnboardingModal } from './components/ui/OnboardingModal';
import { HomeView } from './views/HomeView';
import { ExploreView } from './views/ExploreView';
import { UploadView } from './views/UploadView';
import { FileDetailView } from './views/FileDetailView';
import { LibraryView } from './views/LibraryView';
import { UserProfileView } from './views/UserProfileView';
import { AdminView } from './views/AdminView';
import { StaticPublishView } from './views/StaticPublishView';
import { CommunityView } from './views/CommunityView';
import { ToolsView } from './views/ToolsView';
import { CloudSyncView } from './views/CloudSyncView';
import { JarvisView } from './views/JarvisView';
import { Multiverse1000View } from './views/Multiverse1000View';
import { HostWebView } from './views/HostWebView';
import { AuthModal } from './components/navigation/AuthModal';
import { useAuth } from './context/AuthContext';
import { FileItem } from './types';
import { AlertTriangle, Megaphone, X, Shield, Lock } from 'lucide-react';

function AppContent() {
  const { authModalOpen, setAuthModalOpen, isOwner, isAdmin } = useAuth();
  const { brand, announcement, maintenanceMode } = useSiteConfig();

  const [currentView, setCurrentView] = useState<
    'home' | 'explore' | 'upload' | 'fileDetail' | 'library' | 'userProfile' | 'admin' | 'sandbox' | 'community' | 'tools' | 'sync' | 'jarvis' | 'options1000' | 'host_web'
  >('home');
  const [routeParam, setRouteParam] = useState<string>('');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [bannerDismissed, setBannerDismissed] = useState(false);

  // Synchronize with URL path on boot and on popstate
  useEffect(() => {
    const parseUrl = () => {
      const path = window.location.pathname;
      if (path.startsWith('/f/')) {
        const id = path.replace('/f/', '').trim();
        if (id) {
          setCurrentView('fileDetail');
          setRouteParam(id);
          return;
        }
      } else if (path.startsWith('/u/')) {
        const username = path.replace('/u/', '').trim();
        if (username) {
          setCurrentView('userProfile');
          setRouteParam(username);
          return;
        }
      } else if (path.startsWith('/w/')) {
        const siteSlug = path.replace('/w/', '').trim();
        setCurrentView('host_web');
        setRouteParam(siteSlug);
        return;
      } else if (path === '/host_web' || path === '/host-web' || path === '/host') {
        setCurrentView('host_web');
      } else if (path === '/explore') {
        setCurrentView('explore');
      } else if (path === '/upload') {
        setCurrentView('upload');
      } else if (path === '/library') {
        setCurrentView('library');
      } else if (path === '/admin') {
        setCurrentView('admin');
      } else if (path === '/sandbox') {
        setCurrentView('sandbox');
      } else if (path === '/community') {
        setCurrentView('community');
      } else if (path === '/tools') {
        setCurrentView('tools');
      } else if (path === '/sync') {
        setCurrentView('sync');
      } else if (path === '/jarvis') {
        setCurrentView('jarvis');
      } else if (path === '/options1000' || path === '/1000-options') {
        setCurrentView('options1000');
      } else {
        setCurrentView('home');
      }
    };

    parseUrl();
    window.addEventListener('popstate', parseUrl);
    return () => window.removeEventListener('popstate', parseUrl);
  }, []);

  // Helper to dynamically update HTML meta tags for SEO and social sharing
  const updateMetaTag = (attrName: string, attrVal: string, content: string) => {
    let el = document.querySelector(`meta[${attrName}="${attrVal}"]`);
    if (!el) {
      el = document.createElement('meta');
      el.setAttribute(attrName, attrVal);
      document.head.appendChild(el);
    }
    el.setAttribute('content', content);
  };

  // Dynamic document title and social meta tags update
  useEffect(() => {
    const siteTitle = brand.siteName || 'bxbfile.bxb';
    let pageTitle = `${siteTitle} — ${brand.tagline || '12 GB File Uploader, Cloud Sync & JARVIS AI Platform'}`;
    let pageDesc = 'Premier 12 GB file uploader, real-time multi-device cloud sync, Android APK distribution, and JARVIS AI Multiverse Command Center on bxbfile.bxb.';

    switch (currentView) {
      case 'fileDetail':
        pageTitle = `File Download & Verification — ${siteTitle}`;
        pageDesc = `Download verified files, APKs, and developer builds with authentic SHA-256 cryptographic checksums on ${siteTitle}.`;
        break;
      case 'userProfile':
        pageTitle = routeParam ? `@${routeParam} — Creator Profile on ${siteTitle}` : `Creator Profile — ${siteTitle}`;
        pageDesc = `View releases, downloads, and developer projects published by @${routeParam || 'creator'} on ${siteTitle}.`;
        break;
      case 'explore':
        pageTitle = `Explore Files, APKs & Builds — ${siteTitle}`;
        pageDesc = `Discover verified Android APKs, developer packages, tools, and media with high-speed direct downloads on ${siteTitle}.`;
        break;
      case 'upload':
        pageTitle = `Publish File & APK (12 GB Engine) — ${siteTitle}`;
        pageDesc = `Publish and distribute large files, APK packages, and media with password protection and countdown gates on ${siteTitle}.`;
        break;
      case 'library':
        pageTitle = `My Cloud Library — ${siteTitle}`;
        pageDesc = `Manage your uploaded binaries, subfolders, versions, and monetization settings on ${siteTitle}.`;
        break;
      case 'admin':
        pageTitle = `Owner Operations Console — ${siteTitle}`;
        pageDesc = `Owner suite for live website editing, branding custom logos, AdSense configuration, and audit logs on ${siteTitle}.`;
        break;
      case 'sandbox':
        pageTitle = `Web Project Sandbox — ${siteTitle}`;
        pageDesc = `Preview and run HTML5, CSS, and client-side web applications safely inside an isolated zero-trust sandbox.`;
        break;
      case 'community':
        pageTitle = `Creator Community Reels & Proof Videos — ${siteTitle}`;
        pageDesc = `Watch creator demonstration videos, APK performance benchmarks, and software showcase reels.`;
        break;
      case 'tools':
        pageTitle = `Plugins & Developer Tools Catalog — ${siteTitle}`;
        pageDesc = `15 developer utilities for APK analysis, SHA-256 verification, source code ZIP export, and diagnostics.`;
        break;
      case 'sync':
        pageTitle = `BXB Cloud Sync Hub — ${siteTitle}`;
        pageDesc = `Real-time multi-device cloud synchronization, device cluster pairing, and .bxb snapshot backups.`;
        break;
      case 'jarvis':
        pageTitle = `JARVIS AI — God of Multiverse Edition — ${siteTitle}`;
        pageDesc = `Command your personal AI assistant with Google Search Grounding, high-clarity voice, and 3D WebGL lab.`;
        break;
      case 'options1000':
        pageTitle = `1,000 Multiverse Options & Master Settings — ${siteTitle}`;
        pageDesc = `Interactive control matrix with exactly 1,000 typed options across storage, sync, AI, and security.`;
        break;
      case 'host_web':
        pageTitle = routeParam ? `${routeParam} — Hosted Website on ${siteTitle}` : `Host Web & HTML Publishing Engine — ${siteTitle}`;
        pageDesc = `Publish and host HTML/JS web projects with instant small short links and sandbox execution on ${siteTitle}.`;
        break;
      default:
        pageTitle = `${siteTitle} — ${brand.tagline || 'JARVIS AI & 12 GB Cloud Platform'}`;
        pageDesc = 'The premier file hosting, APK distribution, real-time cloud sync, and AI multiverse command platform.';
    }

    // Set Document Title
    document.title = pageTitle;

    // Dynamically update standard and OpenGraph / Twitter meta tags
    updateMetaTag('name', 'description', pageDesc);
    updateMetaTag('property', 'og:title', pageTitle);
    updateMetaTag('property', 'og:description', pageDesc);
    updateMetaTag('property', 'og:site_name', siteTitle);
    updateMetaTag('name', 'twitter:card', 'summary_large_image');
    updateMetaTag('name', 'twitter:title', pageTitle);
    updateMetaTag('name', 'twitter:description', pageDesc);

    // If viewing a specific file, dynamically fetch its metadata for rich social sharing cards
    if (currentView === 'fileDetail' && routeParam) {
      fetch(`/api/files/${routeParam}`)
        .then(r => r.ok ? r.json() : null)
        .then(file => {
          if (file) {
            const fTitle = `${file.displayName || file.fileName} — Download on ${siteTitle}`;
            const fDesc = file.description || `Download ${file.fileName} (${file.fileSizeFormatted || '12 GB file'}) verified with SHA-256 checksum on ${siteTitle}.`;
            document.title = fTitle;
            updateMetaTag('name', 'description', fDesc);
            updateMetaTag('property', 'og:title', fTitle);
            updateMetaTag('property', 'og:description', fDesc);
            updateMetaTag('name', 'twitter:title', fTitle);
            updateMetaTag('name', 'twitter:description', fDesc);
            if (file.coverImageUrl || file.customLogoUrl) {
              updateMetaTag('property', 'og:image', file.coverImageUrl || file.customLogoUrl);
              updateMetaTag('name', 'twitter:image', file.coverImageUrl || file.customLogoUrl);
            }
          }
        })
        .catch(() => {});
    }
  }, [currentView, routeParam, brand]);

  const navigate = (view: string, param?: string) => {
    setCurrentView(view as any);
    setRouteParam(param || '');

    // Update browser URL state safely without reloading
    let targetPath = '/';
    if (view === 'fileDetail' && param) {
      targetPath = `/f/${param}`;
    } else if (view === 'userProfile' && param) {
      targetPath = `/u/${param}`;
    } else if (view !== 'home') {
      targetPath = `/${view}`;
    }

    if (window.location.pathname !== targetPath) {
      window.history.pushState({}, '', targetPath);
    }

    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleGlobalSearch = (query: string) => {
    setSearchQuery(query);
    navigate('explore');
  };

  // Maintenance mode gate for public visitors (Owners/Admins can still view)
  const isMaintenanceActive = maintenanceMode.enabled && !isOwner && !isAdmin;

  if (isMaintenanceActive) {
    return (
      <div className="min-h-screen flex flex-col items-center justify-center bg-[#090b10] text-slate-100 p-6 text-center">
        <div className="w-16 h-16 rounded-3xl bg-amber-500/20 border border-amber-500/40 text-amber-400 flex items-center justify-center mx-auto mb-4 animate-bounce">
          <AlertTriangle className="w-8 h-8" />
        </div>
        <h1 className="text-2xl font-bold text-white mb-2">{brand.siteName} Maintenance</h1>
        <p className="text-xs sm:text-sm text-slate-400 max-w-md mx-auto mb-6 leading-relaxed">
          {maintenanceMode.message || 'BXB Cloud is currently undergoing scheduled platform updates. Please check back shortly.'}
        </p>
        <div className="flex items-center gap-3">
          <button
            onClick={() => setAuthModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-slate-900 border border-slate-700 text-xs text-slate-300 hover:text-white flex items-center gap-2"
          >
            <Lock className="w-3.5 h-3.5 text-cyan-400" />
            <span>Owner Access</span>
          </button>
        </div>
        <AuthModal 
          isOpen={authModalOpen} 
          onClose={() => setAuthModalOpen(false)} 
        />
      </div>
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-[#090b10] text-slate-100 selection:bg-cyan-500 selection:text-black">
      {/* Live Announcement Banner (Section F) */}
      {announcement.active && !bannerDismissed && (
        <div className={`px-4 py-2 text-xs font-semibold flex items-center justify-between border-b ${
          announcement.type === 'urgent' 
            ? 'bg-red-600/90 text-white border-red-500' 
            : announcement.type === 'warning'
            ? 'bg-amber-600/90 text-white border-amber-500'
            : 'bg-cyan-950/90 text-cyan-200 border-cyan-800'
        }`}>
          <div className="flex items-center gap-2 mx-auto">
            <Megaphone className="w-4 h-4 shrink-0" />
            <span>{announcement.title && <strong>{announcement.title}: </strong>}{announcement.text}</span>
          </div>
          <button onClick={() => setBannerDismissed(true)} className="hover:opacity-75 p-1">
            <X className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Top Navigation */}
      <Navbar
        currentView={currentView}
        onNavigate={navigate}
        onSearchSubmit={handleGlobalSearch}
      />

      {/* Main View Area */}
      <main className="flex-1 pb-16 lg:pb-0">
        {currentView === 'home' && (
          <HomeView
            onNavigate={navigate}
            onSearch={handleGlobalSearch}
          />
        )}

        {currentView === 'explore' && (
          <ExploreView
            initialSearch={searchQuery}
            initialCategory={routeParam || 'all'}
            onNavigate={navigate}
          />
        )}

        {currentView === 'upload' && (
          <UploadView
            onNavigate={navigate}
            onUploadSuccess={(file: FileItem) => {
              navigate('fileDetail', file.id);
            }}
          />
        )}

        {currentView === 'fileDetail' && (
          <FileDetailView
            fileId={routeParam}
            onNavigate={navigate}
          />
        )}

        {currentView === 'library' && (
          <LibraryView
            onNavigate={navigate}
          />
        )}

        {currentView === 'userProfile' && (
          <UserProfileView
            username={routeParam}
            onNavigate={navigate}
          />
        )}

        {currentView === 'admin' && (
          <AdminView
            onNavigate={navigate}
          />
        )}

        {currentView === 'sandbox' && (
          <StaticPublishView
            onNavigate={navigate}
          />
        )}

        {currentView === 'community' && (
          <CommunityView
            onNavigate={navigate}
          />
        )}

        {currentView === 'tools' && (
          <ToolsView
            onNavigate={navigate}
          />
        )}

        {currentView === 'sync' && (
          <CloudSyncView
            onNavigate={navigate}
          />
        )}

        {currentView === 'jarvis' && (
          <JarvisView
            onNavigate={navigate}
          />
        )}

        {currentView === 'options1000' && (
          <Multiverse1000View
            onNavigate={navigate}
          />
        )}

        {currentView === 'host_web' && (
          <HostWebView
            onNavigate={navigate}
            initialSlug={routeParam}
          />
        )}
      </main>

      {/* Mobile Bottom Navigation */}
      <MobileBottomNav
        currentView={currentView}
        onNavigate={navigate}
      />

      {/* Onboarding Dialog for First-Time Google Sign-Ins */}
      <OnboardingModal />

      {/* Multi-Mode Auth & Login Dialog (0 Login Errors) */}
      <AuthModal 
        isOpen={authModalOpen} 
        onClose={() => setAuthModalOpen(false)} 
      />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <SiteConfigProvider>
        <AppContent />
      </SiteConfigProvider>
    </AuthProvider>
  );
}
