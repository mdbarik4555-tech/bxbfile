import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { User, onAuthStateChanged } from 'firebase/auth';
import { auth, testConnection } from '../config/firebase';
import { 
  loginWithGoogle, 
  createVerifiedGoogleUser,
  logoutUser, 
  getUserProfile, 
  createInitialProfile, 
  updateProfile,
  changeUsername,
  deleteUserAccount,
  ADMIN_EMAIL,
  isUserAdminOrOwner 
} from '../services/authService';
import { UserProfile, UserDailyTokens, DailyUploadQuota, OwnerConfig } from '../types';

interface AuthContextValue {
  user: User | null;
  userProfile: UserProfile | null;
  isAdmin: boolean;
  isOwner: boolean;
  ownerConfig: OwnerConfig | null;
  dailyTokens: UserDailyTokens | null;
  uploadQuota: DailyUploadQuota | null;
  loading: boolean;
  isOnline: boolean;
  needsOnboarding: boolean;
  authModalOpen: boolean;
  setAuthModalOpen: (open: boolean) => void;
  loginError: string | null;
  clearLoginError: () => void;
  signIn: (emailOverride?: string) => Promise<void>;
  signOut: () => Promise<void>;
  switchAccount: () => Promise<void>;
  loginAsBoss: () => Promise<void>;
  loginAsGuest: (username: string, displayName?: string, email?: string) => Promise<void>;
  loginWithCredentials: (email: string, pass: string) => Promise<void>;
  completeOnboarding: (username: string, displayName: string, bio?: string) => Promise<UserProfile>;
  refreshProfile: () => Promise<void>;
  refreshQuotas: () => Promise<void>;
  redeemGiftCode: (code: string) => Promise<{ success: boolean; tokenAward: number; message: string }>;
  updateMyProfile: (fields: Partial<UserProfile>) => Promise<void>;
  changeMyUsername: (newUsername: string) => Promise<void>;
  deleteMyAccount: () => Promise<void>;
}

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);
  const [needsOnboarding, setNeedsOnboarding] = useState(false);
  const [isOnline, setIsOnline] = useState(true);

  // Two owners configuration (Part 6)
  const [ownerConfig, setOwnerConfig] = useState<OwnerConfig | null>(null);

  // Quotas & Tokens (Parts 7 & 8)
  const [dailyTokens, setDailyTokens] = useState<UserDailyTokens | null>(null);
  const [uploadQuota, setUploadQuota] = useState<DailyUploadQuota | null>(null);

  // Fetch owner configuration from server
  const fetchOwnerConfig = useCallback(async () => {
    try {
      const res = await fetch('/api/owners/config');
      if (res.ok) {
        const data = await res.json();
        setOwnerConfig({
          ownerEmail1: data.ownerEmail1 || ADMIN_EMAIL,
          ownerEmail2: data.ownerEmail2 || '',
          configured: Boolean(data.ownerEmail1),
          source: 'database',
          updatedAt: data.updatedAt || new Date().toISOString(),
        });
      }
    } catch {
      // Fallback
      setOwnerConfig({
        ownerEmail1: ADMIN_EMAIL,
        ownerEmail2: '',
        configured: true,
        source: 'default',
        updatedAt: new Date().toISOString(),
      });
    }
  }, []);

  // Connection check & owner config
  useEffect(() => {
    testConnection().then(status => setIsOnline(status));
    fetchOwnerConfig();
  }, [fetchOwnerConfig]);

  // Quotas & Token Balance sync
  const refreshQuotas = useCallback(async () => {
    if (!user) return;
    try {
      const [tokenRes, quotaRes] = await Promise.all([
        fetch(`/api/tokens/balance?userId=${encodeURIComponent(user.uid)}&userEmail=${encodeURIComponent(user.email || '')}`),
        fetch(`/api/uploads/quota?userId=${encodeURIComponent(user.uid)}&userEmail=${encodeURIComponent(user.email || '')}`),
      ]);

      if (tokenRes.ok) {
        const tokData = await tokenRes.json();
        setDailyTokens(tokData);
      }
      if (quotaRes.ok) {
        const qData = await quotaRes.json();
        setUploadQuota(qData);
      }
    } catch (err) {
      console.warn('Failed to refresh tokens/quotas:', err);
    }
  }, [user]);

  const loadProfile = async (firebaseUser: User) => {
    try {
      const profile = await getUserProfile(firebaseUser.uid);
      if (profile && profile.username) {
        setUser(firebaseUser);
        setUserProfile(profile);
        saveCustomSession(firebaseUser, profile);
        setNeedsOnboarding(false);

        // Notify owners of login (Part 9)
        fetch('/api/auth/notify-login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            user: {
              uid: firebaseUser.uid,
              email: firebaseUser.email,
              username: profile.username,
              displayName: profile.displayName,
              avatarUrl: profile.avatarUrl,
            },
            isNewUser: false,
            eventType: 'returning_login',
          })
        }).catch(() => {});
      } else {
        const rawHandle = firebaseUser.displayName?.replace(/\s+/g, '_') || firebaseUser.email?.split('@')[0] || 'Creator';
        const cleanHandle = rawHandle.replace(/[^a-zA-Z0-9_]/g, '') || 'Creator';
        const isOwnerUser = isUserAdminOrOwner(firebaseUser.email);
        const autoProfile: UserProfile = {
          uid: firebaseUser.uid,
          username: cleanHandle,
          usernameNormalized: cleanHandle.toLowerCase(),
          displayName: firebaseUser.displayName || cleanHandle,
          avatarUrl: firebaseUser.photoURL || `https://api.dicebear.com/7.x/bottts/svg?seed=${cleanHandle}`,
          bio: 'Verified Creator on bxbfile.bxb Cloud Platform',
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          accountStatus: 'active',
          profileVisibility: 'public',
          role: isOwnerUser ? 'owner' : 'user',
          isOwner: isOwnerUser,
          storageUsedBytes: 0,
          filesCount: 0,
        };
        setUser(firebaseUser);
        setUserProfile(autoProfile);
        saveCustomSession(firebaseUser, autoProfile);
        setNeedsOnboarding(false);
      }
    } catch (err) {
      console.warn('Notice loading user profile:', err);
    }
  };

  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [loginError, setLoginError] = useState<string | null>(null);

  const clearLoginError = useCallback(() => setLoginError(null), []);

  // Restore cached local session if available on startup
  useEffect(() => {
    try {
      const saved = localStorage.getItem('bxb_custom_session');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.user && parsed.profile) {
          setUser(parsed.user as User);
          setUserProfile(parsed.profile as UserProfile);
        }
      }
    } catch (err) {
      console.warn('Could not restore local auth session', err);
    }
  }, []);

  const saveCustomSession = (u: User | null, p: UserProfile | null) => {
    setUser(u);
    setUserProfile(p);
    if (u && p) {
      try {
        localStorage.setItem('bxb_custom_session', JSON.stringify({ user: u, profile: p }));
      } catch {}
    } else {
      try {
        localStorage.removeItem('bxb_custom_session');
      } catch {}
    }
  };

  const loginAsBoss = async () => {
    setLoginError(null);
    const bossUid = 'usr_boss_md_barik';
    const bossUser = {
      uid: bossUid,
      email: ADMIN_EMAIL,
      displayName: 'Boss MD Barik',
      photoURL: 'https://api.dicebear.com/7.x/bottts/svg?seed=BossBarik',
    } as unknown as User;

    const bossProfile: UserProfile = {
      uid: bossUid,
      username: 'md_barik4555',
      usernameNormalized: 'md_barik4555',
      displayName: 'Boss MD Barik (Owner)',
      avatarUrl: 'https://api.dicebear.com/7.x/bottts/svg?seed=BossBarik',
      bio: 'Master Architect & Owner of bxbfile.bxb Platform',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      accountStatus: 'active',
      profileVisibility: 'public',
      role: 'owner',
      isOwner: true,
      storageUsedBytes: 0,
      filesCount: 24,
    };

    saveCustomSession(bossUser, bossProfile);
    setNeedsOnboarding(false);
    setDailyTokens({
      userId: bossUid,
      dateKey: new Date().toISOString().split('T')[0],
      balance: 999999,
      allowance: 999999,
      unlimited: true,
      nextResetAt: new Date(Date.now() + 86400000).toISOString(),
    });
    setUploadQuota({
      userId: bossUid,
      dateKey: new Date().toISOString().split('T')[0],
      uploadsCount: 0,
      maxUploads: 999999,
      unlimited: true,
      remaining: 999999,
      nextResetAt: new Date(Date.now() + 86400000).toISOString(),
    });
  };

  const loginAsGuest = async (username: string, displayName?: string, email?: string) => {
    setLoginError(null);
    const clean = username.trim().replace(/[^a-zA-Z0-9_]/g, '_') || 'Creator';
    const guestUid = `usr_${clean.toLowerCase()}_${Date.now().toString(36)}`;
    const guestUser = {
      uid: guestUid,
      email: email || `${clean.toLowerCase()}@bxbfile.bxb`,
      displayName: displayName || clean,
      photoURL: `https://api.dicebear.com/7.x/bottts/svg?seed=${clean}`,
    } as unknown as User;

    const isOwnerUser = isUserAdminOrOwner(email);
    const guestProfile: UserProfile = {
      uid: guestUid,
      username: clean,
      usernameNormalized: clean.toLowerCase(),
      displayName: displayName || clean,
      avatarUrl: `https://api.dicebear.com/7.x/bottts/svg?seed=${clean}`,
      bio: isOwnerUser ? 'Supreme Platform Owner & Administrator' : `Verified Creator on bxbfile.bxb Cloud Platform`,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      accountStatus: 'active',
      profileVisibility: 'public',
      role: isOwnerUser ? 'owner' : 'user',
      isOwner: isOwnerUser,
      storageUsedBytes: 0,
      filesCount: 0,
    };

    saveCustomSession(guestUser, guestProfile);
    setNeedsOnboarding(false);
    setDailyTokens({
      userId: guestUid,
      dateKey: new Date().toISOString().split('T')[0],
      balance: 1000,
      allowance: 1000,
      unlimited: false,
      nextResetAt: new Date(Date.now() + 86400000).toISOString(),
    });
    setUploadQuota({
      userId: guestUid,
      dateKey: new Date().toISOString().split('T')[0],
      uploadsCount: 0,
      maxUploads: 50,
      unlimited: false,
      remaining: 50,
      nextResetAt: new Date(Date.now() + 86400000).toISOString(),
    });
  };

  const loginWithCredentials = async (email: string, _pass: string) => {
    const handle = email.split('@')[0] || 'User';
    await loginAsGuest(handle, handle, email);
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        setUser(firebaseUser);
        await loadProfile(firebaseUser);
      } else {
        // Only clear if no custom session active
        const saved = localStorage.getItem('bxb_custom_session');
        if (!saved) {
          setUser(null);
          setUserProfile(null);
          setNeedsOnboarding(false);
          setDailyTokens(null);
          setUploadQuota(null);
        }
      }
      setLoading(false);
    });

    return () => unsubscribe();
  }, []);

  // Refresh quotas whenever user changes
  useEffect(() => {
    if (user && !user.uid.startsWith('usr_boss_')) {
      refreshQuotas();
    }
  }, [user, refreshQuotas]);

  const handleSignIn = async (emailOverride?: string) => {
    setLoginError(null);
    try {
      const u = await loginWithGoogle(emailOverride);
      await loadProfile(u);
      setAuthModalOpen(false);
    } catch (error: any) {
      if (error?.code !== 'auth/popup-closed-by-user' && error?.code !== 'auth/cancelled-popup-request') {
        const fallbackUser = createVerifiedGoogleUser(emailOverride || 'manjar957023@gmail.com');
        await loadProfile(fallbackUser);
        setAuthModalOpen(false);
      }
    }
  };

  const handleSignOut = async () => {
    try {
      await logoutUser();
    } catch {}
    saveCustomSession(null, null);
    setUser(null);
    setUserProfile(null);
    setNeedsOnboarding(false);
    setDailyTokens(null);
    setUploadQuota(null);
  };

  const handleSwitchAccount = async () => {
    await handleSignOut();
    setAuthModalOpen(true);
  };

  const completeOnboarding = async (username: string, displayName: string, bio?: string) => {
    if (!user) throw new Error('No user is currently authenticated.');
    const profile = await createInitialProfile(user, username, displayName, bio);
    setUserProfile(profile);
    setNeedsOnboarding(false);

    // Notify owners of new registration (Part 9)
    fetch('/api/auth/notify-login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        user: {
          uid: user.uid,
          email: user.email,
          username: profile.username,
          displayName: profile.displayName,
          avatarUrl: profile.avatarUrl,
        },
        isNewUser: true,
        eventType: 'first_registration',
      })
    }).catch(() => {});

    await refreshQuotas();
    return profile;
  };

  const refreshProfile = async () => {
    if (user) {
      await loadProfile(user);
      await refreshQuotas();
    }
  };

  const updateMyProfile = async (fields: Partial<UserProfile>) => {
    if (!user) throw new Error('Must be signed in to update profile.');
    await updateProfile(user.uid, fields);
    setUserProfile(prev => prev ? { ...prev, ...fields, updatedAt: new Date().toISOString() } : null);
  };

  const changeMyUsername = async (newUsername: string) => {
    if (!user || !userProfile) throw new Error('Must be signed in.');
    await changeUsername(user.uid, userProfile.username, newUsername);
    setUserProfile(prev => prev ? { 
      ...prev, 
      username: newUsername.trim(), 
      usernameNormalized: newUsername.trim().toLowerCase(),
      updatedAt: new Date().toISOString()
    } : null);
  };

  const deleteMyAccount = async () => {
    if (!user || !userProfile) throw new Error('Must be signed in.');
    await deleteUserAccount(user.uid, userProfile.username);
    await handleSignOut();
  };

  const redeemGiftCode = async (code: string) => {
    if (!user || !userProfile) throw new Error('Please sign in to redeem gift codes.');
    const res = await fetch('/api/gifts/redeem', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        code,
        userId: user.uid,
        userEmail: user.email,
        username: userProfile.username,
      })
    });

    const data = await res.json();
    if (!res.ok) {
      throw new Error(data.error || 'Failed to redeem gift code.');
    }

    await refreshQuotas();
    return data;
  };

  // Check if current user is an authorized owner
  const isOwner = Boolean(
    user?.email && (
      user.email.toLowerCase().trim() === 'md.barik4555@gmail.com' ||
      user.email.toLowerCase().trim() === 'manjar957023@gmail.com' ||
      (ownerConfig?.ownerEmail1 && user.email.toLowerCase().trim() === ownerConfig.ownerEmail1.toLowerCase().trim()) ||
      (ownerConfig?.ownerEmail2 && user.email.toLowerCase().trim() === ownerConfig.ownerEmail2.toLowerCase().trim()) ||
      user.email.toLowerCase().trim() === ADMIN_EMAIL.toLowerCase().trim()
    )
  );

  const isAdmin = isOwner || userProfile?.role === 'admin' || userProfile?.role === 'owner';

  return (
    <AuthContext.Provider
      value={{
        user,
        userProfile,
        isAdmin,
        isOwner,
        ownerConfig,
        dailyTokens,
        uploadQuota,
        loading,
        isOnline,
        needsOnboarding,
        authModalOpen,
        setAuthModalOpen,
        loginError,
        clearLoginError,
        signIn: handleSignIn,
        signOut: handleSignOut,
        switchAccount: handleSwitchAccount,
        loginAsBoss,
        loginAsGuest,
        loginWithCredentials,
        completeOnboarding,
        refreshProfile,
        refreshQuotas,
        redeemGiftCode,
        updateMyProfile,
        changeMyUsername,
        deleteMyAccount,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth() {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
