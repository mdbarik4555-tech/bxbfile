import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { SiteConfig, CountdownDefaultsConfig, SharingDefaultsConfig } from '../types';
import { fetchPublicSiteConfig } from '../services/siteConfigService';

interface SiteConfigContextValue {
  config: SiteConfig | null;
  loading: boolean;
  refreshConfig: () => Promise<void>;
  brand: {
    siteName: string;
    tagline: string;
    logoUrl: string;
    darkLogoUrl: string;
    faviconUrl: string;
    appIconUrl: string;
    primaryAccent: string;
    secondaryAccent: string;
  };
  announcement: {
    active: boolean;
    title: string;
    text: string;
    type: 'info' | 'warning' | 'urgent';
    link?: string;
  };
  countdownDefaults: CountdownDefaultsConfig;
  sharingDefaults: SharingDefaultsConfig;
  adsense: {
    enabled: boolean;
    publisherId: string;
    placements: {
      headerLeaderboard: boolean;
      downloadPageBanner: boolean;
      sidebarRectangle: boolean;
      reelsInFeed: boolean;
    };
    status: string;
  };
  maintenanceMode: {
    enabled: boolean;
    message: string;
  };
}

const defaultBrand = {
  siteName: 'bxbfile.bxb',
  tagline: 'File, APK, Cloud Sync & JARVIS AI Platform',
  logoUrl: '',
  darkLogoUrl: '',
  faviconUrl: '',
  appIconUrl: '',
  primaryAccent: '#06b6d4',
  secondaryAccent: '#3b82f6',
};

const defaultAnnouncement = {
  active: false,
  title: '',
  text: '',
  type: 'info' as const,
  link: '',
};

const defaultAdSense = {
  enabled: false,
  publisherId: '',
  placements: {
    headerLeaderboard: false,
    downloadPageBanner: false,
    sidebarRectangle: false,
    reelsInFeed: false,
  },
  status: 'not_configured',
};

const defaultMaintenance = {
  enabled: false,
  message: '',
};

const defaultCountdownDefaults: CountdownDefaultsConfig = {
  enabled: true,
  defaultSeconds: 15,
  policy: 'all',
  allowOverride: true,
};

const defaultSharingDefaults: SharingDefaultsConfig = {
  defaultVisibility: 'public',
  allowPassword: true,
  allowExpiring: true,
  allowDownloadLimits: true,
};

const SiteConfigContext = createContext<SiteConfigContextValue | undefined>(undefined);

export const SiteConfigProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [config, setConfig] = useState<SiteConfig | null>(null);
  const [loading, setLoading] = useState(true);

  const refreshConfig = useCallback(async () => {
    try {
      const data = await fetchPublicSiteConfig();
      setConfig(data);
      
      // Update dynamic favicon if configured
      if (data.brand?.faviconUrl) {
        let link = document.querySelector("link[rel~='icon']") as HTMLLinkElement;
        if (!link) {
          link = document.createElement('link');
          link.rel = 'icon';
          document.head.appendChild(link);
        }
        link.href = data.brand.faviconUrl;
      }
    } catch (err) {
      console.warn('Could not load site config, using defaults:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    refreshConfig();
  }, [refreshConfig]);

  const value: SiteConfigContextValue = {
    config,
    loading,
    refreshConfig,
    brand: config?.brand || defaultBrand,
    announcement: config?.liveEditor?.announcementBanner || defaultAnnouncement,
    countdownDefaults: config?.countdownDefaults || defaultCountdownDefaults,
    sharingDefaults: config?.sharingDefaults || defaultSharingDefaults,
    adsense: config?.adsense || defaultAdSense,
    maintenanceMode: config?.liveEditor?.maintenanceMode || defaultMaintenance,
  };

  return (
    <SiteConfigContext.Provider value={value}>
      {children}
    </SiteConfigContext.Provider>
  );
};

export const useSiteConfig = () => {
  const context = useContext(SiteConfigContext);
  if (!context) {
    throw new Error('useSiteConfig must be used within a SiteConfigProvider');
  }
  return context;
};
