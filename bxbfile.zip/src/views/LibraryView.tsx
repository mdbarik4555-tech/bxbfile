import React, { useState, useEffect } from 'react';
import { 
  FolderArchive, 
  UploadCloud, 
  Globe, 
  EyeOff, 
  Lock, 
  Trash2, 
  Edit3, 
  Share2, 
  Download, 
  Loader2, 
  HardDrive, 
  TrendingUp, 
  ExternalLink,
  Bookmark,
  User,
  Settings,
  Activity,
  Calendar,
  CheckCircle2,
  FolderPlus,
  Folder,
  FolderOpen,
  MoveRight,
  Search,
  Filter,
  MoreVertical,
  Check,
  Copy,
  X
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { 
  getUserFiles, 
  deleteFile, 
  recordDownloadStart, 
  updateFileMetadata,
  getFolders,
  createFolder,
  deleteFolder,
  moveFileToFolder
} from '../services/fileService';
import { FileItem, FolderItem, VisibilityMode, PublicationStatus } from '../types';
import { FileIcon } from '../components/ui/FileIcon';
import { formatBytes, formatRelativeTime } from '../utils/format';
import { ShareModal } from '../components/files/ShareModal';
import { EditFileModal } from '../components/files/EditFileModal';
import { ProfileSettingsModal } from '../components/profile/ProfileSettingsModal';

interface LibraryViewProps {
  onNavigate: (view: string, param?: string) => void;
}

export const LibraryView: React.FC<LibraryViewProps> = ({ onNavigate }) => {
  const { user, userProfile, signIn } = useAuth();
  const [files, setFiles] = useState<FileItem[]>([]);
  const [folders, setFolders] = useState<FolderItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'all' | VisibilityMode | 'draft'>('all');
  const [activeFolderId, setActiveFolderId] = useState<string | null>(null);
  
  // Folder Creation Modal
  const [showFolderModal, setShowFolderModal] = useState(false);
  const [newFolderName, setNewFolderName] = useState('');
  const [creatingFolder, setCreatingFolder] = useState(false);

  // Move File Modal
  const [movingFile, setMovingFile] = useState<FileItem | null>(null);

  // Search & Filter
  const [searchQuery, setSearchQuery] = useState('');

  const [editingFile, setEditingFile] = useState<FileItem | null>(null);
  const [sharingFile, setSharingFile] = useState<FileItem | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [deletingId, setDeletingId] = useState<string | null>(null);
  const [publishingId, setPublishingId] = useState<string | null>(null);
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [actionBanner, setActionBanner] = useState<{ type: 'success' | 'error'; text: string } | null>(null);

  const fetchUserData = async () => {
    if (!user) return;
    setLoading(true);
    try {
      const [userFiles, userFolders] = await Promise.all([
        getUserFiles(user.uid),
        getFolders(user.uid),
      ]);
      setFiles(userFiles);
      setFolders(userFolders);
    } catch (err) {
      console.error('Error fetching user data:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (user) {
      fetchUserData();
    } else {
      setLoading(false);
    }
  }, [user]);

  const handleCreateFolder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !newFolderName.trim()) return;
    setCreatingFolder(true);
    try {
      const res = await createFolder(user.uid, newFolderName.trim());
      setFolders(prev => [res.folder, ...prev]);
      setNewFolderName('');
      setShowFolderModal(false);
      setActionBanner({ type: 'success', text: `Folder "${res.folder.name}" created successfully!` });
      setTimeout(() => setActionBanner(null), 3000);
    } catch (err: any) {
      setActionBanner({ type: 'error', text: err.message || 'Failed to create folder' });
      setTimeout(() => setActionBanner(null), 4000);
    } finally {
      setCreatingFolder(false);
    }
  };

  const handleDeleteFolder = async (folderId: string) => {
    if (!user) return;
    try {
      await deleteFolder(user.uid, folderId);
      setFolders(prev => prev.filter(f => f.id !== folderId));
      if (activeFolderId === folderId) setActiveFolderId(null);
      setFiles(prev => prev.map(f => f.folderId === folderId ? { ...f, folderId: undefined } : f));
      setActionBanner({ type: 'success', text: 'Folder deleted and files unassigned.' });
      setTimeout(() => setActionBanner(null), 3000);
    } catch {
      setActionBanner({ type: 'error', text: 'Failed to delete folder.' });
      setTimeout(() => setActionBanner(null), 4000);
    }
  };

  const handleMoveFile = async (folderId: string | null) => {
    if (!user || !movingFile) return;
    try {
      await moveFileToFolder(movingFile.id, user.uid, folderId);
      setFiles(prev => prev.map(f => f.id === movingFile.id ? { ...f, folderId: folderId || undefined } : f));
      setMovingFile(null);
      setActionBanner({ type: 'success', text: 'File moved successfully.' });
      setTimeout(() => setActionBanner(null), 3000);
    } catch {
      setActionBanner({ type: 'error', text: 'Failed to move file.' });
      setTimeout(() => setActionBanner(null), 4000);
    }
  };

  const handleDelete = async (file: FileItem) => {
    setDeletingId(file.id);
    try {
      await deleteFile(file);
      setFiles((prev) => prev.filter((f) => f.id !== file.id));
      setActionBanner({ type: 'success', text: `"${file.title}" deleted successfully.` });
      setTimeout(() => setActionBanner(null), 3000);
    } catch (err) {
      setActionBanner({ type: 'error', text: 'Failed to delete file.' });
      setTimeout(() => setActionBanner(null), 4000);
    } finally {
      setDeletingId(null);
    }
  };

  const handlePublishDraft = async (file: FileItem) => {
    setPublishingId(file.id);
    try {
      await updateFileMetadata(file.id, { publicationStatus: 'published' });
      setFiles(prev => prev.map(f => f.id === file.id ? { ...f, publicationStatus: 'published' } : f));
      setActionBanner({ type: 'success', text: `Draft "${file.title}" published publicly!` });
      setTimeout(() => setActionBanner(null), 3000);
    } catch {
      setActionBanner({ type: 'error', text: 'Failed to publish draft.' });
      setTimeout(() => setActionBanner(null), 4000);
    } finally {
      setPublishingId(null);
    }
  };

  const handleCopyLink = (fileId: string) => {
    const url = `${window.location.origin}/f/${fileId}`;
    navigator.clipboard.writeText(url);
    setCopiedId(fileId);
    setTimeout(() => setCopiedId(null), 2500);
  };

  if (!user) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16 text-center animate-fade-in">
        <div className="w-16 h-16 rounded-3xl bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 flex items-center justify-center mx-auto mb-4">
          <FolderArchive className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-white mb-2">Creator Sign-In Required</h2>
        <p className="text-xs sm:text-sm text-slate-400 mb-6">
          Sign in with Google to create a creator handle, organize files into folders, and manage uploads.
        </p>
        <button
          onClick={() => signIn()}
          className="px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs transition inline-flex items-center gap-2 glow-btn"
        >
          <span>Sign In with Google</span>
        </button>
      </div>
    );
  }

  // Filter files
  const filteredFiles = files.filter((f) => {
    // Visibility/draft tab
    let matchesTab = true;
    if (activeTab === 'draft') matchesTab = f.publicationStatus === 'draft';
    else if (activeTab === 'all') matchesTab = f.publicationStatus === 'published' || !f.publicationStatus;
    else matchesTab = f.visibility === activeTab && f.publicationStatus === 'published';

    // Folder filter
    let matchesFolder = true;
    if (activeFolderId) {
      matchesFolder = f.folderId === activeFolderId;
    }

    // Search query
    let matchesSearch = true;
    if (searchQuery.trim()) {
      const q = searchQuery.toLowerCase().trim();
      matchesSearch = 
        f.title.toLowerCase().includes(q) ||
        f.extension.toLowerCase().includes(q) ||
        (f.tags && f.tags.some(t => t.toLowerCase().includes(q)));
    }

    return matchesTab && matchesFolder && matchesSearch;
  });

  const totalBytesUsed = files.reduce((acc, curr) => acc + (curr.fileSize || 0), 0);
  const totalDownloads = files.reduce((acc, curr) => acc + (curr.downloadStartCount || 0), 0);
  const draftFilesCount = files.filter(f => f.publicationStatus === 'draft').length;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in space-y-8">
      {/* Top Banner and Actions */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 uppercase tracking-wider">
              Creator Dashboard
            </span>
            <span className="text-xs text-slate-400 font-mono">@{userProfile?.username || 'creator'}</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white mt-1">My Cloud Library</h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Organize files, manage subfolders, inspect SHA-256 integrity, and configure monetization.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowFolderModal(true)}
            className="py-2.5 px-3.5 rounded-xl font-semibold text-xs bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 flex items-center gap-2 transition"
          >
            <FolderPlus className="w-4 h-4 text-cyan-400" />
            <span>New Folder</span>
          </button>

          <button
            onClick={() => setSettingsOpen(true)}
            className="py-2.5 px-3.5 rounded-xl font-semibold text-xs bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 flex items-center gap-2 transition"
          >
            <Settings className="w-4 h-4 text-slate-400" />
            <span>100 Settings</span>
          </button>

          <button
            onClick={() => onNavigate('upload')}
            className="py-2.5 px-4 rounded-xl font-bold text-xs bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white flex items-center gap-2 transition glow-btn"
          >
            <UploadCloud className="w-4 h-4" />
            <span>Upload File</span>
          </button>
        </div>
      </div>

      {/* Action Notification Banner */}
      {actionBanner && (
        <div className={`px-4 py-2.5 rounded-2xl border text-xs font-medium flex items-center justify-between animate-fade-in ${
          actionBanner.type === 'success'
            ? 'bg-emerald-500/20 border-emerald-500/40 text-emerald-300'
            : 'bg-red-500/20 border-red-500/40 text-red-300'
        }`}>
          <span>{actionBanner.text}</span>
          <button onClick={() => setActionBanner(null)} className="text-slate-400 hover:text-white ml-2">
            &times;
          </button>
        </div>
      )}

      {/* Account Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="glass-panel rounded-2xl p-4 border border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Storage Consumed</span>
            <HardDrive className="w-4 h-4 text-cyan-400" />
          </div>
          <p className="text-xl font-extrabold text-white font-mono">{formatBytes(totalBytesUsed)}</p>
          <p className="text-[10px] text-emerald-400 mt-2 font-mono flex items-center gap-1">
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Unlimited Cloud Storage Engine</span>
          </p>
        </div>

        <div className="glass-panel rounded-2xl p-4 border border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Active Files</span>
            <FolderArchive className="w-4 h-4 text-purple-400" />
          </div>
          <p className="text-xl font-extrabold text-white font-mono">{files.filter(f => f.publicationStatus === 'published').length}</p>
          <p className="text-[10px] text-slate-500 mt-1">Live in public or unlisted mode</p>
        </div>

        <div className="glass-panel rounded-2xl p-4 border border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Folders &amp; Subfolders</span>
            <Folder className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-xl font-extrabold text-white font-mono">{folders.length}</p>
          <p className="text-[10px] text-slate-500 mt-1">Custom organized directories</p>
        </div>

        <div className="glass-panel rounded-2xl p-4 border border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Total Downloads</span>
            <TrendingUp className="w-4 h-4 text-emerald-400" />
          </div>
          <p className="text-xl font-extrabold text-white font-mono">{totalDownloads}</p>
          <p className="text-[10px] text-slate-500 mt-1">Across all your uploaded files</p>
        </div>
      </div>

      {/* SECTION 10: REAL FOLDERS BAR */}
      <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Folder className="w-4 h-4 text-amber-400" />
            <h3 className="text-xs font-bold uppercase text-slate-300">Folders &amp; Organization (Section 10)</h3>
          </div>
          {activeFolderId && (
            <button
              onClick={() => setActiveFolderId(null)}
              className="text-[11px] text-cyan-400 hover:underline"
            >
              Back to Root (All Files)
            </button>
          )}
        </div>

        <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
          <button
            onClick={() => setActiveFolderId(null)}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold flex items-center gap-2 transition whitespace-nowrap ${
              activeFolderId === null
                ? 'bg-cyan-500 text-black font-bold'
                : 'bg-slate-950 text-slate-300 border border-slate-800 hover:border-slate-700'
            }`}
          >
            <FolderArchive className="w-3.5 h-3.5" />
            <span>All Library Files ({files.length})</span>
          </button>

          {folders.map((folder) => {
            const count = files.filter(f => f.folderId === folder.id).length;
            const isSelected = activeFolderId === folder.id;
            return (
              <div
                key={folder.id}
                className={`flex items-center rounded-xl text-xs font-semibold transition whitespace-nowrap border ${
                  isSelected
                    ? 'bg-amber-500 text-black border-amber-400 font-bold'
                    : 'bg-slate-950 text-slate-300 border-slate-800 hover:border-slate-700'
                }`}
              >
                <button
                  onClick={() => setActiveFolderId(folder.id)}
                  className="px-3 py-2 flex items-center gap-2"
                >
                  <FolderOpen className="w-3.5 h-3.5" />
                  <span>{folder.name}</span>
                  <span className={`px-1.5 py-0.2 rounded text-[10px] ${isSelected ? 'bg-black/20 text-black' : 'bg-slate-800 text-slate-400'}`}>
                    {count}
                  </span>
                </button>
                <button
                  onClick={() => handleDeleteFolder(folder.id)}
                  title="Delete Folder"
                  className="px-2 py-2 hover:text-red-400 text-slate-500 transition border-l border-slate-800/60"
                >
                  <Trash2 className="w-3 h-3" />
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* Visibility Tabs & Search Filter */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-3">
        <div className="flex items-center gap-2 overflow-x-auto scrollbar-none">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold shrink-0 transition ${
              activeTab === 'all' ? 'bg-cyan-500 text-black font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            Published ({files.filter(f => f.publicationStatus === 'published').length})
          </button>
          <button
            onClick={() => setActiveTab('public')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold shrink-0 transition flex items-center gap-1.5 ${
              activeTab === 'public' ? 'bg-cyan-500 text-black font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Globe className="w-3.5 h-3.5 text-emerald-400" />
            <span>Public</span>
          </button>
          <button
            onClick={() => setActiveTab('unlisted')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold shrink-0 transition flex items-center gap-1.5 ${
              activeTab === 'unlisted' ? 'bg-cyan-500 text-black font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <EyeOff className="w-3.5 h-3.5 text-amber-400" />
            <span>Unlisted</span>
          </button>
          <button
            onClick={() => setActiveTab('private')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold shrink-0 transition flex items-center gap-1.5 ${
              activeTab === 'private' ? 'bg-cyan-500 text-black font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Lock className="w-3.5 h-3.5 text-rose-400" />
            <span>Private</span>
          </button>
          <button
            onClick={() => setActiveTab('draft')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold shrink-0 transition flex items-center gap-1.5 ${
              activeTab === 'draft' ? 'bg-cyan-500 text-black font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Bookmark className="w-3.5 h-3.5 text-amber-400" />
            <span>Drafts ({draftFilesCount})</span>
          </button>
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Search my files..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-8 pr-3 py-1.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white focus:outline-none focus:border-cyan-400"
          />
        </div>
      </div>

      {/* Files List / Grid */}
      {loading ? (
        <div className="min-h-[30vh] flex flex-col items-center justify-center p-8 text-slate-400 gap-3">
          <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
          <p className="text-xs font-mono">Synchronizing files &amp; folder allocations...</p>
        </div>
      ) : filteredFiles.length === 0 ? (
        <div className="text-center py-16 px-4 rounded-3xl border border-dashed border-slate-800 bg-slate-900/20">
          <FolderArchive className="w-12 h-12 text-slate-600 mx-auto mb-3" />
          <h3 className="text-base font-bold text-white mb-1">No files in this folder or view</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto mb-6">
            Upload a file or drag binaries here to build your cloud library with 12 GB support.
          </p>
          <button
            onClick={() => onNavigate('upload')}
            className="px-5 py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 font-bold text-xs text-white transition inline-flex items-center gap-2 glow-btn"
          >
            <UploadCloud className="w-4 h-4" />
            <span>Upload File Now</span>
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filteredFiles.map((file) => {
            const isDeleting = deletingId === file.id;
            const isPublishing = publishingId === file.id;
            const currentFolder = folders.find(f => f.id === file.folderId);

            return (
              <div
                key={file.id}
                className="glass-panel-glow rounded-2xl p-5 border border-slate-800 hover:border-slate-700 transition flex flex-col justify-between gap-4 group"
              >
                <div>
                  {/* File Header & Icon */}
                  <div className="flex items-start justify-between gap-3 mb-3">
                    <div className="flex items-center gap-3 min-w-0">
                      <FileIcon extension={file.extension} className="w-10 h-10 shrink-0" />
                      <div className="min-w-0">
                        <h3 className="text-sm font-bold text-white truncate group-hover:text-cyan-300 transition">
                          {file.title}
                        </h3>
                        <div className="flex items-center gap-2 text-[11px] text-slate-400 font-mono mt-0.5">
                          <span>{file.extension.toUpperCase()}</span>
                          <span>•</span>
                          <span>{formatBytes(file.fileSize)}</span>
                          {file.version && (
                            <>
                              <span>•</span>
                              <span>v{file.version}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Status Badge */}
                    <div className="shrink-0 flex flex-col items-end gap-1">
                      {file.publicationStatus === 'draft' ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30">
                          Draft
                        </span>
                      ) : file.visibility === 'public' ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 flex items-center gap-1">
                          <Globe className="w-3 h-3" />
                          <span>Public</span>
                        </span>
                      ) : file.visibility === 'unlisted' ? (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1">
                          <EyeOff className="w-3 h-3" />
                          <span>Unlisted</span>
                        </span>
                      ) : (
                        <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-rose-500/20 text-rose-300 border border-rose-500/30 flex items-center gap-1">
                          <Lock className="w-3 h-3" />
                          <span>Private</span>
                        </span>
                      )}

                      {file.isPaid && (
                        <span className="px-1.5 py-0.2 rounded text-[9px] font-bold bg-amber-500/20 text-amber-300 font-mono">
                          ₹{file.price || 49}
                        </span>
                      )}
                    </div>
                  </div>

                  {/* Folder Indicator */}
                  {currentFolder && (
                    <div className="mb-2 inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-slate-900 border border-slate-700 text-[10px] text-amber-300 font-medium">
                      <Folder className="w-3 h-3 text-amber-400" />
                      <span>{currentFolder.name}</span>
                    </div>
                  )}

                  {file.description && (
                    <p className="text-xs text-slate-400 line-clamp-2 leading-relaxed mb-3">
                      {file.description}
                    </p>
                  )}

                  {/* Metadata Stats */}
                  <div className="flex items-center gap-4 text-[11px] text-slate-500 font-mono pt-2 border-t border-slate-800/80">
                    <span className="flex items-center gap-1">
                      <Download className="w-3.5 h-3.5 text-slate-400" />
                      <span>{file.downloadStartCount || 0}</span>
                    </span>
                    <span>•</span>
                    <span>{formatRelativeTime(file.createdAt)}</span>
                  </div>
                </div>

                {/* Actions Toolbar */}
                <div className="pt-3 border-t border-slate-800 flex items-center justify-between gap-1 text-xs">
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleCopyLink(file.id)}
                      className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white transition"
                      title="Copy Share Link"
                    >
                      {copiedId === file.id ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>

                    <button
                      onClick={() => setSharingFile(file)}
                      className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white transition"
                      title="Share Options"
                    >
                      <Share2 className="w-3.5 h-3.5 text-cyan-400" />
                    </button>

                    <button
                      onClick={() => setMovingFile(file)}
                      className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white transition"
                      title="Move to Folder"
                    >
                      <Folder className="w-3.5 h-3.5 text-amber-400" />
                    </button>

                    <button
                      onClick={() => setEditingFile(file)}
                      className="p-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-slate-300 hover:text-white transition"
                      title="Edit Metadata"
                    >
                      <Edit3 className="w-3.5 h-3.5 text-slate-300" />
                    </button>

                    <button
                      onClick={() => handleDelete(file)}
                      disabled={isDeleting}
                      className="p-2 rounded-xl bg-slate-900 hover:bg-red-950/40 text-slate-400 hover:text-red-400 transition"
                      title="Delete File"
                    >
                      {isDeleting ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Trash2 className="w-3.5 h-3.5" />}
                    </button>
                  </div>

                  {file.publicationStatus === 'draft' ? (
                    <button
                      onClick={() => handlePublishDraft(file)}
                      disabled={isPublishing}
                      className="px-3 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-bold text-xs flex items-center gap-1.5 transition"
                    >
                      <span>Publish</span>
                    </button>
                  ) : (
                    <button
                      onClick={() => onNavigate('fileDetail', file.id)}
                      className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold text-xs flex items-center gap-1.5 transition"
                    >
                      <span>View</span>
                      <ExternalLink className="w-3 h-3 text-cyan-400" />
                    </button>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Modal 1: Create Folder */}
      {showFolderModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-sm glass-panel-glow rounded-3xl p-6 border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-white text-sm flex items-center gap-2">
                <FolderPlus className="w-4 h-4 text-cyan-400" />
                <span>Create New Folder</span>
              </h3>
              <button onClick={() => setShowFolderModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleCreateFolder} className="space-y-4 text-xs">
              <div>
                <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">Folder Name</label>
                <input
                  type="text"
                  required
                  value={newFolderName}
                  onChange={(e) => setNewFolderName(e.target.value)}
                  placeholder="e.g. Android APKs or Client Builds"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowFolderModal(false)}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={creatingFolder}
                  className="px-4 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 font-bold text-white transition flex items-center gap-1.5"
                >
                  {creatingFolder && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  <span>Create</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Modal 2: Move File to Folder */}
      {movingFile && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-fade-in">
          <div className="w-full max-w-sm glass-panel-glow rounded-3xl p-6 border border-slate-800 space-y-4 text-xs">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-white text-sm">Move File to Folder</h3>
              <button onClick={() => setMovingFile(null)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-slate-400 truncate">
              Target: <strong className="text-white">{movingFile.title}</strong>
            </p>

            <div className="space-y-1.5 max-h-56 overflow-y-auto">
              <button
                onClick={() => handleMoveFile(null)}
                className={`w-full text-left p-2.5 rounded-xl flex items-center gap-2 transition ${
                  movingFile.folderId === undefined || movingFile.folderId === null
                    ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/40'
                    : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
                }`}
              >
                <FolderArchive className="w-4 h-4" />
                <span>Root Directory (No folder)</span>
              </button>

              {folders.map(fol => (
                <button
                  key={fol.id}
                  onClick={() => handleMoveFile(fol.id)}
                  className={`w-full text-left p-2.5 rounded-xl flex items-center gap-2 transition ${
                    movingFile.folderId === fol.id
                      ? 'bg-cyan-500/20 text-cyan-300 font-bold border border-cyan-500/40'
                      : 'bg-slate-900 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <Folder className="w-4 h-4 text-amber-400" />
                  <span>{fol.name}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Modals */}
      {sharingFile && (
        <ShareModal
          file={sharingFile}
          isOpen={Boolean(sharingFile)}
          onClose={() => setSharingFile(null)}
        />
      )}

      {editingFile && (
        <EditFileModal
          file={editingFile}
          isOpen={Boolean(editingFile)}
          onClose={() => setEditingFile(null)}
          onUpdated={(updated) => {
            setFiles(prev => prev.map(f => f.id === updated.id ? updated : f));
          }}
        />
      )}

      {settingsOpen && (
        <ProfileSettingsModal
          isOpen={settingsOpen}
          onClose={() => setSettingsOpen(false)}
        />
      )}
    </div>
  );
};
