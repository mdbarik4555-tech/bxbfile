import React, { useState, useEffect, useRef } from 'react';
import {
  Mic,
  MicOff,
  Volume2,
  VolumeX,
  Send,
  Sparkles,
  Bot,
  Shield,
  Box,
  Pickaxe,
  Activity,
  Sliders,
  Play,
  Pause,
  RotateCcw,
  AlertTriangle,
  CheckCircle2,
  Lock,
  Eye,
  EyeOff,
  Search,
  Key,
  Layers,
  StopCircle,
  FileCheck,
  Terminal,
  Cpu,
  Flame,
  Radio,
  RefreshCw,
  Copy,
  Check,
  Zap,
  ArrowRight,
  Loader2,
} from 'lucide-react';
import * as THREE from 'three';
import { useAuth } from '../context/AuthContext';
import {
  voiceEngine,
  commandParser,
  secureVault,
  CommandType,
  ParsedCommand,
  getFeatureSeedCatalog,
  FeatureRegistryItem,
  HINDI_ERROR_MESSAGES,
} from '../services/jarvisService';
import { MinecraftValidator, ValidationError } from '../services/minecraftService';
import { cloudSync } from '../services/cloudSyncService';

interface JarvisViewProps {
  onNavigate: (view: string, param?: string) => void;
}

interface ChatMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  command?: ParsedCommand;
  audioPlaying?: boolean;
}

export const JarvisView: React.FC<JarvisViewProps> = ({ onNavigate }) => {
  const { user } = useAuth();
  const [activeConsole, setActiveConsole] = useState<'chat' | 'agent' | '3dlab' | 'minecraft' | 'security' | 'features'>('chat');

  // Voice & Chat State
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: 'msg_welcome',
      role: 'assistant',
      content: 'Greetings, Boss! I am JARVIS AI, powered by GPT-6 & Gemini Multimodal intelligence on BXB File.BXB. How may I assist you today?',
      timestamp: new Date().toLocaleTimeString('en-US'),
    },
  ]);
  const [inputPrompt, setInputPrompt] = useState('');
  const [isListening, setIsListening] = useState(false);
  const [isSpeaking, setIsSpeaking] = useState(false);
  const [interimSpeech, setInterimSpeech] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  const [voiceAutoSpeak, setVoiceAutoSpeak] = useState(true);

  // Agent Mode State
  const [agentTaskInput, setAgentTaskInput] = useState('');
  const [agentPlanning, setAgentPlanning] = useState(false);
  const [currentPlan, setCurrentPlan] = useState<any | null>(null);
  const [approvalModalStep, setApprovalModalStep] = useState<any | null>(null);
  const [agentEmergencyStopped, setAgentEmergencyStopped] = useState(false);
  const [agentLog, setAgentLog] = useState<string[]>([]);

  // 3D Lab State
  const canvasMountRef = useRef<HTMLDivElement>(null);
  const threeStateRef = useRef<{
    renderer?: THREE.WebGLRenderer;
    scene?: THREE.Scene;
    camera?: THREE.PerspectiveCamera;
    meshGroup?: THREE.Group;
    animId?: number;
    rotationActive: boolean;
    wireframe: boolean;
  }>({ rotationActive: true, wireframe: false });
  const [fps, setFps] = useState(60);
  const [polyCount, setPolyCount] = useState({ vertices: 4820, triangles: 3640 });
  const [lightingPreset, setLightingPreset] = useState<'studio' | 'outdoor' | 'dramatic'>('studio');
  const [is3DPlaying, setIs3DPlaying] = useState(true);
  const [dockCollapsed, setDockCollapsed] = useState(false);

  // Minecraft Lab State
  const [mcJsonInput, setMcJsonInput] = useState(`{
  "format_version": 2,
  "header": {
    "name": "BXB Cloud Multiverse Addon",
    "description": "High-performance Bedrock resource pack with verified manifest",
    "uuid": "8a3e9104-b420-41da-a7a2-f90112cb9481",
    "version": [1, 0, 0],
    "min_engine_version": [1, 20, 0]
  },
  "modules": [
    {
      "type": "resources",
      "uuid": "14f2e967-7b81-42cb-b401-44fa8001e712",
      "version": [1, 0, 0]
    }
  ]
}`);
  const [mcValidationResults, setMcValidationResults] = useState<ValidationError[]>([]);
  const [mcChecked, setMcChecked] = useState(false);

  // Security Center State
  const [storedApiKey, setStoredApiKey] = useState<string>('');
  const [keyInput, setKeyInput] = useState('');
  const [securityScore, setSecurityScore] = useState(95);
  const [keyRevealed, setKeyRevealed] = useState(false);
  const [copiedKey, setCopiedKey] = useState(false);

  // Feature Registry
  const [featureSearch, setFeatureSearch] = useState('');
  const [featureFilter, setFeatureFilter] = useState('all');
  const allFeatures = getFeatureSeedCatalog();

  // Load existing API key on mount
  useEffect(() => {
    secureVault.getKey('openai').then(k => {
      if (k) setStoredApiKey(k);
    });
  }, []);

  // 3D Scene Initialization
  useEffect(() => {
    if (activeConsole !== '3dlab' || !canvasMountRef.current) return;

    const container = canvasMountRef.current;
    const width = container.clientWidth || 600;
    const height = container.clientHeight || 420;

    const scene = new THREE.Scene();
    scene.background = new THREE.Color(0x090b10);
    scene.fog = new THREE.FogExp2(0x090b10, 0.035);

    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 100);
    camera.position.set(0, 2.5, 6.5);

    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.outputColorSpace = THREE.SRGBColorSpace;
    renderer.toneMapping = THREE.ACESFilmicToneMapping;
    renderer.toneMappingExposure = 1.15;
    container.replaceChildren(renderer.domElement);

    // Warm Key Light & Cool Hemisphere Light (Three.js Directive)
    const keyLight = new THREE.DirectionalLight(0x00e5ff, 2.4);
    keyLight.position.set(4, 5, 4);
    scene.add(keyLight);

    const hemiLight = new THREE.HemisphereLight(0x40c4ff, 0x0a1628, 1.2);
    scene.add(hemiLight);

    // Contact Shadow Ground Plane
    const groundGeo = new THREE.PlaneGeometry(16, 16);
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x06090f,
      roughness: 0.85,
      metalness: 0.1,
    });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = -1.2;
    scene.add(ground);

    // Procedural Composite 3-12 Part Hero Subject: JARVIS Holographic Multiverse Core
    const group = new THREE.Group();

    // 1. Center Floating Reactor Core
    const coreGeo = new THREE.IcosahedronGeometry(0.85, 2);
    const coreMat = new THREE.MeshStandardMaterial({
      color: 0x00e5ff,
      metalness: 0.9,
      roughness: 0.15,
      emissive: 0x005577,
      emissiveIntensity: 0.6,
    });
    const core = new THREE.Mesh(coreGeo, coreMat);
    group.add(core);

    // 2. Outer Gimbal Orbit Ring 1
    const ring1Geo = new THREE.TorusGeometry(1.4, 0.04, 16, 64);
    const ring1Mat = new THREE.MeshStandardMaterial({
      color: 0x0066ff,
      metalness: 0.95,
      roughness: 0.2,
    });
    const ring1 = new THREE.Mesh(ring1Geo, ring1Mat);
    group.add(ring1);

    // 3. Outer Gimbal Orbit Ring 2
    const ring2Geo = new THREE.TorusGeometry(1.85, 0.035, 16, 64);
    const ring2Mat = new THREE.MeshStandardMaterial({
      color: 0x8a2be2,
      metalness: 0.95,
      roughness: 0.25,
    });
    const ring2 = new THREE.Mesh(ring2Geo, ring2Mat);
    ring2.rotation.x = Math.PI / 3;
    group.add(ring2);

    // 4. Accent Data Nodes
    for (let i = 0; i < 6; i++) {
      const nodeGeo = new THREE.OctahedronGeometry(0.12);
      const nodeMat = new THREE.MeshStandardMaterial({
        color: 0x00ffcc,
        emissive: 0x00e5ff,
        emissiveIntensity: 0.8,
      });
      const node = new THREE.Mesh(nodeGeo, nodeMat);
      const angle = (i / 6) * Math.PI * 2;
      node.position.set(Math.cos(angle) * 1.85, Math.sin(angle) * 0.4, Math.sin(angle) * 1.85);
      group.add(node);
    }

    scene.add(group);

    threeStateRef.current = {
      renderer,
      scene,
      camera,
      meshGroup: group,
      rotationActive: true,
      wireframe: false,
    };

    let lastTime = performance.now();
    let frameCount = 0;

    const animate = (time: number) => {
      frameCount++;
      if (time - lastTime >= 1000) {
        setFps(frameCount);
        frameCount = 0;
        lastTime = time;
      }

      if (threeStateRef.current.rotationActive && group) {
        group.rotation.y += 0.008;
        ring1.rotation.x += 0.012;
        ring2.rotation.y += 0.015;
      }

      renderer.render(scene, camera);
      threeStateRef.current.animId = requestAnimationFrame(animate);
    };

    threeStateRef.current.animId = requestAnimationFrame(animate);

    return () => {
      if (threeStateRef.current.animId) {
        cancelAnimationFrame(threeStateRef.current.animId);
      }
      renderer.dispose();
    };
  }, [activeConsole]);

  const handleSendMessage = async (textToSend?: string) => {
    const text = (textToSend || inputPrompt).trim();
    if (!text || chatLoading) return;

    setInputPrompt('');
    setInterimSpeech('');

    // Check command parser (Section 22)
    const parsed = commandParser.parse(text);

    const userMsg: ChatMessage = {
      id: `msg_${Date.now()}`,
      role: 'user',
      content: text,
      timestamp: new Date().toLocaleTimeString('en-US'),
      command: parsed,
    };

    setMessages(prev => [...prev, userMsg]);
    setChatLoading(true);

    // If voice command had a specialized instant action
    if (parsed.type === CommandType.CLOUD_SYNC) {
      if (user) cloudSync.pushPendingChanges(user.uid);
    }

    try {
      const res = await fetch('/api/jarvis/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: text,
          messages: messages.concat(userMsg).map(m => ({ role: m.role, content: m.content })),
        }),
      });

      const data = await res.json();
      const replyContent = data.content || parsed.speechReplyHi || 'Directive completed successfully, Boss.';

      const assistantMsg: ChatMessage = {
        id: `msg_asst_${Date.now()}`,
        role: 'assistant',
        content: replyContent,
        timestamp: new Date().toLocaleTimeString('en-US'),
      };

      setMessages(prev => [...prev, assistantMsg]);

      // Speak in English with studio clarity if auto-speak enabled
      if (voiceAutoSpeak) {
        voiceEngine.speak(replyContent, {
          lang: 'en-US',
          onEnd: () => setIsSpeaking(false),
        });
        setIsSpeaking(true);
      }
    } catch {
      const fallbackReply = parsed.speechReplyHi || 'Understood, Boss. Processing your command with optimal parameters.';
      const fallbackMsg: ChatMessage = {
        id: `msg_fallback_${Date.now()}`,
        role: 'assistant',
        content: fallbackReply,
        timestamp: new Date().toLocaleTimeString('en-US'),
      };
      setMessages(prev => [...prev, fallbackMsg]);
      if (voiceAutoSpeak) voiceEngine.speak(fallbackReply, { lang: 'en-US' });
    } finally {
      setChatLoading(false);
    }
  };

  const handleStartVoice = () => {
    if (isListening) {
      voiceEngine.stopListening();
      setIsListening(false);
      return;
    }
    voiceEngine.stopSpeaking();
    setIsSpeaking(false);

    voiceEngine.startListening({
      lang: 'en-US',
      onResult: (transcript, isFinal) => {
        setInterimSpeech(transcript);
        if (isFinal) {
          setIsListening(false);
          handleSendMessage(transcript);
        }
      },
      onError: (err) => {
        setIsListening(false);
        setInterimSpeech('');
      },
      onEnd: () => {
        setIsListening(false);
      },
    });
    setIsListening(true);
  };

  const handleStopSpeaking = () => {
    voiceEngine.stopSpeaking();
    setIsSpeaking(false);
  };

  // Agent Mode Task Submission
  const handleStartAgentTask = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!agentTaskInput.trim()) return;

    setAgentPlanning(true);
    setAgentEmergencyStopped(false);
    setAgentLog(prev => [`[${new Date().toLocaleTimeString()}] Task received: "${agentTaskInput}"`, ...prev]);

    try {
      const res = await fetch('/api/jarvis/agent/plan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ taskDescription: agentTaskInput }),
      });
      const plan = await res.json();
      setCurrentPlan(plan);
      setAgentLog(prev => [
        `[${new Date().toLocaleTimeString()}] Plan generated: ${plan.steps.length} sequential steps`,
        ...prev,
      ]);
    } catch {
      setAgentLog(prev => [`[${new Date().toLocaleTimeString()}] Planning failed.`, ...prev]);
    } finally {
      setAgentPlanning(false);
    }
  };

  const handleApproveStep = (step: any) => {
    if (!currentPlan) return;
    setAgentLog(prev => [
      `[${new Date().toLocaleTimeString()}] Step "${step.description}" APPROVED by Boss. Executing...`,
      ...prev,
    ]);
    setCurrentPlan((prev: any) => ({
      ...prev,
      steps: prev.steps.map((s: any) => s.id === step.id ? { ...s, status: 'completed' } : s),
    }));
    setApprovalModalStep(null);
  };

  const handleEmergencyStop = () => {
    setAgentEmergencyStopped(true);
    setCurrentPlan((prev: any) => prev ? { ...prev, status: 'canceled' } : null);
    setApprovalModalStep(null);
    setAgentLog(prev => [`[EMERGENCY STOP] All agent operations aborted by user command.`, ...prev]);
    voiceEngine.speak(HINDI_ERROR_MESSAGES.MSG_STOP, { lang: 'en-US' });
  };

  // Minecraft Validation Run
  const handleValidateMinecraft = () => {
    try {
      const parsed = JSON.parse(mcJsonInput);
      const errors = MinecraftValidator.validateManifest(parsed);
      setMcValidationResults(errors);
      setMcChecked(true);
    } catch (e: any) {
      setMcValidationResults([
        { file: 'manifest.json', line: null, message: `Syntax Error: ${e.message}`, severity: 'error' },
      ]);
      setMcChecked(true);
    }
  };

  // Security Key Store
  const handleSaveApiKey = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!keyInput.trim()) return;
    await secureVault.storeKey('openai', keyInput.trim());
    setStoredApiKey(keyInput.trim());
    setKeyInput('');
    setSecurityScore(100);
  };

  const filteredFeatures = allFeatures.filter(f => {
    const matchesCat = featureFilter === 'all' || f.category === featureFilter;
    const matchesQuery = !featureSearch || f.title.toLowerCase().includes(featureSearch.toLowerCase()) || f.id.toLowerCase().includes(featureSearch.toLowerCase());
    return matchesCat && matchesQuery;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 animate-fade-in text-white space-y-6">
      {/* Top Identity Lockup (Section 1) */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-cyan-500/20 bg-gradient-to-r from-cyan-950/20 via-slate-900/40 to-blue-950/20 p-6 rounded-3xl border">
        <div className="flex items-center gap-4">
          {/* Holographic Arc Reactor Orb (Section 11) */}
          <div
            onClick={handleStartVoice}
            className={`relative w-16 h-16 rounded-2xl flex items-center justify-center cursor-pointer transition-all duration-300 ${
              isSpeaking
                ? 'bg-gradient-to-tr from-cyan-400 to-blue-600 shadow-lg shadow-cyan-400/50 scale-105'
                : isListening
                ? 'bg-gradient-to-tr from-emerald-400 to-teal-500 shadow-lg shadow-emerald-400/50 scale-105'
                : 'bg-slate-900 border border-cyan-500/40 hover:border-cyan-400'
            }`}
          >
            <Bot className={`w-8 h-8 ${isSpeaking || isListening ? 'text-black' : 'text-cyan-400'}`} />
            {isSpeaking && (
              <span className="absolute -inset-1 rounded-2xl border-2 border-cyan-400 animate-ping opacity-50 pointer-events-none"></span>
            )}
          </div>

          <div>
            <div className="flex items-center gap-2">
              <span className="text-xl sm:text-2xl font-black tracking-wider text-white">JARVIS AI</span>
              <span className="text-xs font-bold text-cyan-400 font-mono tracking-widest uppercase">BY BXB CLOUD</span>
              <span className="px-2 py-0.5 rounded text-[10px] font-extrabold bg-gradient-to-r from-amber-500 to-orange-500 text-black uppercase">
                God of Multiverse Edition
              </span>
            </div>
            <p className="text-xs text-slate-400 font-mono mt-0.5">
              YOUR PERSONAL AI COMMAND CENTER &bull; bxbfile.bxb Core
            </p>
          </div>
        </div>

        {/* Console Mode Selector */}
        <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none pb-1">
          {[
            { id: 'chat' as const, label: 'Voice & Chat', icon: Radio },
            { id: 'agent' as const, label: 'Agent Mode', icon: Zap },
            { id: '3dlab' as const, label: '3D Lab', icon: Box },
            { id: 'security' as const, label: 'Security & Vault', icon: Shield },
            { id: 'minecraft' as const, label: 'Minecraft Lab', icon: Pickaxe },
            { id: 'features' as const, label: 'Feature Catalog (200)', icon: Layers },
          ].map(tab => {
            const Icon = tab.icon;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveConsole(tab.id)}
                className={`flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold whitespace-nowrap transition ${
                  activeConsole === tab.id
                    ? 'bg-cyan-500 text-black font-bold shadow-md shadow-cyan-500/30'
                    : 'bg-slate-900/80 text-slate-400 hover:text-white border border-slate-800'
                }`}
              >
                <Icon className="w-3.5 h-3.5" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* CONSOLE 1: VOICE & CHAT (Hindi + English) */}
      {activeConsole === 'chat' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Main Chat Feed (8 cols) */}
          <div className="lg:col-span-8 flex flex-col h-[600px] glass-panel-glow rounded-3xl p-5 border border-cyan-500/30">
            {/* Chat Messages */}
            <div className="flex-1 overflow-y-auto space-y-3.5 pr-2">
              {messages.map(msg => (
                <div
                  key={msg.id}
                  className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  {msg.role === 'assistant' && (
                    <div className="w-8 h-8 rounded-xl bg-cyan-950/90 border border-cyan-500/40 text-cyan-300 flex items-center justify-center shrink-0">
                      <Bot className="w-4 h-4" />
                    </div>
                  )}
                  <div
                    className={`max-w-[85%] rounded-2xl p-4 text-xs leading-relaxed space-y-1.5 shadow-md ${
                      msg.role === 'user'
                        ? 'bg-cyan-600 text-white font-medium border-l-4 border-cyan-300'
                        : 'bg-slate-900/90 text-slate-100 border border-slate-800 border-l-4 border-blue-500'
                    }`}
                  >
                    <p className="whitespace-pre-wrap">{msg.content}</p>
                    <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 font-mono">
                      <span>{msg.timestamp}</span>
                      {msg.role === 'assistant' && (
                        <button
                          onClick={() => voiceEngine.speak(msg.content, { lang: 'en-US' })}
                          className="hover:text-cyan-400 transition"
                          title="Speak reply"
                        >
                          <Volume2 className="w-3.5 h-3.5" />
                        </button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
              {chatLoading && (
                <div className="flex items-center gap-2 text-xs text-cyan-400 font-mono p-3">
                  <RefreshCw className="w-4 h-4 animate-spin" />
                  <span>JARVIS AI thinking (Gemini 3.8 Flash)...</span>
                </div>
              )}
            </div>

            {/* Interim Speech Indicator */}
            {interimSpeech && (
              <div className="p-2.5 rounded-xl bg-cyan-950/60 border border-cyan-500/30 text-xs font-mono text-cyan-300 mb-2 animate-pulse">
                Hearing: "{interimSpeech}"
              </div>
            )}

            {/* Input & Voice Toolbar */}
            <form onSubmit={(e) => { e.preventDefault(); handleSendMessage(); }} className="flex items-center gap-2 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={handleStartVoice}
                className={`p-3 rounded-2xl transition ${
                  isListening
                    ? 'bg-emerald-500 text-black animate-pulse shadow-lg shadow-emerald-500/30'
                    : 'bg-slate-900 border border-slate-700 text-slate-300 hover:text-cyan-400 hover:border-cyan-500'
                }`}
                title={isListening ? 'Stop listening' : 'Start voice prompt (English / US Studio)'}
              >
                {isListening ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
              </button>

              {isSpeaking && (
                <button
                  type="button"
                  onClick={handleStopSpeaking}
                  className="p-3 rounded-2xl bg-red-600 text-white font-bold transition hover:bg-red-500"
                  title="Stop speaking"
                >
                  <StopCircle className="w-5 h-5" />
                </button>
              )}

              <input
                type="text"
                value={inputPrompt}
                onChange={(e) => setInputPrompt(e.target.value)}
                placeholder="Give directive to JARVIS AI (e.g. 'cloud sync', 'protect file', 'time', 'joke')..."
                className="flex-1 px-4 py-3 rounded-2xl bg-slate-950 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-400 font-mono"
              />

              <button
                type="submit"
                disabled={chatLoading || !inputPrompt.trim()}
                className="p-3 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 font-bold text-white transition disabled:opacity-50"
              >
                <Send className="w-5 h-5" />
              </button>
            </form>
          </div>

          {/* Quick Triggers & Command Center Panel (4 cols) */}
          <div className="lg:col-span-4 space-y-4">
            {/* Quick English Commands */}
            <div className="p-5 rounded-3xl glass-panel border border-slate-800 space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-300 flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <span>Quick Voice Triggers (38 Patterns)</span>
              </h3>
              <div className="space-y-1.5 text-xs">
                {[
                  { label: 'Cloud Sync Engine', cmd: 'sync' },
                  { label: 'Cryptographic File Guard', cmd: 'protect file' },
                  { label: 'Current Time & Latency', cmd: 'time' },
                  { label: 'Today Date & Day', cmd: 'date' },
                  { label: 'Weather & Telemetry', cmd: 'weather' },
                  { label: 'JARVIS Capabilities & Help', cmd: 'help' },
                ].map(item => (
                  <button
                    key={item.label}
                    onClick={() => handleSendMessage(item.cmd)}
                    className="w-full text-left p-2.5 rounded-xl bg-slate-900/60 hover:bg-cyan-950/40 hover:text-cyan-300 border border-slate-800/80 font-mono transition flex items-center justify-between"
                  >
                    <span>{item.label}</span>
                    <ArrowRight className="w-3.5 h-3.5 text-slate-500" />
                  </button>
                ))}
              </div>
            </div>

            {/* Voice Settings Switch */}
            <div className="p-4 rounded-2xl bg-slate-900/60 border border-slate-800 text-xs space-y-2">
              <div className="flex items-center justify-between">
                <span className="font-semibold text-slate-300">Auto Speak Replies (TTS)</span>
                <input
                  type="checkbox"
                  checked={voiceAutoSpeak}
                  onChange={(e) => setVoiceAutoSpeak(e.target.checked)}
                  className="w-4 h-4 rounded text-cyan-500 bg-slate-950 border-slate-700"
                />
              </div>
              <p className="text-[10px] text-slate-500">
                Responds using natural studio speech synthesis with Gemini &amp; ChatGPT voice clarity in English.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* CONSOLE 2: AGENT MODE (Section 15) */}
      {activeConsole === 'agent' && (
        <div className="space-y-6">
          <div className="p-6 rounded-3xl glass-panel-glow border border-amber-500/30 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
              <div>
                <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 uppercase">
                  Supervised Autonomy
                </span>
                <h2 className="text-xl font-bold text-white mt-1">JARVIS AI Autonomous Agent Engine</h2>
                <p className="text-xs text-slate-400 mt-0.5">
                  Input a goal in natural language. JARVIS breaks it into structured steps with risk classification and approval gates.
                </p>
              </div>

              <button
                onClick={handleEmergencyStop}
                className="px-4 py-2 rounded-xl bg-red-600 hover:bg-red-500 text-white font-bold text-xs flex items-center gap-2 shadow-lg shadow-red-600/30 transition self-start sm:self-auto active:scale-95"
              >
                <AlertTriangle className="w-4 h-4" />
                <span>Emergency Stop</span>
              </button>
            </div>

            {/* Task Input Form */}
            <form onSubmit={handleStartAgentTask} className="flex gap-2 text-xs">
              <input
                type="text"
                required
                value={agentTaskInput}
                onChange={(e) => setAgentTaskInput(e.target.value)}
                placeholder="e.g. Publish CyberStrike APK, verify SHA-256, and synchronize across devices..."
                className="flex-1 px-4 py-3 rounded-2xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:border-amber-400"
              />
              <button
                type="submit"
                disabled={agentPlanning}
                className="px-6 py-3 rounded-2xl bg-gradient-to-r from-amber-500 to-orange-600 hover:from-amber-400 hover:to-orange-500 font-bold text-white flex items-center gap-2 transition"
              >
                {agentPlanning ? <Loader2 className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
                <span>Plan Task</span>
              </button>
            </form>
          </div>

          {/* Current Plan Steps */}
          {currentPlan && (
            <div className="p-6 rounded-3xl glass-panel border border-slate-800 space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-3">
                <div>
                  <h3 className="font-bold text-white text-sm">{currentPlan.description}</h3>
                  <p className="text-xs text-cyan-400 font-mono">{currentPlan.descriptionHi}</p>
                </div>
                <span className={`px-2.5 py-1 rounded-full text-xs font-bold uppercase ${
                  currentPlan.status === 'completed' ? 'bg-emerald-500/20 text-emerald-300' :
                  currentPlan.status === 'canceled' ? 'bg-red-500/20 text-red-300' : 'bg-amber-500/20 text-amber-300'
                }`}>
                  {currentPlan.status}
                </span>
              </div>

              <div className="space-y-3">
                {currentPlan.steps.map((st: any) => (
                  <div
                    key={st.id}
                    className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
                  >
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-mono text-cyan-400 font-bold">Step {st.order}</span>
                        <span className={`px-2 py-0.2 rounded text-[9px] font-bold uppercase ${
                          st.riskClassification === 'read_only' ? 'bg-emerald-500/20 text-emerald-300' :
                          st.riskClassification === 'reversible' ? 'bg-blue-500/20 text-blue-300' :
                          st.riskClassification === 'sensitive' ? 'bg-amber-500/20 text-amber-300' : 'bg-red-500/20 text-red-300'
                        }`}>
                          {st.riskClassification}
                        </span>
                        <span className="text-slate-500 font-mono">[{st.tool}:{st.action}]</span>
                      </div>
                      <p className="text-white font-medium">{st.description}</p>
                      <p className="text-[11px] text-slate-400">{st.descriptionHi}</p>
                    </div>

                    <div className="shrink-0 flex items-center gap-2">
                      {st.status === 'completed' ? (
                        <span className="flex items-center gap-1 text-emerald-400 font-bold">
                          <CheckCircle2 className="w-4 h-4" />
                          <span>Done</span>
                        </span>
                      ) : st.requiresApproval ? (
                        <button
                          onClick={() => handleApproveStep(st)}
                          className="px-4 py-1.5 rounded-xl bg-amber-500 hover:bg-amber-400 text-black font-bold transition"
                        >
                          Approve Directive
                        </button>
                      ) : (
                        <button
                          onClick={() => handleApproveStep(st)}
                          className="px-3.5 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-semibold transition"
                        >
                          Run
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Action Log Terminal */}
          <div className="p-5 rounded-3xl bg-black border border-slate-800 text-xs font-mono space-y-2">
            <div className="flex items-center justify-between text-slate-500 border-b border-slate-900 pb-2">
              <span className="flex items-center gap-1.5">
                <Terminal className="w-4 h-4 text-cyan-400" />
                <span>Agent Execution Audit Log</span>
              </span>
              <span>audit_active</span>
            </div>
            <div className="max-h-40 overflow-y-auto space-y-1 text-slate-300">
              {agentLog.map((log, i) => (
                <div key={i} className="text-[11px]">{log}</div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* CONSOLE 3: THREE.JS 3D LAB (Section 16 & Three.js Skill) */}
      {activeConsole === '3dlab' && (
        <div className="space-y-4">
          <div className="relative w-full h-[520px] rounded-3xl overflow-hidden border border-cyan-500/30 bg-[#090b10] shadow-2xl">
            {/* Canvas Mount */}
            <div ref={canvasMountRef} className="w-full h-full" />

            {/* Top Left Stats Counter (Zero Occlusion) */}
            <div className="absolute top-4 left-4 p-3 rounded-2xl bg-black/70 backdrop-blur-md border border-slate-800 text-[11px] font-mono space-y-1 z-10">
              <div className="text-cyan-400 font-bold">JARVIS Holographic Multiverse Core</div>
              <div className="text-slate-400">FPS: <strong className="text-emerald-400">{fps}</strong></div>
              <div className="text-slate-400">Polys: <strong className="text-white">{polyCount.triangles}</strong> triangles</div>
              <div className="text-slate-400">Lighting: <strong className="text-purple-400 capitalize">{lightingPreset}</strong></div>
            </div>

            {/* Collapsible Bottom Control Dock (Three.js Skill Directive) */}
            <div
              className={`absolute bottom-4 left-1/2 -translate-x-1/2 w-[90%] max-w-2xl transition-all duration-300 z-10 ${
                dockCollapsed ? 'translate-y-20 opacity-0 pointer-events-none' : 'translate-y-0 opacity-100'
              }`}
            >
              <div className="p-3.5 rounded-2xl bg-slate-950/90 border border-cyan-500/40 backdrop-blur-xl shadow-2xl flex items-center justify-between gap-3 text-xs">
                {/* Lighting Presets */}
                <div className="flex items-center gap-1.5">
                  <span className="text-[10px] text-slate-400 uppercase font-mono">Lighting:</span>
                  {(['studio', 'outdoor', 'dramatic'] as const).map(p => (
                    <button
                      key={p}
                      onClick={() => setLightingPreset(p)}
                      className={`px-2.5 py-1 rounded-lg capitalize transition ${
                        lightingPreset === p ? 'bg-cyan-500 text-black font-bold' : 'text-slate-400 hover:text-white bg-slate-900'
                      }`}
                    >
                      {p}
                    </button>
                  ))}
                </div>

                {/* Rotate & Wireframe controls */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      const next = !threeStateRef.current.rotationActive;
                      threeStateRef.current.rotationActive = next;
                      setIs3DPlaying(next);
                    }}
                    className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white transition"
                    title="Pause / Play Rotation"
                  >
                    {is3DPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
                  </button>
                  <button
                    onClick={() => {
                      if (threeStateRef.current.meshGroup) {
                        threeStateRef.current.meshGroup.rotation.set(0, 0, 0);
                      }
                    }}
                    className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white transition"
                    title="Reset Camera / Rotation"
                  >
                    <RotateCcw className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            </div>

            {/* Collapse / Expand Toggle Button */}
            <button
              onClick={() => setDockCollapsed(!dockCollapsed)}
              className="absolute bottom-2 right-4 text-[10px] text-slate-400 hover:text-white z-20 font-mono"
            >
              {dockCollapsed ? '▴ Show Controls' : '▾ Hide Controls'}
            </button>
          </div>
        </div>
      )}

      {/* CONSOLE 4: SECURITY & VAULT (Section 6 & 13) */}
      {activeConsole === 'security' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Key Vault Card */}
          <div className="p-6 rounded-3xl glass-panel-glow border border-slate-800 space-y-4 text-xs">
            <div className="flex items-center gap-2">
              <Key className="w-5 h-5 text-cyan-400" />
              <div>
                <h3 className="text-sm font-bold text-white">Web Crypto AES-256-GCM Vault</h3>
                <p className="text-[11px] text-slate-400">Stores external AI keys with cryptographic salt &amp; IV</p>
              </div>
            </div>

            {storedApiKey ? (
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
                <div className="flex justify-between items-center text-slate-400">
                  <span>Registered OpenAI Key:</span>
                  <span className="font-mono text-cyan-400 font-bold">
                    {keyRevealed ? storedApiKey : secureVault.maskKey(storedApiKey)}
                  </span>
                </div>
                <div className="flex justify-end gap-2 pt-1">
                  <button
                    onClick={() => setKeyRevealed(!keyRevealed)}
                    className="px-3 py-1 rounded-lg bg-slate-800 text-slate-300 hover:text-white text-[11px]"
                  >
                    {keyRevealed ? 'Hide' : 'Reveal (10s)'}
                  </button>
                  <button
                    onClick={() => {
                      secureVault.storeKey('openai', '');
                      setStoredApiKey('');
                    }}
                    className="px-3 py-1 rounded-lg bg-red-950/40 text-red-300 border border-red-800 text-[11px]"
                  >
                    Delete Key
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSaveApiKey} className="space-y-3">
                <input
                  type="password"
                  required
                  value={keyInput}
                  onChange={(e) => setKeyInput(e.target.value)}
                  placeholder="Enter external API key (sk-...)"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono focus:border-cyan-400 focus:outline-none"
                />
                <button
                  type="submit"
                  className="w-full py-2.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 font-bold text-white transition"
                >
                  Encrypt &amp; Store Key
                </button>
              </form>
            )}
          </div>

          {/* Security Score Card */}
          <div className="p-6 rounded-3xl glass-panel border border-slate-800 space-y-4 text-xs">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-white text-sm flex items-center gap-2">
                <Shield className="w-5 h-5 text-emerald-400" />
                <span>Security Integrity Score</span>
              </h3>
              <span className="text-2xl font-black text-emerald-400 font-mono">{securityScore}/100</span>
            </div>

            <div className="w-full h-2 rounded-full bg-slate-800 overflow-hidden">
              <div className="h-full bg-emerald-400 rounded-full" style={{ width: `${securityScore}%` }} />
            </div>

            <div className="space-y-2 text-[11px] text-slate-400">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Server-Side Gemini API Proxy Active (Zero Key Exposure)</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Zero-Trust Firestore ABAC Security Rules Enforced</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                <span>Web Crypto SHA-256 Binary Tamper Detection Active</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* CONSOLE 5: MINECRAFT LAB (Section 24) */}
      {activeConsole === 'minecraft' && (
        <div className="p-6 rounded-3xl glass-panel-glow border border-slate-800 space-y-4 text-xs">
          <div className="flex items-center gap-2">
            <Pickaxe className="w-5 h-5 text-emerald-400" />
            <div>
              <h3 className="font-bold text-white text-sm">Minecraft Addon &amp; Manifest Validator</h3>
              <p className="text-[11px] text-slate-400">Validates RFC-4122 UUIDs, format version, and path traversal security</p>
            </div>
          </div>

          <textarea
            rows={10}
            value={mcJsonInput}
            onChange={(e) => setMcJsonInput(e.target.value)}
            className="w-full p-4 rounded-2xl bg-black border border-slate-800 font-mono text-cyan-300 text-xs focus:outline-none focus:border-cyan-400"
          />

          <button
            onClick={handleValidateMinecraft}
            className="px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 font-bold text-white transition flex items-center gap-2"
          >
            <FileCheck className="w-4 h-4" />
            <span>Validate Manifest</span>
          </button>

          {mcChecked && (
            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
              <h4 className="font-bold text-white">Validation Results:</h4>
              {mcValidationResults.length === 0 ? (
                <div className="text-emerald-400 font-semibold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Manifest is 100% compliant with Bedrock Engine v2+</span>
                </div>
              ) : (
                <div className="space-y-1">
                  {mcValidationResults.map((err, i) => (
                    <div key={i} className="text-red-400 flex items-center gap-2">
                      <AlertTriangle className="w-3.5 h-3.5" />
                      <span>{err.message}</span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* CONSOLE 6: FEATURE REGISTRY CATALOG (200 Entries) */}
      {activeConsole === 'features' && (
        <div className="space-y-4 text-xs">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-3 p-4 rounded-2xl bg-slate-900/60 border border-slate-800">
            <div className="relative w-full sm:w-72">
              <Search className="w-4 h-4 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Search 200 features..."
                value={featureSearch}
                onChange={(e) => setFeatureSearch(e.target.value)}
                className="w-full pl-9 pr-3 py-1.5 rounded-xl bg-slate-950 border border-slate-800 text-white focus:outline-none focus:border-cyan-400"
              />
            </div>
            <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto scrollbar-none">
              {(['all', 'core', 'ai', 'voice', 'sync', '3d', 'security'] as const).map(cat => (
                <button
                  key={cat}
                  onClick={() => setFeatureFilter(cat)}
                  className={`px-2.5 py-1 rounded-lg capitalize transition ${
                    featureFilter === cat ? 'bg-cyan-500 text-black font-bold' : 'text-slate-400 bg-slate-900'
                  }`}
                >
                  {cat}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 max-h-[500px] overflow-y-auto pr-1">
            {filteredFeatures.map(item => (
              <div key={item.id} className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-mono text-cyan-400 text-[10px] font-bold block">{item.id}</span>
                  <span className="font-bold text-white text-xs">{item.title}</span>
                </div>
                <span className="px-2 py-0.5 rounded text-[9px] font-bold bg-emerald-500/20 text-emerald-300 uppercase">
                  {item.status}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
