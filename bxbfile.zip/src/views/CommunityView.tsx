import React, { useState, useEffect } from 'react';
import { 
  Film, 
  Heart, 
  MessageSquare, 
  Share2, 
  Sparkles, 
  CheckCircle2, 
  ExternalLink, 
  Send, 
  Plus, 
  Loader2, 
  Volume2, 
  VolumeX, 
  Play, 
  Pause,
  Download,
  AlertTriangle,
  X
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { getReels, createReel, toggleLikeReel, commentOnReel } from '../services/fileService';
import { ReelItem, ReelComment } from '../types';
import { formatRelativeTime } from '../utils/format';

interface CommunityViewProps {
  onNavigate: (view: string, param?: string) => void;
}

export const CommunityView: React.FC<CommunityViewProps> = ({ onNavigate }) => {
  const { user, userProfile, signIn } = useAuth();
  const [reels, setReels] = useState<ReelItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeReelIndex, setActiveReelIndex] = useState(0);
  
  // Post Reel Modal
  const [showPostModal, setShowPostModal] = useState(false);
  const [reelTitle, setReelTitle] = useState('');
  const [reelDesc, setReelDesc] = useState('');
  const [videoUrl, setVideoUrl] = useState('');
  const [thumbnailUrl, setThumbnailUrl] = useState('');
  const [linkedFileTitle, setLinkedFileTitle] = useState('');
  const [hasProofBadge, setHasProofBadge] = useState(true);
  const [posting, setPosting] = useState(false);

  // Comments State
  const [activeCommentReelId, setActiveCommentReelId] = useState<string | null>(null);
  const [comments, setComments] = useState<ReelComment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [submittingComment, setSubmittingComment] = useState(false);

  // Playback state
  const [isPlaying, setIsPlaying] = useState(true);
  const [isMuted, setIsMuted] = useState(true);
  const [reelError, setReelError] = useState<string | null>(null);

  const fetchReels = async () => {
    setLoading(true);
    try {
      const data = await getReels();
      setReels(data);
    } catch {
      // fallback
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchReels();
  }, []);

  const handleToggleLike = async (reel: ReelItem) => {
    if (!user) {
      await signIn();
      return;
    }
    try {
      const res = await toggleLikeReel(reel.id, user.uid);
      setReels(prev => prev.map(r => r.id === reel.id ? { 
        ...r, 
        likesCount: res.likesCount,
        likedBy: res.liked ? [...(r.likedBy || []), user.uid] : (r.likedBy || []).filter(id => id !== user.uid)
      } : r));
    } catch {
      // ignore
    }
  };

  const handlePostReel = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !userProfile) {
      await signIn();
      return;
    }
    if (!videoUrl.trim() || !reelTitle.trim()) return;

    setPosting(true);
    try {
      const res = await createReel({
        creatorUid: user.uid,
        creatorUsername: userProfile.username,
        creatorDisplayName: userProfile.displayName,
        creatorAvatar: userProfile.avatarUrl,
        title: reelTitle.trim(),
        description: reelDesc.trim(),
        videoUrl: videoUrl.trim(),
        thumbnailUrl: thumbnailUrl.trim() || undefined,
        proofBadge: hasProofBadge,
        associatedFileTitle: linkedFileTitle.trim() || undefined,
      });

      setReels(prev => [res.reel, ...prev]);
      setShowPostModal(false);
      setReelTitle('');
      setReelDesc('');
      setVideoUrl('');
      setThumbnailUrl('');
      setLinkedFileTitle('');
    } catch (err: any) {
      setReelError(err.message || 'Failed to post reel');
      setTimeout(() => setReelError(null), 4000);
    } finally {
      setPosting(false);
    }
  };

  const handleOpenComments = (reel: ReelItem) => {
    setActiveCommentReelId(reel.id);
    // Load sample or real comments
    setComments([
      {
        id: 'c1',
        reelId: reel.id,
        authorUid: 'dev1',
        authorUsername: 'CloudCreator',
        content: 'Verified this APK! The SHA-256 matches the release tag. Smooth 60 FPS.',
        createdAt: new Date(Date.now() - 3600000).toISOString(),
      }
    ]);
  };

  const handleAddComment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !userProfile || !activeCommentReelId || !newComment.trim()) return;

    setSubmittingComment(true);
    try {
      const res = await commentOnReel(activeCommentReelId, {
        authorUid: user.uid,
        authorUsername: userProfile.username,
        authorAvatar: userProfile.avatarUrl,
        content: newComment.trim(),
      });

      setComments(prev => [...prev, res.comment]);
      setReels(prev => prev.map(r => r.id === activeCommentReelId ? {
        ...r,
        commentsCount: (r.commentsCount || 0) + 1
      } : r));
      setNewComment('');
    } catch {
      setReelError('Failed to post comment');
      setTimeout(() => setReelError(null), 4000);
    } finally {
      setSubmittingComment(false);
    }
  };

  const currentReel = reels[activeReelIndex] || reels[0];

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-6 animate-fade-in text-white space-y-6">
      {/* Header Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 uppercase tracking-wider">
              Section 12 Community
            </span>
            <span className="text-xs text-slate-400 font-mono">Proof Videos &amp; APK Reels</span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1 flex items-center gap-2">
            <Film className="w-6 h-6 text-cyan-400" />
            <span>Creator Community Reels</span>
          </h1>
          <p className="text-xs text-slate-400 mt-0.5">
            Watch creator proof videos, gameplay demonstrations, and software walkthroughs.
          </p>
        </div>

        <button
          onClick={() => setShowPostModal(true)}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 font-bold text-xs text-white flex items-center gap-2 transition glow-btn self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" />
          <span>Publish Proof Video</span>
        </button>
      </div>

      {reelError && (
        <div className="p-3 rounded-2xl bg-red-500/20 border border-red-500/40 text-red-300 text-xs font-semibold flex items-center justify-between animate-fade-in">
          <span>{reelError}</span>
          <button onClick={() => setReelError(null)} className="text-slate-400 hover:text-white">&times;</button>
        </div>
      )}

      {loading ? (
        <div className="py-24 text-center text-slate-400">
          <Loader2 className="w-8 h-8 animate-spin text-cyan-400 mx-auto mb-2" />
          <p className="text-xs font-mono">Streaming creator video feeds...</p>
        </div>
      ) : reels.length === 0 ? (
        <div className="py-20 text-center rounded-3xl bg-slate-900/40 border border-slate-800 text-slate-400 space-y-2">
          <Film className="w-12 h-12 text-slate-600 mx-auto mb-2" />
          <h3 className="text-sm font-bold text-white">No Reels Posted Yet</h3>
          <p className="text-xs max-w-sm mx-auto">Be the first to share an APK demonstration or software showcase video.</p>
        </div>
      ) : (
        /* Vertical & Desktop Reel Feed */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Main Reel Player (Center) */}
          <div className="lg:col-span-8 bg-black rounded-3xl overflow-hidden border border-slate-800 relative shadow-2xl flex flex-col justify-center items-center min-h-[520px]">
            {currentReel && (
              <div className="relative w-full h-[520px] bg-slate-950 flex items-center justify-center overflow-hidden">
                <video
                  key={currentReel.id}
                  src={currentReel.videoUrl}
                  poster={currentReel.thumbnailUrl}
                  autoPlay={isPlaying}
                  loop
                  muted={isMuted}
                  playsInline
                  className="w-full h-full object-contain"
                />

                {/* Overlaid Controls Top */}
                <div className="absolute top-4 right-4 flex items-center gap-2 z-10">
                  <button
                    onClick={() => setIsMuted(!isMuted)}
                    className="p-2 rounded-full bg-black/60 backdrop-blur-md text-white hover:bg-black/80 transition"
                  >
                    {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                  </button>
                  <button
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="p-2 rounded-full bg-black/60 backdrop-blur-md text-white hover:bg-black/80 transition"
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </button>
                </div>

                {/* Overlaid Creator Info Bottom */}
                <div className="absolute bottom-0 inset-x-0 p-6 bg-gradient-to-t from-black/95 via-black/60 to-transparent z-10 space-y-2">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-cyan-600 border border-white/20 overflow-hidden flex items-center justify-center font-bold text-xs text-white">
                      {currentReel.creatorAvatar ? (
                        <img src={currentReel.creatorAvatar} alt="" className="w-full h-full object-cover" />
                      ) : (
                        <span>{currentReel.creatorUsername.charAt(0).toUpperCase()}</span>
                      )}
                    </div>
                    <div>
                      <div className="font-bold text-white text-xs flex items-center gap-1.5">
                        <span>@{currentReel.creatorUsername}</span>
                        {currentReel.proofBadge && (
                          <span className="px-1.5 py-0.2 rounded text-[9px] font-extrabold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 uppercase flex items-center gap-0.5">
                            <CheckCircle2 className="w-2.5 h-2.5" />
                            <span>Proof Verified</span>
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  <h3 className="font-bold text-white text-sm">{currentReel.title}</h3>
                  <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">{currentReel.description}</p>

                  {currentReel.associatedFileTitle && (
                    <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-xl bg-cyan-950/80 border border-cyan-800 text-xs font-mono text-cyan-300">
                      <Download className="w-3.5 h-3.5 text-cyan-400" />
                      <span>Attached Binary: {currentReel.associatedFileTitle}</span>
                    </div>
                  )}
                </div>

                {/* Action Sidebar on Right */}
                <div className="absolute right-4 bottom-20 flex flex-col items-center gap-4 z-20">
                  {/* Like Button */}
                  <button
                    onClick={() => handleToggleLike(currentReel)}
                    className="flex flex-col items-center gap-1 group"
                  >
                    <div className={`w-11 h-11 rounded-full flex items-center justify-center backdrop-blur-md transition ${
                      currentReel.likedBy?.includes(user?.uid || '')
                        ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/40'
                        : 'bg-black/60 text-white hover:bg-black/80'
                    }`}>
                      <Heart className={`w-5 h-5 ${currentReel.likedBy?.includes(user?.uid || '') ? 'fill-current' : ''}`} />
                    </div>
                    <span className="text-[11px] font-bold text-white font-mono">{currentReel.likesCount || 0}</span>
                  </button>

                  {/* Comment Button */}
                  <button
                    onClick={() => handleOpenComments(currentReel)}
                    className="flex flex-col items-center gap-1 group"
                  >
                    <div className="w-11 h-11 rounded-full bg-black/60 backdrop-blur-md text-white hover:bg-black/80 flex items-center justify-center transition">
                      <MessageSquare className="w-5 h-5" />
                    </div>
                    <span className="text-[11px] font-bold text-white font-mono">{currentReel.commentsCount || 0}</span>
                  </button>
                </div>
              </div>
            )}
          </div>

          {/* Reel Playlist / Thumbnails (Right Column) */}
          <div className="lg:col-span-4 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">More Creator Showcases</h3>
            <div className="space-y-2 max-h-[520px] overflow-y-auto pr-1">
              {reels.map((r, idx) => (
                <div
                  key={r.id}
                  onClick={() => setActiveReelIndex(idx)}
                  className={`p-3 rounded-2xl border transition cursor-pointer flex items-center gap-3 ${
                    activeReelIndex === idx
                      ? 'bg-cyan-950/40 border-cyan-500/50 shadow-md shadow-cyan-500/10'
                      : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                  }`}
                >
                  <div className="w-16 h-14 rounded-xl bg-slate-950 overflow-hidden shrink-0 relative">
                    {r.thumbnailUrl ? (
                      <img src={r.thumbnailUrl} alt="" className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center bg-cyan-900/30 text-cyan-400">
                        <Film className="w-5 h-5" />
                      </div>
                    )}
                    <span className="absolute bottom-1 right-1 px-1 rounded text-[8px] font-mono bg-black/80 text-white">
                      {r.duration || 15}s
                    </span>
                  </div>

                  <div className="min-w-0 flex-1">
                    <h4 className="text-xs font-bold text-white truncate">{r.title}</h4>
                    <p className="text-[11px] text-slate-400 font-mono">@{r.creatorUsername}</p>
                    <div className="flex items-center gap-2 text-[10px] text-slate-500 font-mono mt-0.5">
                      <span>{r.likesCount} likes</span>
                      <span>•</span>
                      <span>{r.commentsCount} comments</span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Modal: Comments Drawer */}
      {activeCommentReelId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-md glass-panel-glow rounded-3xl p-6 border border-slate-800 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-sm flex items-center gap-2">
                <MessageSquare className="w-4 h-4 text-cyan-400" />
                <span>Community Discussion</span>
              </h3>
              <button onClick={() => setActiveCommentReelId(null)} className="text-slate-400 hover:text-white">
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="space-y-3 max-h-60 overflow-y-auto pr-1">
              {comments.map((c) => (
                <div key={c.id} className="p-3 rounded-xl bg-slate-900/80 border border-slate-800 space-y-1">
                  <div className="flex items-center justify-between text-[11px]">
                    <span className="font-bold text-cyan-400 font-mono">@{c.authorUsername}</span>
                    <span className="text-slate-500 font-mono">{formatRelativeTime(c.createdAt)}</span>
                  </div>
                  <p className="text-slate-300 leading-relaxed">{c.content}</p>
                </div>
              ))}
            </div>

            <form onSubmit={handleAddComment} className="flex gap-2 pt-2 border-t border-slate-800">
              <input
                type="text"
                required
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                placeholder="Share your thought or review..."
                className="flex-1 px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:border-cyan-400"
              />
              <button
                type="submit"
                disabled={submittingComment}
                className="px-3.5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 font-bold text-white transition flex items-center gap-1"
              >
                {submittingComment ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Modal: Publish Reel */}
      {showPostModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-lg glass-panel-glow rounded-3xl p-6 sm:p-8 border border-slate-800 space-y-4 text-xs">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3">
              <h3 className="font-bold text-white text-base flex items-center gap-2">
                <Film className="w-5 h-5 text-cyan-400" />
                <span>Publish Creator Showcase Reel</span>
              </h3>
              <button onClick={() => setShowPostModal(false)} className="text-slate-400 hover:text-white">
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handlePostReel} className="space-y-4">
              <div>
                <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">Reel Title</label>
                <input
                  type="text"
                  required
                  value={reelTitle}
                  onChange={(e) => setReelTitle(e.target.value)}
                  placeholder="e.g. CyberStrike APK 60FPS Showcase"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">Video Stream URL</label>
                <input
                  type="url"
                  required
                  value={videoUrl}
                  onChange={(e) => setVideoUrl(e.target.value)}
                  placeholder="https://...mp4 or CDN video link"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">Poster Thumbnail URL</label>
                <input
                  type="url"
                  value={thumbnailUrl}
                  onChange={(e) => setThumbnailUrl(e.target.value)}
                  placeholder="https://...jpg or cover preview"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">Description &amp; Highlights</label>
                <textarea
                  rows={2}
                  value={reelDesc}
                  onChange={(e) => setReelDesc(e.target.value)}
                  placeholder="What features or performance does this proof demonstrate?"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900 border border-slate-800">
                <span className="text-slate-300 font-semibold">Mark as Cryptographically Verified Proof:</span>
                <input
                  type="checkbox"
                  checked={hasProofBadge}
                  onChange={(e) => setHasProofBadge(e.target.checked)}
                  className="w-4 h-4 rounded text-cyan-500 bg-slate-950 border-slate-700"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowPostModal(false)}
                  className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={posting}
                  className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 font-bold text-white transition flex items-center gap-1.5"
                >
                  {posting && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  <span>Publish to Community</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
