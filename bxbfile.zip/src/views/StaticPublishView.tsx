import React, { useState } from 'react';
import { 
  Layers, 
  UploadCloud, 
  ShieldCheck, 
  Play, 
  ExternalLink, 
  Code2, 
  AlertCircle, 
  Check, 
  Monitor, 
  Smartphone,
  Info
} from 'lucide-react';

interface StaticPublishViewProps {
  onNavigate: (view: string, param?: string) => void;
}

export const StaticPublishView: React.FC<StaticPublishViewProps> = ({ onNavigate }) => {
  const [htmlCode, setHtmlCode] = useState(`<!DOCTYPE html>
<html>
<head>
  <style>
    body {
      font-family: system-ui, sans-serif;
      background: linear-gradient(135deg, #090b10, #131b2e);
      color: #fff;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      height: 100vh;
      margin: 0;
      text-align: center;
    }
    .card {
      background: rgba(255, 255, 255, 0.05);
      border: 1px solid rgba(0, 210, 255, 0.3);
      border-radius: 20px;
      padding: 30px;
      box-shadow: 0 0 30px rgba(0, 210, 255, 0.2);
    }
    h1 { color: #00d2ff; margin-bottom: 8px; }
    p { color: #94a3b8; font-size: 14px; }
    button {
      background: #00d2ff;
      color: #000;
      font-weight: bold;
      border: none;
      padding: 10px 20px;
      border-radius: 10px;
      cursor: pointer;
      margin-top: 15px;
    }
  </style>
</head>
<body>
  <div class="card">
    <h1>BXB Web Runner</h1>
    <p>This HTML/JS bundle is running in a zero-trust sandbox.</p>
    <p id="status" style="color:#06b6d4;font-size:12px;margin-top:10px;font-family:monospace;"></p>
    <button onclick="document.getElementById('status').innerText='Sandbox Script Executed Successfully!'">Interactive Test</button>
  </div>
</body>
</html>`);

  const [activeCode, setActiveCode] = useState(htmlCode);
  const [device, setDevice] = useState<'desktop' | 'mobile'>('desktop');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 text-cyan-400 font-mono text-xs uppercase tracking-wider mb-1">
          <Layers className="w-4 h-4" />
          <span>Isolated Project Runner</span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          Web Project Sandbox &amp; Distribution
        </h1>
        <p className="text-xs sm:text-sm text-slate-400 max-w-2xl">
          Preview static HTML, CSS, and client-side JavaScript applications safely inside an isolated sandboxed iframe with strict security boundaries.
        </p>
      </div>

      <div className="p-4 rounded-2xl bg-cyan-950/30 border border-cyan-800/40 text-xs text-cyan-300 flex items-start gap-3">
        <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
        <div className="space-y-1">
          <p className="font-semibold">BXB Cloud Sandboxing Constitution:</p>
          <p className="text-slate-300 text-[11px] leading-relaxed">
            Uploaded projects are executed under sandboxed iframes (<code className="font-mono text-cyan-300">sandbox="allow-scripts"</code>) without access to parent authentication tokens, session cookies, or server-side service credentials.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Editor side */}
        <div className="glass-panel rounded-3xl p-5 space-y-4 flex flex-col">
          <div className="flex items-center justify-between">
            <span className="text-xs font-bold text-slate-300 flex items-center gap-1.5 font-mono">
              <Code2 className="w-4 h-4 text-cyan-400" />
              <span>Project Entrypoint (index.html)</span>
            </span>
            <button
              onClick={() => setActiveCode(htmlCode)}
              className="px-3.5 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-semibold text-xs flex items-center gap-1.5 transition"
            >
              <Play className="w-3.5 h-3.5 fill-black" />
              <span>Run in Sandbox</span>
            </button>
          </div>

          <textarea
            rows={18}
            value={htmlCode}
            onChange={(e) => setHtmlCode(e.target.value)}
            className="w-full flex-1 p-4 rounded-2xl bg-[#05070a] border border-slate-800 text-xs font-mono text-cyan-300 focus:outline-none focus:border-cyan-500/60 resize-none leading-relaxed"
          />

          <div className="flex items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-800">
            <span>Ready to publish this project bundle?</span>
            <button
              onClick={() => onNavigate('upload')}
              className="text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1"
            >
              <span>Upload to BXB Cloud</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Live Sandboxed Runner */}
        <div className="glass-panel-glow rounded-3xl p-5 space-y-4 flex flex-col">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
              <span className="text-xs font-bold text-white">Live Sandboxed Viewport</span>
            </div>

            <div className="flex items-center bg-slate-900 rounded-xl p-1 border border-slate-800">
              <button
                onClick={() => setDevice('desktop')}
                className={`p-1.5 rounded-lg text-xs transition ${
                  device === 'desktop' ? 'bg-cyan-500/20 text-cyan-300' : 'text-slate-400'
                }`}
              >
                <Monitor className="w-4 h-4" />
              </button>
              <button
                onClick={() => setDevice('mobile')}
                className={`p-1.5 rounded-lg text-xs transition ${
                  device === 'mobile' ? 'bg-cyan-500/20 text-cyan-300' : 'text-slate-400'
                }`}
              >
                <Smartphone className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div className="flex-1 min-h-[380px] bg-[#05070a] rounded-2xl p-2 flex items-center justify-center overflow-hidden border border-slate-800">
            <div
              className={`transition-all duration-300 bg-white rounded-xl overflow-hidden shadow-2xl ${
                device === 'mobile' ? 'w-[320px] h-[520px] border-4 border-slate-800' : 'w-full h-full'
              }`}
            >
              <iframe
                title="Sandboxed Project Execution"
                srcDoc={activeCode}
                sandbox="allow-scripts allow-forms allow-modals"
                className="w-full h-full border-none"
              />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
