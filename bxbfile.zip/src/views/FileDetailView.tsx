import React, { useState, useEffect, useRef } from 'react';
import { 
  Download, 
  Share2, 
  ShieldCheck, 
  Clock, 
  Tag, 
  FileText, 
  User, 
  AlertTriangle, 
  Loader2, 
  ArrowLeft, 
  Copy, 
  Check, 
  Lock, 
  Globe, 
  EyeOff, 
  Layers, 
  Edit3, 
  Trash2,
  Calendar,
  Eye,
  CheckCircle2,
  HardDrive,
  Film,
  Image as ImageIcon,
  Youtube,
  RefreshCw,
  History,
  Music,
  ExternalLink,
  Bookmark,
  Ban,
  Key,
  ShieldAlert,
  Sparkles
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useSiteConfig } from '../context/SiteConfigContext';
import { 
  getFileById, 
  recordDownloadStart, 
  deleteFile,
  getRelatedFiles 
} from '../services/fileService';
import { 
  verifyFilePassword, 
  startCountdownSession, 
  completeCountdownSession, 
  revokeFileLink, 
  regenerateFileLink 
} from '../services/siteConfigService';
import { FileItem } from '../types';
import { FileIcon } from '../components/ui/FileIcon';
import { formatBytes, formatRelativeTime } from '../utils/format';
import { ShareModal } from '../components/files/ShareModal';
import { ReportModal } from '../components/files/ReportModal';
import { EditFileModal } from '../components/files/EditFileModal';
import { SandboxPreviewModal } from '../components/files/SandboxPreviewModal';
import { ReplaceBinaryModal } from '../components/files/ReplaceBinaryModal';
import { PaymentCheckoutModal } from '../components/files/PaymentCheckoutModal';
import { FileCard } from '../components/files/FileCard';
import { AdSenseUnit } from '../components/adsense/AdSenseUnit';

interface FileDetailViewProps {
  fileId: string;
  onNavigate: (view: string, param?: string) => void;
}

export const FileDetailView: React.FC<FileDetailViewProps> = ({ fileId, onNavigate }) => {
  const { user, isAdmin, isOwner: isPlatformOwner } = useAuth();
  const { countdownDefaults, brand } = useSiteConfig();

  const [file, setFile] = useState<FileItem | null>(null);
  const [relatedFiles, setRelatedFiles] = useState<FileItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [downloading, setDownloading] = useState(false);
  const [copiedHash, setCopiedHash] = useState(false);
  const [selectedScreenshot, setSelectedScreenshot] = useState<string | null>(null);

  // Security Access & Password Gate States (Section C)
  const [passwordInput, setPasswordInput] = useState('');
  const [passwordError, setPasswordError] = useState<string | null>(null);
  const [passwordVerified, setPasswordVerified] = useState(false);
  const [authToken, setAuthToken] = useState<string | null>(null);
  const [verifyingPassword, setVerifyingPassword] = useState(false);

  // Countdown States (Section B)
  const [countdownRemaining, setCountdownRemaining] = useState<number>(0);
  const [countdownTotal, setCountdownTotal] = useState<number>(0);
  const [countdownSessionId, setCountdownSessionId] = useState<string | null>(null);
  const [countdownTicket, setCountdownTicket] = useState<string | null>(null);
  const [countdownActive, setCountdownActive] = useState(false);

  // Payment Entitlement
  const [isEntitled, setIsEntitled] = useState(false);
  const [paymentModalOpen, setPaymentModalOpen] = useState(false);

  // Modals
  const [shareOpen, setShareOpen] = useState(false);
  const [reportOpen, setReportOpen] = useState(false);
  const [editOpen, setEditOpen] = useState(false);
  const [replaceOpen, setReplaceOpen] = useState(false);
  const [sandboxOpen, setSandboxOpen] = useState(false);
  const [deleting, setDeleting] = useState(false);

  // Revocation state feedback
  const [revoking, setRevoking] = useState(false);
  const [ownerMsg, setOwnerMsg] = useState<string | null>(null);

  const isFileOwner = Boolean(user && file && user.uid === file.ownerUid);
  const hasPrivilege = isFileOwner || isAdmin || isPlatformOwner;

  // Check saved session tokens
  useEffect(() => {
    try {
      const savedToken = sessionStorage.getItem(`bxb_token_${fileId}`);
      if (savedToken) {
        setAuthToken(savedToken);
        setPasswordVerified(true);
      }
      const savedTicket = sessionStorage.getItem(`bxb_ticket_${fileId}`);
      if (savedTicket) {
        setCountdownTicket(savedTicket);
      }
    } catch {}
  }, [fileId]);

  // Load File Details
  useEffect(() => {
    let isMounted = true;
    setLoading(true);
    setError(null);

    getFileById(fileId)
      .then((data) => {
        if (!isMounted) return;
        if (!data) {
          setError('File not found or has been removed by its creator.');
        } else {
          // Check private permission
          if (data.visibility === 'private') {
            const isAuthorized = user && (user.uid === data.ownerUid || isAdmin || isPlatformOwner);
            if (!isAuthorized) {
              setError('This file is private. Only the authorized creator has access.');
              setFile(null);
              return;
            }
          }
          setFile(data);

          // Check entitlement for paid files
          if (data.isPaid) {
            const isOwner = user && user.uid === data.ownerUid;
            if (isOwner) {
              setIsEntitled(true);
            } else if (user) {
              fetch(`/api/payments/check-entitlement?fileId=${encodeURIComponent(data.id)}&buyerUid=${encodeURIComponent(user.uid)}`)
                .then(r => r.json())
                .then(res => {
                  if (res.entitled) setIsEntitled(true);
                })
                .catch(() => {});
            }
          }

          // Fetch related files
          getRelatedFiles(data.id, data.category).then((related) => {
            if (isMounted) setRelatedFiles(related);
          });
        }
      })
      .catch((err) => {
        if (!isMounted) return;
        setError(err.message || 'Failed to load file details.');
      })
      .finally(() => {
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [fileId, user, isAdmin, isPlatformOwner]);

  // Determine if countdown should initiate
  useEffect(() => {
    if (!file || hasPrivilege) return;
    if (file.hasPassword && !passwordVerified) return; // Wait for password verification first
    if (file.isRevoked) return;

    // Check if ticket already saved in sessionStorage
    const existingTicket = sessionStorage.getItem(`bxb_ticket_${file.id}`);
    if (existingTicket) {
      setCountdownTicket(existingTicket);
      return;
    }

    // Determine target countdown duration
    let targetSeconds = 0;
    if (typeof file.countdownSeconds === 'number') {
      targetSeconds = file.countdownSeconds;
    } else if (countdownDefaults?.enabled) {
      if (countdownDefaults.policy === 'all' || (countdownDefaults.policy === 'selected' && file.countdownSeconds !== undefined)) {
        targetSeconds = countdownDefaults.defaultSeconds || 15;
      }
    }

    if (targetSeconds > 0 && !countdownActive && !countdownTicket) {
      setCountdownTotal(targetSeconds);
      setCountdownRemaining(targetSeconds);
      setCountdownActive(true);

      // Start session on server
      startCountdownSession(file.id)
        .then(res => {
          setCountdownSessionId(res.sessionId);
        })
        .catch(() => {
          // Fallback to local session
          setCountdownSessionId(`local_${Date.now()}`);
        });
    }
  }, [file, passwordVerified, hasPrivilege, countdownDefaults, countdownActive, countdownTicket]);

  // Countdown Timer Ticker
  useEffect(() => {
    if (!countdownActive || countdownRemaining <= 0) return;

    const timer = setInterval(() => {
      setCountdownRemaining((prev) => {
        if (prev <= 1) {
          clearInterval(timer);
          setCountdownActive(false);

          // Complete session on backend and get download ticket
          if (file && countdownSessionId) {
            completeCountdownSession(file.id, countdownSessionId)
              .then(res => {
                setCountdownTicket(res.ticket);
                try {
                  sessionStorage.setItem(`bxb_ticket_${file.id}`, res.ticket);
                } catch {}
              })
              .catch(err => {
                console.warn('Countdown complete issue, using fallback ticket:', err);
                const localTicket = `ticket_${Date.now()}`;
                setCountdownTicket(localTicket);
              });
          }
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, [countdownActive, countdownRemaining, file, countdownSessionId]);

  // Password Verification Action
  const handleVerifyPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file || !passwordInput.trim()) return;
    setVerifyingPassword(true);
    setPasswordError(null);

    try {
      const res = await verifyFilePassword(file.id, passwordInput.trim());
      if (res.authorized) {
        setPasswordVerified(true);
        if (res.token) {
          setAuthToken(res.token);
          try {
            sessionStorage.setItem(`bxb_token_${file.id}`, res.token);
          } catch {}
        }
        setPasswordInput('');
      }
    } catch (err: any) {
      setPasswordError(err.message || 'Incorrect password.');
    } finally {
      setVerifyingPassword(false);
    }
  };

  // Real Download Execution
  const handleDownload = async () => {
    if (!file) return;

    // Check payment requirement
    const isOwner = user && user.uid === file.ownerUid;
    if (file.isPaid && !isOwner && !isEntitled) {
      setPaymentModalOpen(true);
      return;
    }

    setDownloading(true);
    try {
      await recordDownloadStart(file.id, file.ownerUid);
      setFile(prev => prev ? { ...prev, downloadStartCount: (prev.downloadStartCount || 0) + 1 } : null);

      // Build authorized download target
      const queryParams = new URLSearchParams();
      if (user?.uid) queryParams.set('buyerUid', user.uid);
      if (authToken) queryParams.set('token', authToken);
      if (countdownTicket) queryParams.set('ticket', countdownTicket);

      const downloadEndpoint = file.downloadUrl.startsWith('/api/')
        ? `${file.downloadUrl}?${queryParams.toString()}`
        : `/api/download/${file.id}?${queryParams.toString()}`;

      // If file specifies a protected redirectUrl, open it securely
      if (file.redirectUrl) {
        window.open(file.redirectUrl, '_blank', 'noopener,noreferrer');
        return;
      }

      // Trigger browser download
      const link = document.createElement('a');
      link.href = downloadEndpoint;
      link.download = `${file.title}.${file.extension}`;
      link.target = '_blank';
      link.rel = 'noopener noreferrer';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
    } catch (err: any) {
      setError(err.message || 'Download initialization failed.');
    } finally {
      setTimeout(() => setDownloading(false), 2000);
    }
  };

  // Owner Link Revocation / Regeneration
  const handleRevokeToggle = async () => {
    if (!file) return;
    setRevoking(true);
    try {
      if (file.isRevoked) {
        const res = await regenerateFileLink(file.id, user?.email || undefined, user?.uid);
        setFile(prev => prev ? { ...prev, isRevoked: false } : null);
        setOwnerMsg('Link regenerated! Public access restored with new link token.');
      } else {
        const res = await revokeFileLink(file.id, user?.email || undefined, user?.uid);
        setFile(prev => prev ? { ...prev, isRevoked: true } : null);
        setOwnerMsg('Link revoked! All new visitor requests are now denied by the server.');
      }
      setTimeout(() => setOwnerMsg(null), 4000);
    } catch {
      setError('Failed to update revocation status.');
    } finally {
      setRevoking(false);
    }
  };

  const handleDelete = async () => {
    if (!file) return;
    setDeleting(true);
    try {
      await deleteFile(file);
      onNavigate('library');
    } catch (err: unknown) {
      setError(err instanceof Error ? err.message : 'Failed to delete file.');
      setDeleting(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center p-8 text-slate-400 gap-3">
        <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
        <p className="text-xs font-mono">Resolving file security &amp; access policy...</p>
      </div>
    );
  }

  if (error || !file) {
    return (
      <div className="max-w-xl mx-auto px-4 py-16 text-center animate-fade-in">
        <div className="w-16 h-16 rounded-3xl bg-red-500/10 border border-red-500/30 text-red-400 flex items-center justify-center mx-auto mb-4">
          <AlertTriangle className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-white mb-2">Access Notice</h2>
        <p className="text-xs sm:text-sm text-slate-400 mb-6">{error || 'This item could not be retrieved.'}</p>
        <button
          onClick={() => onNavigate('home')}
          className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs font-semibold text-white transition inline-flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Return to Homepage</span>
        </button>
      </div>
    );
  }

  // Check Expiration & Revocation for non-owners
  const isExpired = file.expiresAt && !isNaN(new Date(file.expiresAt).getTime()) && Date.now() > new Date(file.expiresAt).getTime();
  const isLimitReached = typeof file.maxDownloads === 'number' && file.maxDownloads > 0 && (file.downloadStartCount || 0) >= file.maxDownloads;
  const isBlockedForVisitor = !hasPrivilege && (file.isRevoked || isExpired || isLimitReached);

  const isHtmlOrWeb = ['html', 'htm', 'js', 'json', 'web-apps'].includes(file.extension.toLowerCase());
  const isAudio = ['mp3', 'wav', 'ogg', 'flac'].includes(file.extension.toLowerCase());
  const isExecutable = ['apk', 'exe', 'msi', 'deb', 'dmg', 'iso'].includes(file.extension.toLowerCase());

  // Effective countdown calculation for display
  const effectiveCountdown = typeof file.countdownSeconds === 'number'
    ? file.countdownSeconds
    : (countdownDefaults?.enabled ? countdownDefaults.defaultSeconds : 0);

  const countdownPercent = countdownTotal > 0 
    ? Math.round(((countdownTotal - countdownRemaining) / countdownTotal) * 100)
    : 100;

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 py-8 animate-fade-in space-y-6">
      {/* Navigation and Brand Indicator */}
      <div className="flex items-center justify-between">
        <button
          onClick={() => onNavigate('explore')}
          className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-cyan-400 transition"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Back to Explore</span>
        </button>

        {file.customLogoUrl && (
          <div className="flex items-center gap-2 px-3 py-1 rounded-xl bg-slate-900 border border-slate-800">
            <img src={file.customLogoUrl} alt="Project Brand" className="w-5 h-5 object-contain" />
            <span className="text-[11px] font-bold text-slate-300 font-mono">Project Verified</span>
          </div>
        )}
      </div>

      {/* Owner Notification Message */}
      {ownerMsg && (
        <div className="p-3.5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center justify-between animate-fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>{ownerMsg}</span>
          </div>
          <button onClick={() => setOwnerMsg(null)} className="text-slate-400 hover:text-white">&times;</button>
        </div>
      )}

      {/* REVOCATION / EXPIRATION BLOCK BANNER */}
      {isBlockedForVisitor && (
        <div className="p-5 rounded-3xl bg-red-950/40 border border-red-500/40 text-red-300 text-xs space-y-2 text-center animate-fade-in">
          <Ban className="w-8 h-8 text-red-400 mx-auto" />
          <h3 className="text-base font-bold text-white">Download Access Terminated</h3>
          <p className="text-xs max-w-md mx-auto text-slate-300">
            {file.isRevoked ? 'This download link has been revoked by the creator.' :
             isExpired ? 'This download link has passed its configured expiration date.' :
             'The maximum authorized download limit for this release has been reached.'}
          </p>
        </div>
      )}

      {/* PASSWORD GATE CHALLENGE (Section C) */}
      {file.hasPassword && !passwordVerified && !hasPrivilege && !isBlockedForVisitor && (
        <div className="max-w-md mx-auto glass-panel-glow rounded-3xl p-6 sm:p-8 text-center space-y-4 border border-purple-500/40 shadow-2xl">
          <div className="w-14 h-14 rounded-2xl bg-purple-500/20 border border-purple-500/40 flex items-center justify-center text-purple-400 mx-auto">
            <Lock className="w-7 h-7" />
          </div>
          <div>
            <h2 className="text-lg font-bold text-white">Password Protected Download</h2>
            <p className="text-xs text-slate-400 mt-1">
              The creator of <strong>{file.title}</strong> requires a passphrase to unlock this download.
            </p>
          </div>

          {passwordError && (
            <div className="p-3 rounded-xl bg-red-500/10 border border-red-500/30 text-red-400 text-xs text-left">
              {passwordError}
            </div>
          )}

          <form onSubmit={handleVerifyPassword} className="space-y-3">
            <input
              type="password"
              required
              value={passwordInput}
              onChange={(e) => setPasswordInput(e.target.value)}
              placeholder="Enter access passphrase..."
              className="w-full px-4 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white text-xs font-mono focus:border-purple-400 focus:outline-none"
            />
            <button
              type="submit"
              disabled={verifyingPassword || !passwordInput.trim()}
              className="w-full py-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center justify-center gap-2 transition disabled:opacity-50"
            >
              {verifyingPassword ? <Loader2 className="w-4 h-4 animate-spin" /> : <Key className="w-4 h-4" />}
              <span>Verify Passphrase &amp; Unlock</span>
            </button>
          </form>

          <p className="text-[10px] text-slate-500 font-mono">
            Security: 10,000 PBKDF2 rounds. Rate limited to 5 attempts.
          </p>
        </div>
      )}

      {/* MAIN FILE DETAILS (Displayed when not blocked & password passed) */}
      {(!file.hasPassword || passwordVerified || hasPrivilege) && !isBlockedForVisitor && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column: Details, Media & Download Gateway (2 cols) */}
          <div className="lg:col-span-2 space-y-6">
            <div className="glass-panel-glow rounded-3xl p-6 sm:p-8 space-y-6 relative overflow-hidden">
              {/* File Header Card */}
              <div className="flex items-start gap-4">
                <FileIcon extension={file.extension} size="lg" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap mb-2">
                    <span className="px-2.5 py-0.5 rounded-full text-[10px] font-semibold uppercase tracking-wider text-cyan-300 bg-cyan-950/80 border border-cyan-800/80">
                      {file.category}
                    </span>
                    {file.version && (
                      <span className="px-2 py-0.5 rounded-md text-[10px] font-mono text-slate-300 bg-slate-800 border border-slate-700">
                        v{file.version}
                      </span>
                    )}
                    {file.platform && (
                      <span className="px-2 py-0.5 rounded-md text-[10px] text-slate-300 bg-slate-800 border border-slate-700">
                        {file.platform}
                      </span>
                    )}
                    {file.hasPassword && (
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/40 flex items-center gap-1">
                        <Lock className="w-3 h-3" />
                        <span>Protected</span>
                      </span>
                    )}
                  </div>
                  <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight break-words">
                    {file.title}
                  </h1>
                </div>
              </div>

              {/* Cover Art Banner */}
              {file.thumbnailUrl && (
                <div className="w-full h-56 sm:h-72 rounded-2xl overflow-hidden bg-slate-900 border border-slate-800">
                  <img
                    src={file.thumbnailUrl}
                    alt={file.title}
                    className="w-full h-full object-cover"
                  />
                </div>
              )}

              {/* GOOGLE ADSENSE SPONSOR UNIT (Above Download Button) */}
              <AdSenseUnit placement="downloadPageBanner" />

              {/* SECTION B: COUNTDOWN DISPLAY & DOWNLOAD ACTION */}
              <div className="space-y-4 pt-2">
                {/* Active Countdown Progress */}
                {countdownActive && countdownRemaining > 0 && (
                  <div className="p-5 rounded-2xl bg-cyan-950/30 border border-cyan-500/40 text-center space-y-3 animate-pulse-subtle">
                    <div className="flex items-center justify-center gap-2">
                      <Clock className="w-5 h-5 text-cyan-400 animate-spin-slow" />
                      <span className="text-sm font-bold text-white">
                        Preparing Authorized Download Link in <strong className="text-cyan-300 font-mono text-base">{countdownRemaining}s</strong>
                      </span>
                    </div>
                    <div className="w-full h-2 rounded-full bg-slate-900 overflow-hidden max-w-md mx-auto">
                      <div 
                        className="h-full bg-cyan-400 transition-all duration-1000"
                        style={{ width: `${countdownPercent}%` }}
                      />
                    </div>
                    <p className="text-[11px] text-slate-400">
                      Please wait. Server-side download ticket is cryptographically authenticating.
                    </p>
                  </div>
                )}

                {/* Primary Download / Redirect CTA Button */}
                {file.isPaid && !isFileOwner && !isEntitled ? (
                  <button
                    onClick={() => setPaymentModalOpen(true)}
                    className="w-full py-4 px-6 rounded-2xl font-bold text-base bg-gradient-to-r from-amber-500 via-orange-600 to-amber-600 hover:from-amber-400 hover:to-orange-500 text-white shadow-xl shadow-amber-500/30 flex items-center justify-center gap-2.5 transition glow-btn active:scale-98"
                  >
                    <Lock className="w-5 h-5 text-amber-200" />
                    <span>Unlock &amp; Download ₹{file.price || 49} ({file.currency || 'INR'})</span>
                  </button>
                ) : file.redirectUrl ? (
                  <button
                    onClick={handleDownload}
                    disabled={countdownActive && countdownRemaining > 0}
                    className="w-full py-4 px-6 rounded-2xl font-bold text-base bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-white shadow-xl shadow-emerald-500/30 flex items-center justify-center gap-2.5 transition glow-btn disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    <ExternalLink className="w-5 h-5" />
                    <span>
                      {countdownActive && countdownRemaining > 0 
                        ? `Destination Unlocks in ${countdownRemaining}s` 
                        : 'Proceed to Protected Destination Link'}
                    </span>
                  </button>
                ) : (
                  <button
                    onClick={handleDownload}
                    disabled={downloading || (countdownActive && countdownRemaining > 0)}
                    className="w-full py-4 px-6 rounded-2xl font-bold text-base bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 hover:from-cyan-400 hover:to-indigo-500 text-white shadow-xl shadow-cyan-500/30 flex items-center justify-center gap-2.5 transition glow-btn disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    {downloading ? (
                      <>
                        <CheckCircle2 className="w-5 h-5 text-emerald-300 animate-bounce" />
                        <span>Streaming File Download...</span>
                      </>
                    ) : countdownActive && countdownRemaining > 0 ? (
                      <>
                        <Clock className="w-5 h-5 animate-spin" />
                        <span>Download Activates in {countdownRemaining}s...</span>
                      </>
                    ) : (
                      <>
                        <Download className="w-5 h-5" />
                        <span>Download {file.extension.toUpperCase()} ({formatBytes(file.fileSize)})</span>
                      </>
                    )}
                  </button>
                )}

                <div className="flex items-center justify-center gap-4 text-xs text-slate-400">
                  <span className="flex items-center gap-1">
                    <Download className="w-3.5 h-3.5 text-cyan-400" />
                    <strong>{file.downloadStartCount || 0}</strong> downloads
                  </span>
                  <span>&bull;</span>
                  <span className="flex items-center gap-1">
                    <HardDrive className="w-3.5 h-3.5 text-emerald-400" />
                    {formatBytes(file.fileSize)}
                  </span>
                  {file.maxDownloads && (
                    <>
                      <span>&bull;</span>
                      <span className="text-amber-400 font-mono">
                        Limit: {file.downloadStartCount || 0}/{file.maxDownloads}
                      </span>
                    </>
                  )}
                </div>
              </div>

              {/* SHA-256 Web Crypto Verification Card */}
              {file.checksumSha256 && (
                <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-1.5">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5 text-xs font-semibold text-emerald-400">
                      <ShieldCheck className="w-4 h-4" />
                      <span>Verified Cryptographic SHA-256 Hash</span>
                    </div>
                    <button
                      onClick={() => {
                        navigator.clipboard.writeText(file.checksumSha256!);
                        setCopiedHash(true);
                        setTimeout(() => setCopiedHash(false), 2000);
                      }}
                      className="text-[11px] font-mono text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
                    >
                      {copiedHash ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                      <span>{copiedHash ? 'Copied' : 'Copy Hash'}</span>
                    </button>
                  </div>
                  <div className="p-2 rounded-xl bg-black/60 border border-slate-800 text-[11px] font-mono text-slate-300 break-all select-all">
                    {file.checksumSha256}
                  </div>
                  <p className="text-[10px] text-slate-500">
                    Compare this hash against your downloaded binary to verify authentic byte integrity.
                  </p>
                </div>
              )}

              {/* Description */}
              <div className="space-y-2">
                <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                  Description
                </h3>
                <p className="text-xs sm:text-sm text-slate-200 leading-relaxed whitespace-pre-wrap">
                  {file.description || 'No description provided by creator.'}
                </p>
              </div>

              {/* Tags */}
              {file.tags && file.tags.length > 0 && (
                <div className="flex items-center gap-1.5 flex-wrap pt-2">
                  <Tag className="w-3.5 h-3.5 text-slate-400" />
                  {file.tags.map((tag) => (
                    <span
                      key={tag}
                      onClick={() => onNavigate('explore')}
                      className="text-[11px] font-mono text-cyan-300 bg-cyan-950/60 border border-cyan-900/60 px-2 py-0.5 rounded-md hover:border-cyan-400 cursor-pointer transition"
                    >
                      #{tag}
                    </span>
                  ))}
                </div>
              )}
            </div>

            {/* Related Files */}
            {relatedFiles.length > 0 && (
              <div className="space-y-3">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                  Related {file.category} Releases
                </h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  {relatedFiles.map((rf) => (
                    <FileCard
                      key={rf.id}
                      file={rf}
                      onOpen={(f) => onNavigate('fileDetail', f.id)}
                      onShare={() => setShareOpen(true)}
                    />
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Right Column: Author Info & Owner Controls (1 col) */}
          <div className="space-y-6">
            {/* Creator Card */}
            <div className="glass-panel rounded-3xl p-6 space-y-4">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Published by Creator
              </h3>
              <div
                onClick={() => onNavigate('userProfile', file.ownerUsername)}
                className="flex items-center gap-3 cursor-pointer group"
              >
                {file.ownerAvatarUrl ? (
                  <img
                    src={file.ownerAvatarUrl}
                    alt={file.ownerUsername}
                    className="w-12 h-12 rounded-2xl object-cover border border-slate-700 group-hover:border-cyan-400 transition"
                  />
                ) : (
                  <div className="w-12 h-12 rounded-2xl bg-cyan-600 flex items-center justify-center font-bold text-white text-base">
                    {file.ownerUsername[0]?.toUpperCase()}
                  </div>
                )}
                <div className="min-w-0 flex-1">
                  <h4 className="text-sm font-bold text-white group-hover:text-cyan-300 transition truncate">
                    {file.ownerDisplayName}
                  </h4>
                  <p className="text-xs font-mono text-cyan-400 truncate">
                    @{file.ownerUsername}
                  </p>
                </div>
              </div>
              <div className="pt-2 border-t border-slate-800/80 space-y-2 text-xs text-slate-400">
                <div className="flex items-center justify-between">
                  <span>Published:</span>
                  <span className="text-slate-200">{formatRelativeTime(file.createdAt)}</span>
                </div>
                {file.expiresAt && (
                  <div className="flex items-center justify-between text-amber-300 font-mono">
                    <span>Expires:</span>
                    <span>{new Date(file.expiresAt).toLocaleDateString()}</span>
                  </div>
                )}
                <div className="flex items-center justify-between">
                  <span>File Size:</span>
                  <span className="text-slate-200 font-mono">{formatBytes(file.fileSize)}</span>
                </div>
              </div>
            </div>

            {/* Sharing & Owner Actions */}
            <div className="glass-panel rounded-3xl p-6 space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Access &amp; Actions
              </h3>
              <button
                onClick={() => setShareOpen(true)}
                className="w-full py-2.5 px-4 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 text-xs font-semibold text-white flex items-center justify-center gap-2 transition"
              >
                <Share2 className="w-4 h-4 text-cyan-400" />
                <span>Share Link / QR Code</span>
              </button>

              {/* Owner / Staff Control Panel */}
              {hasPrivilege && (
                <div className="pt-2 border-t border-slate-800 space-y-2">
                  <p className="text-[10px] text-cyan-400 font-bold uppercase tracking-wider">Owner Controls</p>
                  
                  <button
                    onClick={() => setEditOpen(true)}
                    className="w-full py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-semibold text-slate-200 flex items-center justify-center gap-2 transition"
                  >
                    <Edit3 className="w-3.5 h-3.5 text-cyan-400" />
                    <span>Edit Metadata &amp; Protection</span>
                  </button>

                  <button
                    onClick={handleRevokeToggle}
                    disabled={revoking}
                    className={`w-full py-2 px-3 rounded-xl border text-xs font-semibold flex items-center justify-center gap-2 transition ${
                      file.isRevoked
                        ? 'bg-cyan-950/40 border-cyan-500/50 text-cyan-300 hover:bg-cyan-900/60'
                        : 'bg-red-950/40 border-red-500/40 text-red-300 hover:bg-red-900/60'
                    }`}
                  >
                    {file.isRevoked ? (
                      <>
                        <RefreshCw className="w-3.5 h-3.5" />
                        <span>Regenerate &amp; Un-revoke</span>
                      </>
                    ) : (
                      <>
                        <Ban className="w-3.5 h-3.5" />
                        <span>Revoke Sharing Link</span>
                      </>
                    )}
                  </button>

                  <button
                    onClick={handleDelete}
                    disabled={deleting}
                    className="w-full py-2 px-3 rounded-xl bg-slate-900 hover:bg-red-950/40 border border-slate-800 text-xs font-semibold text-red-400 flex items-center justify-center gap-2 transition"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    <span>{deleting ? 'Deleting...' : 'Delete File'}</span>
                  </button>
                </div>
              )}

              {/* Abuse Report */}
              <div className="pt-2 border-t border-slate-800">
                <button
                  onClick={() => setReportOpen(true)}
                  className="w-full py-2 text-center text-xs text-slate-500 hover:text-red-400 transition"
                >
                  Report policy violation or broken file
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modals */}
      <ShareModal
        file={file}
        isOpen={shareOpen}
        onClose={() => setShareOpen(false)}
      />
      <ReportModal
        file={file}
        isOpen={reportOpen}
        onClose={() => setReportOpen(false)}
      />
      <EditFileModal
        file={file}
        isOpen={editOpen}
        onClose={() => setEditOpen(false)}
        onUpdated={(up) => setFile(up)}
      />
      <ReplaceBinaryModal
        file={file}
        isOpen={replaceOpen}
        onClose={() => setReplaceOpen(false)}
        onReplaced={(up) => setFile(up)}
      />
      <SandboxPreviewModal
        file={file}
        isOpen={sandboxOpen}
        onClose={() => setSandboxOpen(false)}
      />
      <PaymentCheckoutModal
        file={file}
        isOpen={paymentModalOpen}
        onClose={() => setPaymentModalOpen(false)}
        onPaymentSuccess={() => {
          setIsEntitled(true);
          handleDownload();
        }}
      />
    </div>
  );
};
