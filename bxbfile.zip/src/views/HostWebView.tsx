import React, { useState, useEffect } from 'react';
import { 
  Globe, 
  Code, 
  Sparkles, 
  Copy, 
  Check, 
  ExternalLink, 
  Play, 
  Trash2, 
  RefreshCw, 
  Eye, 
  Layers, 
  FileCode, 
  Terminal, 
  AlertCircle,
  CheckCircle2,
  Share2,
  Maximize2
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { publishHostedWebsite, fetchHostedWebsites, deleteHostedWebsite } from '../services/siteConfigService';

interface HostWebViewProps {
  onNavigate: (view: string, param?: string) => void;
  initialSlug?: string;
}

const TEMPLATES = [
  {
    name: 'Cyberpunk 2D Canvas Game',
    desc: 'Interactive playable canvas asteroid dodge game with score and neon glow.',
    html: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Cyber Dodge 2077</title>
  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body { background: #050508; color: #00f2fe; font-family: 'Courier New', monospace; text-align: center; overflow: hidden; display: flex; flex-direction: column; align-items: center; justify-content: center; height: 100vh; }
    h1 { font-size: 24px; text-shadow: 0 0 10px #00f2fe; margin-bottom: 8px; letter-spacing: 2px; }
    #score { font-size: 16px; margin-bottom: 12px; color: #ff007f; text-shadow: 0 0 8px #ff007f; }
    canvas { background: #0b0c16; border: 2px solid #00f2fe; box-shadow: 0 0 20px rgba(0, 242, 254, 0.4); border-radius: 12px; }
    p { margin-top: 10px; font-size: 12px; color: #8892b0; }
  </style>
</head>
<body>
  <h1>CYBER DODGE // BXB HOST</h1>
  <div id="score">SCORE: 0</div>
  <canvas id="game" width="400" height="400"></canvas>
  <p>Move mouse or touch screen to steer your neon drone</p>

  <script>
    const canvas = document.getElementById('game');
    const ctx = canvas.getContext('2d');
    let score = 0;
    let player = { x: 200, y: 350, r: 12 };
    let obstacles = [];
    let frame = 0;

    canvas.addEventListener('mousemove', (e) => {
      const rect = canvas.getBoundingClientRect();
      player.x = e.clientX - rect.left;
    });

    canvas.addEventListener('touchmove', (e) => {
      const rect = canvas.getBoundingClientRect();
      player.x = e.touches[0].clientX - rect.left;
    });

    function update() {
      frame++;
      if (frame % 25 === 0) {
        obstacles.push({ x: Math.random() * (canvas.width - 20) + 10, y: -20, r: Math.random() * 12 + 6, speed: Math.random() * 3 + 2 });
      }

      ctx.clearRect(0, 0, canvas.width, canvas.height);

      // Draw player
      ctx.beginPath();
      ctx.arc(player.x, player.y, player.r, 0, Math.PI * 2);
      ctx.fillStyle = '#00f2fe';
      ctx.shadowColor = '#00f2fe';
      ctx.shadowBlur = 15;
      ctx.fill();

      // Obstacles
      for (let i = obstacles.length - 1; i >= 0; i--) {
        const o = obstacles[i];
        o.y += o.speed;

        ctx.beginPath();
        ctx.arc(o.x, o.y, o.r, 0, Math.PI * 2);
        ctx.fillStyle = '#ff007f';
        ctx.shadowColor = '#ff007f';
        ctx.shadowBlur = 10;
        ctx.fill();

        // Collision
        const dist = Math.hypot(player.x - o.x, player.y - o.y);
        if (dist < player.r + o.r) {
          alert('SYSTEM OVERLOAD! Final Score: ' + score);
          score = 0;
          obstacles = [];
          break;
        }

        if (o.y > canvas.height + 20) {
          obstacles.splice(i, 1);
          score += 10;
          document.getElementById('score').innerText = 'SCORE: ' + score;
        }
      }

      requestAnimationFrame(update);
    }
    update();
  </script>
</body>
</html>`
  },
  {
    name: 'Modern Creator Portfolio',
    desc: 'Clean sleek showcase with gradient cards, social badges, and responsive design.',
    html: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Creator Portfolio</title>
  <style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { background: #090a0f; color: #f1f5f9; font-family: system-ui, -apple-system, sans-serif; min-height: 100vh; display: flex; align-items: center; justify-content: center; padding: 20px; }
    .card { background: rgba(30, 41, 59, 0.7); backdrop-filter: blur(12px); border: 1px solid rgba(148, 163, 184, 0.15); border-radius: 24px; max-width: 500px; width: 100%; padding: 32px; text-align: center; box-shadow: 0 20px 40px rgba(0,0,0,0.5); }
    .avatar { width: 90px; height: 90px; border-radius: 50%; background: linear-gradient(135deg, #06b6d4, #3b82f6); margin: 0 auto 16px; display: flex; align-items: center; justify-content: center; font-size: 36px; border: 3px solid rgba(255,255,255,0.2); }
    h1 { font-size: 24px; font-weight: 800; margin-bottom: 6px; }
    p.tag { color: #38bdf8; font-size: 13px; font-weight: 600; text-transform: uppercase; letter-spacing: 1px; margin-bottom: 16px; }
    p.bio { color: #94a3b8; font-size: 14px; line-height: 1.6; margin-bottom: 24px; }
    .links { display: flex; flex-direction: column; gap: 10px; }
    .btn { background: #1e293b; color: white; text-decoration: none; padding: 12px 20px; border-radius: 12px; font-weight: 600; font-size: 14px; border: 1px solid rgba(255,255,255,0.1); transition: all 0.2s; display: block; }
    .btn:hover { background: #0284c7; transform: translateY(-2px); box-shadow: 0 10px 20px rgba(2, 132, 199, 0.3); }
    .footer { margin-top: 24px; font-size: 11px; color: #64748b; }
  </style>
</head>
<body>
  <div class="card">
    <div class="avatar">⚡</div>
    <h1>Master Creator</h1>
    <p class="tag">Digital Architect & Developer</p>
    <p class="bio">Welcome to my personal live corner on the BXB Web Platform. Building next-generation tools, fast game engines, and cloud software.</p>
    <div class="links">
      <a href="#" class="btn">🚀 Latest Projects on BXB Cloud</a>
      <a href="#" class="btn">🎮 Playable Web Builds</a>
      <a href="#" class="btn">💬 Contact / Community</a>
    </div>
    <div class="footer">Hosted on bxbfile.bxb Cloud Web Engine</div>
  </div>
</body>
</html>`
  },
  {
    name: '3D Particle Matrix Canvas',
    desc: 'Fluid particle simulation with cursor attraction and glowing connection lines.',
    html: `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Particle Matrix</title>
  <style>
    * { margin:0; padding:0; overflow:hidden; }
    body { background: #000; }
    canvas { display: block; }
    .overlay { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%); text-align: center; color: white; font-family: sans-serif; pointer-events: none; }
    h1 { font-size: 32px; font-weight: 900; letter-spacing: 4px; text-shadow: 0 0 20px #06b6d4; }
  </style>
</head>
<body>
  <div class="overlay">
    <h1>BXB MATRIX CLOUD</h1>
  </div>
  <canvas id="c"></canvas>
  <script>
    const c = document.getElementById('c');
    const ctx = c.getContext('2d');
    let w = c.width = window.innerWidth;
    let h = c.height = window.innerHeight;
    const particles = [];
    for(let i=0; i<80; i++) {
      particles.push({
        x: Math.random()*w,
        y: Math.random()*h,
        vx: (Math.random()-0.5)*1.5,
        vy: (Math.random()-0.5)*1.5,
        r: Math.random()*2 + 1
      });
    }
    function draw() {
      ctx.fillStyle = 'rgba(0,0,0,0.1)';
      ctx.fillRect(0,0,w,h);
      ctx.fillStyle = '#06b6d4';
      for(let i=0; i<particles.length; i++) {
        let p = particles[i];
        p.x += p.vx; p.y += p.vy;
        if(p.x<0||p.x>w) p.vx*=-1;
        if(p.y<0||p.y>h) p.vy*=-1;
        ctx.beginPath();
        ctx.arc(p.x, p.y, p.r, 0, Math.PI*2);
        ctx.fill();
        for(let j=i+1; j<particles.length; j++) {
          let p2 = particles[j];
          let d = Math.hypot(p.x-p2.x, p.y-p2.y);
          if(d<120) {
            ctx.strokeStyle = 'rgba(6, 182, 212, ' + (1 - d/120)*0.4 + ')';
            ctx.beginPath();
            ctx.moveTo(p.x, p.y);
            ctx.lineTo(p2.x, p2.y);
            ctx.stroke();
          }
        }
      }
      requestAnimationFrame(draw);
    }
    draw();
  </script>
</body>
</html>`
  }
];

export const HostWebView: React.FC<HostWebViewProps> = ({ onNavigate, initialSlug }) => {
  const { user, userProfile, isOwner } = useAuth();

  const [slug, setSlug] = useState(initialSlug || '');
  const [title, setTitle] = useState('');
  const [htmlCode, setHtmlCode] = useState(TEMPLATES[0].html);
  const [cssCode, setCssCode] = useState('');
  const [jsCode, setJsCode] = useState('');
  const [activeCodeTab, setActiveCodeTab] = useState<'html' | 'css' | 'js'>('html');
  const [previewMode, setPreviewMode] = useState<'split' | 'edit' | 'preview'>('split');
  const [publishing, setPublishing] = useState(false);
  const [publishSuccess, setPublishSuccess] = useState<any | null>(null);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);

  // User's hosted sites
  const [mySites, setMySites] = useState<any[]>([]);
  const [loadingSites, setLoadingSites] = useState(false);

  const cleanSlug = slug.toLowerCase().replace(/[^a-z0-9_-]/g, '').trim();
  const shortDomainLink = cleanSlug ? `bxbfile.bxb/w/${cleanSlug}` : 'bxbfile.bxb/w/your-name';
  const liveLocalUrl = cleanSlug ? `/w/${cleanSlug}` : '';

  useEffect(() => {
    loadMySites();
  }, [user]);

  const loadMySites = async () => {
    setLoadingSites(true);
    try {
      const sites = await fetchHostedWebsites(user?.email || undefined);
      setMySites(sites);
    } catch {
      // ignore
    } finally {
      setLoadingSites(false);
    }
  };

  const handlePublish = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!cleanSlug) {
      setErrorMsg('Please enter a Web Name / Slug.');
      return;
    }
    if (!htmlCode.trim()) {
      setErrorMsg('Please provide valid HTML content.');
      return;
    }

    setPublishing(true);
    setErrorMsg(null);
    setPublishSuccess(null);

    try {
      const res = await publishHostedWebsite({
        slug: cleanSlug,
        title: title || cleanSlug,
        htmlContent: htmlCode,
        cssContent: cssCode,
        jsContent: jsCode,
        authorUid: user?.uid || 'anon',
        authorEmail: user?.email || 'creator@bxbfile.bxb',
        authorUsername: userProfile?.username || 'Creator'
      });

      setPublishSuccess(res);
      loadMySites();
    } catch (err: any) {
      setErrorMsg(err.message || 'Failed to host website');
    } finally {
      setPublishing(false);
    }
  };

  const handleDelete = async (targetSlug: string) => {
    if (!confirm(`Are you sure you want to take down website "${targetSlug}"?`)) return;
    try {
      await deleteHostedWebsite(targetSlug, user?.email || '');
      loadMySites();
      if (publishSuccess?.site?.slug === targetSlug) {
        setPublishSuccess(null);
      }
    } catch (err: any) {
      alert(err.message || 'Failed to delete');
    }
  };

  const handleCopyLink = (linkToCopy: string) => {
    navigator.clipboard.writeText(linkToCopy);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2500);
  };

  // Build sandboxed srcDoc for live iframe preview
  const livePreviewHtml = `
    <!DOCTYPE html>
    <html>
      <head>
        <meta charset="utf-8">
        <style>${cssCode}</style>
      </head>
      <body>
        ${htmlCode}
        <script>${jsCode}<\/script>
      </body>
    </html>
  `;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in text-white space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-purple-500/20 text-purple-300 border border-purple-500/30 uppercase tracking-wider">
              BXB Web Hosting Engine
            </span>
            <span className="text-xs text-slate-400 font-mono">Direct HTML Sandbox</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white mt-1 flex items-center gap-3">
            <Globe className="w-8 h-8 text-purple-400" />
            <span>Host Web &amp; HTML Publishing</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Instantly host HTML, CSS &amp; JavaScript websites. Put your code, pick your Web Name, and receive a tiny short link (<code className="font-mono text-purple-300">bxbfile.bxb/w/:name</code>).
          </p>
        </div>

        {/* View Mode controls */}
        <div className="flex items-center gap-2">
          <div className="flex items-center p-1 bg-slate-900 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => setPreviewMode('edit')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                previewMode === 'edit' ? 'bg-purple-600 text-white font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Code Only
            </button>
            <button
              onClick={() => setPreviewMode('split')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                previewMode === 'split' ? 'bg-purple-600 text-white font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Split View
            </button>
            <button
              onClick={() => setPreviewMode('preview')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                previewMode === 'preview' ? 'bg-purple-600 text-white font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Live Preview
            </button>
          </div>
        </div>
      </div>

      {/* Starter Templates */}
      <div className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-2 text-xs text-slate-300">
          <Sparkles className="w-4 h-4 text-purple-400 shrink-0" />
          <span className="font-semibold">Quick Starter Templates:</span>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {TEMPLATES.map((tpl, i) => (
            <button
              key={i}
              type="button"
              onClick={() => {
                setHtmlCode(tpl.html);
                setCssCode('');
                setJsCode('');
                if (!title) setTitle(tpl.name);
                if (!slug) setSlug(tpl.name.toLowerCase().replace(/[^a-z0-9]/g, '-').slice(0, 16));
              }}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-purple-950/60 border border-slate-700 hover:border-purple-500/50 text-xs text-slate-200 transition flex items-center gap-1.5"
            >
              <Code className="w-3.5 h-3.5 text-purple-400" />
              <span>{tpl.name}</span>
            </button>
          ))}
        </div>
      </div>

      {/* Success Banner */}
      {publishSuccess && (
        <div className="p-5 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-white space-y-3 animate-fade-in">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5 text-emerald-400 font-bold text-sm">
              <CheckCircle2 className="w-5 h-5 shrink-0" />
              <span>Website Successfully Published &amp; Live!</span>
            </div>
            <span className="px-2.5 py-0.5 rounded text-[11px] font-mono bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
              HTTP 200 OK
            </span>
          </div>
          <p className="text-xs text-slate-300">
            Your website <strong className="text-white font-mono">"{publishSuccess.site.slug}"</strong> is now live globally with instant SSL encryption and high-speed edge distribution.
          </p>

          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-2 pt-1">
            <div className="flex-1 px-4 py-2.5 rounded-xl bg-slate-950 border border-emerald-500/40 text-xs font-mono text-cyan-300 flex items-center justify-between">
              <span>{publishSuccess.shortLink}</span>
              <span className="text-[10px] text-slate-500 ml-2">Small Link</span>
            </div>
            <button
              onClick={() => handleCopyLink(publishSuccess.shortLink)}
              className="px-4 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 shadow transition active:scale-95"
            >
              {copiedLink ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
              <span>{copiedLink ? 'Copied Small Link!' : 'Copy Small Link'}</span>
            </button>
            <a
              href={publishSuccess.liveUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="px-4 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-white font-bold text-xs flex items-center justify-center gap-1.5 border border-slate-700 transition"
            >
              <ExternalLink className="w-4 h-4 text-cyan-400" />
              <span>Open Live Site</span>
            </a>
          </div>
        </div>
      )}

      {/* Error notification */}
      {errorMsg && (
        <div className="p-4 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-300 text-xs flex items-center gap-3">
          <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
          <span>{errorMsg}</span>
        </div>
      )}

      {/* Main Publishing Form & Code Studio */}
      <form onSubmit={handlePublish} className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-xs font-bold text-slate-300 block mb-1">
              Web Name / Slug <span className="text-purple-400">*</span>
            </label>
            <div className="flex rounded-xl bg-slate-900 border border-slate-700 overflow-hidden focus-within:border-purple-500">
              <span className="px-3 py-2.5 bg-slate-800/80 text-xs text-slate-400 font-mono border-r border-slate-700 flex items-center">
                bxbfile.bxb/w/
              </span>
              <input
                type="text"
                required
                value={slug}
                onChange={(e) => setSlug(e.target.value.toLowerCase().replace(/[^a-z0-9_-]/g, ''))}
                placeholder="my-cool-site"
                className="flex-1 px-3 py-2.5 bg-transparent text-xs text-white placeholder-slate-500 font-mono focus:outline-none"
              />
            </div>
            <p className="text-[11px] text-slate-400 mt-1 font-mono">
              Short Link: <span className="text-purple-400 font-semibold">{shortDomainLink}</span>
            </p>
          </div>

          <div>
            <label className="text-xs font-bold text-slate-300 block mb-1">
              Website Title
            </label>
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. My Interactive Web App"
              className="w-full px-3 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-purple-500"
            />
            <p className="text-[11px] text-slate-400 mt-1">
              Displayed in browser tab and social media cards
            </p>
          </div>
        </div>

        {/* Code Tabs & Live Split Canvas */}
        <div className="rounded-2xl bg-slate-900 border border-slate-800 overflow-hidden shadow-2xl">
          {/* Studio Bar */}
          <div className="px-4 py-3 bg-slate-950/80 border-b border-slate-800 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setActiveCodeTab('html')}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition flex items-center gap-1.5 ${
                  activeCodeTab === 'html' ? 'bg-orange-500/20 text-orange-400 border border-orange-500/30' : 'text-slate-400 hover:text-white'
                }`}
              >
                <FileCode className="w-3.5 h-3.5" />
                <span>index.html</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveCodeTab('css')}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition flex items-center gap-1.5 ${
                  activeCodeTab === 'css' ? 'bg-blue-500/20 text-blue-400 border border-blue-500/30' : 'text-slate-400 hover:text-white'
                }`}
              >
                <span>styles.css (Optional)</span>
              </button>
              <button
                type="button"
                onClick={() => setActiveCodeTab('js')}
                className={`px-3 py-1.5 rounded-lg text-xs font-mono font-bold transition flex items-center gap-1.5 ${
                  activeCodeTab === 'js' ? 'bg-amber-500/20 text-amber-400 border border-amber-500/30' : 'text-slate-400 hover:text-white'
                }`}
              >
                <span>script.js (Optional)</span>
              </button>
            </div>

            <div className="flex items-center gap-2 text-[11px] text-slate-400 font-mono">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
              <span>Live Engine Ready</span>
            </div>
          </div>

          {/* Editors / Preview Grid */}
          <div className={`grid ${previewMode === 'split' ? 'grid-cols-1 lg:grid-cols-2' : 'grid-cols-1'} min-h-[420px]`}>
            {/* Code Input */}
            {(previewMode === 'split' || previewMode === 'edit') && (
              <div className="p-4 bg-slate-950 flex flex-col font-mono text-xs border-r border-slate-800">
                {activeCodeTab === 'html' && (
                  <textarea
                    value={htmlCode}
                    onChange={(e) => setHtmlCode(e.target.value)}
                    placeholder="<!DOCTYPE html><html>...</html>"
                    className="w-full flex-1 min-h-[380px] bg-transparent text-emerald-300 font-mono text-xs focus:outline-none resize-y leading-relaxed"
                    spellCheck={false}
                  />
                )}
                {activeCodeTab === 'css' && (
                  <textarea
                    value={cssCode}
                    onChange={(e) => setCssCode(e.target.value)}
                    placeholder="/* Custom CSS */ body { background: #000; }"
                    className="w-full flex-1 min-h-[380px] bg-transparent text-cyan-300 font-mono text-xs focus:outline-none resize-y leading-relaxed"
                    spellCheck={false}
                  />
                )}
                {activeCodeTab === 'js' && (
                  <textarea
                    value={jsCode}
                    onChange={(e) => setJsCode(e.target.value)}
                    placeholder="// Custom JS console.log('BXB Web Running');"
                    className="w-full flex-1 min-h-[380px] bg-transparent text-amber-300 font-mono text-xs focus:outline-none resize-y leading-relaxed"
                    spellCheck={false}
                  />
                )}
              </div>
            )}

            {/* Sandbox Live Preview */}
            {(previewMode === 'split' || previewMode === 'preview') && (
              <div className="bg-slate-900 flex flex-col relative overflow-hidden">
                <div className="px-3 py-2 bg-slate-950/60 border-b border-slate-800 text-[11px] text-slate-400 flex items-center justify-between">
                  <span>Sandboxed Live Preview</span>
                  <span className="font-mono text-purple-400">{shortDomainLink}</span>
                </div>
                <iframe
                  title="Host Web Sandbox Preview"
                  srcDoc={livePreviewHtml}
                  sandbox="allow-scripts allow-modals allow-forms"
                  className="w-full flex-1 min-h-[380px] border-none bg-white"
                />
              </div>
            )}
          </div>
        </div>

        {/* Publish Action Button */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 pt-2">
          <div className="text-xs text-slate-400 flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
            <span>Zero-Trust isolated sandbox. Unlimited free bandwidth for all users.</span>
          </div>

          <button
            type="submit"
            disabled={publishing || !cleanSlug}
            className="w-full sm:w-auto px-8 py-3.5 rounded-2xl bg-gradient-to-r from-purple-500 via-pink-600 to-cyan-500 hover:from-purple-400 hover:to-cyan-400 text-white font-extrabold text-sm flex items-center justify-center gap-2.5 shadow-xl shadow-purple-500/25 transition active:scale-95 disabled:opacity-50"
          >
            {publishing ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>Deploying to BXB Edge...</span>
              </>
            ) : (
              <>
                <Globe className="w-4 h-4" />
                <span>Publish Website &amp; Generate Small Link</span>
              </>
            )}
          </button>
        </div>
      </form>

      {/* My Hosted Websites Catalog */}
      <div className="pt-8 border-t border-slate-800">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Layers className="w-5 h-5 text-purple-400" />
              <span>Published Websites &amp; Small Links</span>
            </h2>
            <p className="text-xs text-slate-400">
              Websites currently live on the bxbfile.bxb domain network
            </p>
          </div>
          <button
            onClick={loadMySites}
            disabled={loadingSites}
            className="p-2 rounded-xl bg-slate-900 border border-slate-800 hover:text-white text-slate-400 transition"
            title="Refresh List"
          >
            <RefreshCw className={`w-4 h-4 ${loadingSites ? 'animate-spin' : ''}`} />
          </button>
        </div>

        {mySites.length === 0 ? (
          <div className="p-8 rounded-2xl bg-slate-900/40 border border-slate-800 text-center text-slate-400 space-y-2">
            <Globe className="w-8 h-8 text-slate-600 mx-auto" />
            <p className="text-xs">No websites hosted yet. Choose a template above and click "Publish Website" to claim your first small link!</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {mySites.map((site) => (
              <div
                key={site.slug}
                className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 hover:border-purple-500/40 transition space-y-3"
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <h3 className="font-bold text-white text-sm truncate">{site.title || site.slug}</h3>
                    <div className="inline-flex items-center gap-1 text-[11px] font-mono text-purple-400 mt-0.5">
                      <Globe className="w-3 h-3" />
                      <span>bxbfile.bxb/w/{site.slug}</span>
                    </div>
                  </div>
                  <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                    Live
                  </span>
                </div>

                <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono pt-1">
                  <span>Visits: {site.visits || 0}</span>
                  <span>{new Date(site.updatedAt || site.createdAt).toLocaleDateString()}</span>
                </div>

                <div className="flex items-center gap-2 pt-2 border-t border-slate-800/80">
                  <a
                    href={`/w/${site.slug}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 py-1.5 px-2.5 rounded-xl bg-purple-600 hover:bg-purple-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Open Live</span>
                  </a>

                  <button
                    onClick={() => handleCopyLink(`bxbfile.bxb/w/${site.slug}`)}
                    className="p-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition"
                    title="Copy Small Link"
                  >
                    <Copy className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => handleDelete(site.slug)}
                    className="p-2 rounded-xl bg-slate-800 hover:bg-red-500/20 text-slate-400 hover:text-red-400 transition"
                    title="Delete Website"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
