import React, { useState, useEffect } from 'react';
import { 
  Cloud, 
  UploadCloud, 
  Compass, 
  Smartphone, 
  Monitor, 
  Code, 
  Gamepad2, 
  Cpu, 
  FileText, 
  Film, 
  ShieldCheck, 
  Zap, 
  Lock, 
  TrendingUp, 
  Clock, 
  ArrowRight, 
  Search,
  Sparkles,
  CheckCircle2,
  Share2,
  X,
  Globe,
  Server,
  Info,
  RefreshCw
} from 'lucide-react';
import { getPublicFiles } from '../services/fileService';
import { FileItem, CATEGORIES } from '../types';
import { FileCard } from '../components/files/FileCard';
import { ShareModal } from '../components/files/ShareModal';

interface HomeViewProps {
  onNavigate: (view: string, param?: string) => void;
  onSearch: (query: string) => void;
}

export const HomeView: React.FC<HomeViewProps> = ({ onNavigate, onSearch }) => {
  const [trendingFiles, setTrendingFiles] = useState<FileItem[]>([]);
  const [recentFiles, setRecentFiles] = useState<FileItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchInput, setSearchInput] = useState('');
  const [shareFile, setShareFile] = useState<FileItem | null>(null);
  const [policyModal, setPolicyModal] = useState<{ title: string; content: React.ReactNode } | null>(null);

  useEffect(() => {
    let isMounted = true;
    setLoading(true);

    Promise.all([
      getPublicFiles({ sortBy: 'downloads', maxResults: 4 }),
      getPublicFiles({ sortBy: 'recent', maxResults: 8 }),
    ])
      .then(([trending, recent]) => {
        if (!isMounted) return;
        setTrendingFiles(trending);
        setRecentFiles(recent);
      })
      .catch((err) => {
        console.error('Error querying home files:', err);
      })
      .finally(() => {
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, []);

  const handleHeroSearch = (e: React.FormEvent) => {
    e.preventDefault();
    if (searchInput.trim()) {
      onSearch(searchInput.trim());
      onNavigate('explore');
    }
  };

  return (
    <div className="space-y-16 py-6 pb-20 animate-fade-in">
      {/* 1. HERO SECTION */}
      <section className="relative overflow-hidden px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto text-center space-y-6 pt-6 sm:pt-12">
          {/* Futuristic Brand & Domain Badge */}
          <div className="inline-flex flex-wrap items-center justify-center gap-2 px-4 py-2 rounded-2xl text-xs font-mono font-medium bg-gradient-to-r from-cyan-950/90 via-slate-900 to-blue-950/90 border border-cyan-500/40 text-cyan-300 shadow-xl shadow-cyan-500/10">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse shadow-sm shadow-emerald-400"></span>
            <span className="font-bold text-white tracking-wider">bxbfile.bxb</span>
            <span className="text-slate-500">•</span>
            <span className="px-2 py-0.5 rounded-md bg-cyan-900/60 text-cyan-300 border border-cyan-700/60 font-mono font-semibold">
              BXB Cloud
            </span>
            <span className="text-slate-500">•</span>
            <span className="text-emerald-300 font-semibold">12 GB Engine</span>
            <span className="text-slate-500">•</span>
            <span className="text-cyan-300 font-semibold">Real-Time Cloud Sync</span>
            <span className="text-slate-500">•</span>
            <span className="text-amber-300 font-semibold">JARVIS AI</span>
          </div>

          {/* Headline */}
          <h1 className="text-3xl sm:text-5xl lg:text-6xl font-black text-white tracking-tight leading-tight max-w-4xl mx-auto">
            The Ultimate Cloud Platform for{' '}
            <span className="bg-gradient-to-r from-cyan-400 via-blue-400 to-indigo-400 bg-clip-text text-transparent">
              Files, APKs &amp; Builds
            </span>
          </h1>

          {/* Subtitle */}
          <p className="text-sm sm:text-base text-slate-300 max-w-2xl mx-auto leading-relaxed">
            bxbfile.bxb by BXB Cloud: Distribute Android APKs, developer packages, tools, and media attachments up to 12 GB with real-time multi-device Cloud Sync, Web Crypto SHA-256 integrity, and the JARVIS AI Multiverse Command Center.
          </p>

          {/* Quick Search in Hero */}
          <form onSubmit={handleHeroSearch} className="max-w-xl mx-auto relative pt-2">
            <Search className="w-5 h-5 text-slate-400 absolute left-4 top-1/2 -translate-y-1/2 mt-1" />
            <input
              type="text"
              value={searchInput}
              onChange={(e) => setSearchInput(e.target.value)}
              placeholder="Search for Android APKs, project ZIPs, utilities..."
              className="w-full pl-12 pr-28 py-3.5 rounded-2xl bg-slate-900/90 border border-slate-700/80 text-sm text-white placeholder-slate-400 focus:border-cyan-400 focus:outline-none focus:ring-1 focus:ring-cyan-400 shadow-2xl transition"
            />
            <button
              type="submit"
              className="absolute right-2 top-1/2 -translate-y-1/2 mt-1 px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs transition"
            >
              Search
            </button>
          </form>

          {/* Hero CTAs */}
          <div className="flex flex-wrap items-center justify-center gap-3 pt-3">
            <button
              onClick={() => onNavigate('upload')}
              className="px-6 py-3 rounded-2xl font-bold text-xs sm:text-sm bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white flex items-center justify-center gap-2 shadow-xl shadow-cyan-500/25 transition glow-btn active:scale-98"
            >
              <UploadCloud className="w-4 h-4" />
              <span>Publish 12 GB File</span>
            </button>

            <button
              onClick={() => onNavigate('sync')}
              className="px-5 py-3 rounded-2xl font-bold text-xs sm:text-sm bg-slate-900 hover:bg-cyan-950/60 border border-cyan-500/40 text-cyan-300 flex items-center justify-center gap-2 transition"
            >
              <RefreshCw className="w-4 h-4 text-cyan-400 animate-spin-slow" />
              <span>BXB Cloud Sync Hub</span>
            </button>

            <button
              onClick={() => onNavigate('jarvis')}
              className="px-5 py-3 rounded-2xl font-bold text-xs sm:text-sm bg-gradient-to-r from-amber-500/20 to-orange-500/20 hover:bg-amber-500/30 border border-amber-500/40 text-amber-300 flex items-center justify-center gap-2 transition"
            >
              <Sparkles className="w-4 h-4 text-amber-400" />
              <span>JARVIS AI Command Center</span>
            </button>

            <button
              onClick={() => onNavigate('explore')}
              className="px-5 py-3 rounded-2xl font-bold text-xs sm:text-sm bg-slate-900/90 hover:bg-slate-800 border border-slate-700/80 text-slate-200 flex items-center justify-center gap-2 transition"
            >
              <Compass className="w-4 h-4 text-slate-400" />
              <span>Explore Public Registry</span>
            </button>
          </div>
        </div>
      </section>

      {/* 2. CATEGORY EXPLORER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight">
              Explore by Category
            </h2>
            <p className="text-xs text-slate-400">Curated registries for apps, tools, and creator releases</p>
          </div>
          <button
            onClick={() => onNavigate('explore')}
            className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
          >
            <span>View All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-3.5">
          {CATEGORIES.map((cat) => (
            <div
              key={cat.id}
              onClick={() => onNavigate('explore', cat.id)}
              className="p-4 rounded-2xl glass-panel hover:glass-panel-glow border border-slate-800 hover:border-cyan-500/40 cursor-pointer transition-all duration-300 group hover:-translate-y-1"
            >
              <div className="w-10 h-10 rounded-xl bg-slate-800 group-hover:bg-cyan-500/20 text-slate-300 group-hover:text-cyan-300 flex items-center justify-center mb-3 transition">
                {cat.id === 'apk' && <Smartphone className="w-5 h-5" />}
                {cat.id === 'windows' && <Monitor className="w-5 h-5" />}
                {cat.id === 'projects' && <Code className="w-5 h-5" />}
                {cat.id === 'games' && <Gamepad2 className="w-5 h-5" />}
                {cat.id === 'ai-tools' && <Cpu className="w-5 h-5" />}
                {cat.id === 'documents' && <FileText className="w-5 h-5" />}
                {cat.id === 'media' && <Film className="w-5 h-5" />}
                {!['apk', 'windows', 'projects', 'games', 'ai-tools', 'documents', 'media'].includes(cat.id) && (
                  <Cloud className="w-5 h-5" />
                )}
              </div>
              <h3 className="text-xs font-bold text-white group-hover:text-cyan-300 transition">
                {cat.name}
              </h3>
              <p className="text-[10px] text-slate-400 line-clamp-1 mt-0.5">
                {cat.desc}
              </p>
            </div>
          ))}
        </div>
      </section>

      {/* 3. TRENDING / MOST DOWNLOADED FILES */}
      {trendingFiles.length > 0 && (
        <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <TrendingUp className="w-4 h-4" />
              </div>
              <div>
                <h2 className="text-xl font-extrabold text-white tracking-tight">
                  Trending Downloads
                </h2>
                <p className="text-xs text-slate-400">Ranked by verified user downloads</p>
              </div>
            </div>
            <button
              onClick={() => onNavigate('explore')}
              className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
            >
              <span>More</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {trendingFiles.map((file) => (
              <FileCard
                key={file.id}
                file={file}
                onOpen={(f) => onNavigate('fileDetail', f.id)}
                onShare={(f) => setShareFile(f)}
                onAuthorClick={(u) => onNavigate('userProfile', u)}
              />
            ))}
          </div>
        </section>
      )}

      {/* 4. RECENTLY PUBLISHED FILES */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Clock className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-xl font-extrabold text-white tracking-tight">
                Recently Published Releases
              </h2>
              <p className="text-xs text-slate-400">Live stream of latest uploads by creators</p>
            </div>
          </div>
          <button
            onClick={() => onNavigate('explore')}
            className="text-xs font-semibold text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
          >
            <span>Browse All</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        {recentFiles.length === 0 && !loading ? (
          <div className="py-16 text-center glass-panel rounded-3xl border border-slate-800">
            <Cloud className="w-12 h-12 text-slate-500 mx-auto mb-3" />
            <h3 className="text-base font-bold text-white mb-1">No Public Files Yet</h3>
            <p className="text-xs text-slate-400 max-w-sm mx-auto mb-4">
              Be the first creator to upload and publish an APK, tool or project bundle to BXB Cloud.
            </p>
            <button
              onClick={() => onNavigate('upload')}
              className="px-5 py-2.5 rounded-xl bg-cyan-500 text-black font-semibold text-xs transition"
            >
              Upload First File
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {recentFiles.map((file) => (
              <FileCard
                key={file.id}
                file={file}
                onOpen={(f) => onNavigate('fileDetail', f.id)}
                onShare={(f) => setShareFile(f)}
                onAuthorClick={(u) => onNavigate('userProfile', u)}
              />
            ))}
          </div>
        )}
      </section>

      {/* 5. PLATFORM ARCHITECTURE & TRUST PILLARS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="glass-panel-glow rounded-3xl p-8 sm:p-12 relative overflow-hidden">
          <div className="text-center max-w-2xl mx-auto mb-10 space-y-2">
            <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
              Built for High-Speed Distribution &amp; Security
            </h2>
            <p className="text-xs sm:text-sm text-slate-400">
              Zero compromises on file integrity, privacy boundaries, or download reliability.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
                <ShieldCheck className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white">Cryptographic Checksums</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Every binary upload is cryptographically hashed using Web Crypto SHA-256. Visitors can independently audit binaries against the published checksum.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-purple-500/10 border border-purple-500/30 flex items-center justify-center text-purple-400">
                <Lock className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white">ABAC Zero-Trust Rules</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Enforced by Cloud Firestore and Storage security rules. Private uploads are mathematically blocked from unauthorized visitor downloads or discovery leaks.
              </p>
            </div>

            <div className="p-5 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
              <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
                <Zap className="w-5 h-5" />
              </div>
              <h3 className="text-sm font-bold text-white">Fast Direct Downloads</h3>
              <p className="text-xs text-slate-400 leading-relaxed">
                Backed by Google Cloud global object storage. No artificial download throttling, no fake wait timers, and no multi-step ad walls.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 6. PUBLISHING CALL TO ACTION */}
      <section className="max-w-5xl mx-auto px-4 sm:px-6">
        <div className="rounded-3xl p-8 sm:p-12 text-center bg-gradient-to-r from-cyan-900/40 via-blue-900/40 to-purple-900/40 border border-cyan-500/30 shadow-2xl relative">
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight mb-3">
            Have an APK or Project to Share?
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 max-w-xl mx-auto mb-6">
            Claim your BXB Cloud creator username in seconds with Google authentication. Publish your release and generate a permanent download page URL instantly.
          </p>
          <button
            onClick={() => onNavigate('upload')}
            className="px-8 py-3.5 rounded-2xl font-bold text-sm bg-cyan-500 hover:bg-cyan-400 text-black shadow-xl shadow-cyan-500/30 transition glow-btn active:scale-95"
          >
            Start Publishing on BXB Cloud
          </button>
        </div>
      </section>

      {/* 7. COMPREHENSIVE FOOTER */}
      <footer className="border-t border-slate-800/80 pt-10 pb-6 px-4 sm:px-6 lg:px-8 text-slate-400 text-xs">
        <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-lg bg-gradient-to-tr from-cyan-500 to-blue-600 flex items-center justify-center text-white">
                <Cloud className="w-4 h-4" />
              </div>
              <span className="font-bold text-white text-sm">BXB CLOUD</span>
            </div>
            <p className="text-[11px] leading-relaxed text-slate-400">
              Futuristic file hosting, APK distribution, and developer project publishing platform.
            </p>
            <p className="text-[10px] font-mono text-cyan-400">
              Powered by Google Firebase Cloud Architecture
            </p>
          </div>

          <div>
            <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-2.5">Platform</h4>
            <ul className="space-y-2">
              <li><button onClick={() => onNavigate('explore')} className="hover:text-cyan-400 transition">Explore All Files</button></li>
              <li><button onClick={() => onNavigate('explore', 'apk')} className="hover:text-cyan-400 transition">Android APK Hub</button></li>
              <li><button onClick={() => onNavigate('explore', 'projects')} className="hover:text-cyan-400 transition">Developer Projects</button></li>
              <li><button onClick={() => onNavigate('sandbox')} className="hover:text-cyan-400 transition">Web Sandbox Runner</button></li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-2.5">Creator Suite</h4>
            <ul className="space-y-2">
              <li><button onClick={() => onNavigate('upload')} className="hover:text-cyan-400 transition">Upload Binary (12 GB)</button></li>
              <li><button onClick={() => onNavigate('library')} className="hover:text-cyan-400 transition">My Cloud Library</button></li>
              <li>
                <button 
                  onClick={() => setPolicyModal({
                    title: "BXB Cloud Publishing Guidelines",
                    content: (
                      <div className="space-y-3 text-xs text-slate-300">
                        <p>All uploads to BXB Cloud must comply with community safety standards:</p>
                        <ul className="list-disc pl-4 space-y-1 text-slate-400">
                          <li>Respect intellectual property, licensing, and creator ownership.</li>
                          <li>No viruses, malicious APK payloads, cryptominers, or spyware.</li>
                          <li>Proof videos or screenshots are encouraged for developer credibility.</li>
                          <li>Every file receives an authentic SHA-256 cryptographic checksum upon upload.</li>
                        </ul>
                      </div>
                    )
                  })}
                  className="hover:text-cyan-400 transition text-left"
                >
                  Publishing Guidelines
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setPolicyModal({
                    title: "Storage Engine & Upload Quotas",
                    content: (
                      <div className="space-y-3 text-xs text-slate-300">
                        <div className="p-3 rounded-xl bg-cyan-950/40 border border-cyan-800/60 font-mono text-[11px] text-cyan-300">
                          <p className="font-bold text-white">BXB CLOUD SPECIFICATIONS:</p>
                          <p>• Maximum Single File: 12 GB (Chunked Resumable Engine)</p>
                          <p>• Configured Daily Files: Unlimited (Fair use abuse-prevention)</p>
                          <p>• Daily Token Allowance: 1,000 Tokens (Owner Accounts: Unlimited)</p>
                          <p>• Multi-part chunk size: 10 MB - 25 MB dynamic slice</p>
                        </div>
                        <p className="text-slate-400">
                          Large files are streamed directly in memory-safe chunks using the Web Crypto API and Node.js file system, eliminating browser memory overflow.
                        </p>
                      </div>
                    )
                  })}
                  className="hover:text-cyan-400 transition text-left"
                >
                  Storage Engine &amp; Quotas
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setPolicyModal({
                    title: "Domain & DNS Architecture",
                    content: (
                      <div className="space-y-3 text-xs text-slate-300">
                        <div className="p-3 rounded-xl bg-slate-900 border border-slate-700 font-mono text-[11px]">
                          <p className="text-cyan-400 font-bold">DOMAIN REGISTRATION SUMMARY:</p>
                          <p className="text-white mt-1">1. Preferred Public Domain: <span className="text-cyan-300 font-bold">bxbcloud.cloud</span></p>
                          <p className="text-slate-400 text-[10px]">.cloud is an ICANN-registered generic TLD. Available for public registration via Namecheap, Cloudflare, Google Domains/Squarespace.</p>
                          <p className="text-white mt-2">2. Private Network Suffix: <span className="text-amber-300 font-bold">bxbcloud.bxb</span></p>
                          <p className="text-slate-400 text-[10px]">.bxb is an internal network namespace or decentralized name. For public Internet traffic, use bxbcloud.cloud.</p>
                        </div>
                        <p className="text-slate-400">
                          To point bxbcloud.cloud to your BXB Cloud deployment, configure a CNAME record pointing to your Google Cloud Run / Firebase custom domain endpoints.
                        </p>
                      </div>
                    )
                  })}
                  className="hover:text-cyan-400 transition text-left text-cyan-400 font-medium"
                >
                  Domain &amp; DNS Setup
                </button>
              </li>
            </ul>
          </div>

          <div>
            <h4 className="font-bold text-white text-xs uppercase tracking-wider mb-2.5">Safety &amp; Legal</h4>
            <ul className="space-y-2">
              <li>
                <button 
                  onClick={() => setPolicyModal({
                    title: "Terms of Service",
                    content: (
                      <p className="text-xs text-slate-300 leading-relaxed">
                        By using BXB Cloud, creators retain full ownership of uploaded packages. Creators warrant that files are free from malware and comply with copyright laws. BXB Cloud reserves the right to suspend accounts distributing malicious payloads.
                      </p>
                    )
                  })}
                  className="hover:text-cyan-400 transition text-left"
                >
                  Terms of Service
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setPolicyModal({
                    title: "Privacy Policy",
                    content: (
                      <p className="text-xs text-slate-300 leading-relaxed">
                        User email addresses and Google profile details are strictly confidential. Public file pages display only chosen custom usernames and display names. We do not sell user data or track browsing sessions outside BXB Cloud.
                      </p>
                    )
                  })}
                  className="hover:text-cyan-400 transition text-left"
                >
                  Privacy Policy
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setPolicyModal({
                    title: "Report Abuse / DMCA",
                    content: (
                      <p className="text-xs text-slate-300 leading-relaxed">
                        Every file download page includes a direct moderation reporting tool. Reports are immediately routed to staff moderators. For legal DMCA inquiries, contact moderation staff through the Operations Console.
                      </p>
                    )
                  })}
                  className="hover:text-cyan-400 transition text-left"
                >
                  Report Abuse / DMCA
                </button>
              </li>
              <li>
                <button 
                  onClick={() => setPolicyModal({
                    title: "Authoritative Cryptographic Integrity",
                    content: (
                      <p className="text-xs text-slate-300 leading-relaxed">
                        Every file uploaded to BXB Cloud is hashed with standard SHA-256 (256-bit Secure Hash Algorithm). The checksum is permanently attached to the file record so downloaders can mathematically confirm no byte tampering has occurred.
                      </p>
                    )
                  })}
                  className="hover:text-cyan-400 transition text-left"
                >
                  Cryptographic Integrity
                </button>
              </li>
            </ul>
          </div>
        </div>

        <div className="max-w-7xl mx-auto pt-6 border-t border-slate-900 flex flex-col sm:flex-row items-center justify-between gap-3 text-[11px] text-slate-500">
          <p>&copy; {new Date().getFullYear()} BXB Cloud. All rights reserved.</p>
          <p className="font-mono text-cyan-400/80">Brand: BXB Cloud • Domain: bxbcloud.cloud • Internal: bxbcloud.bxb</p>
        </div>
      </footer>

      {/* Policy / Documentation Dialog Modal */}
      {policyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-md animate-fade-in">
          <div className="relative w-full max-w-lg rounded-3xl bg-[#0e131f] border border-cyan-500/30 p-6 shadow-2xl space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Info className="w-5 h-5 text-cyan-400" />
                <h3 className="text-base font-bold text-white">{policyModal.title}</h3>
              </div>
              <button 
                onClick={() => setPolicyModal(null)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="py-2">
              {policyModal.content}
            </div>
            <div className="pt-3 border-t border-slate-800 flex justify-end">
              <button 
                onClick={() => setPolicyModal(null)}
                className="px-5 py-2 rounded-xl bg-cyan-500 text-black font-semibold text-xs hover:bg-cyan-400 transition"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Share Modal */}
      {shareFile && (
        <ShareModal
          file={shareFile}
          isOpen={Boolean(shareFile)}
          onClose={() => setShareFile(null)}
        />
      )}
    </div>
  );
};
