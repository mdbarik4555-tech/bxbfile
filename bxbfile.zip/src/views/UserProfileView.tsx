import React, { useState, useEffect } from 'react';
import { 
  User, 
  Calendar, 
  HardDrive, 
  TrendingUp, 
  Globe, 
  ArrowLeft, 
  Loader2, 
  Sparkles,
  Share2 
} from 'lucide-react';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../config/firebase';
import { getUserPublicFiles } from '../services/fileService';
import { UserProfile, FileItem } from '../types';
import { FileCard } from '../components/files/FileCard';
import { formatRelativeTime } from '../utils/format';
import { ShareModal } from '../components/files/ShareModal';

interface UserProfileViewProps {
  username: string;
  onNavigate: (view: string, param?: string) => void;
}

export const UserProfileView: React.FC<UserProfileViewProps> = ({ username, onNavigate }) => {
  const [profile, setProfile] = useState<UserProfile | null>(null);
  const [files, setFiles] = useState<FileItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [shareFile, setShareFile] = useState<FileItem | null>(null);

  useEffect(() => {
    let isMounted = true;
    setLoading(true);
    setError(null);

    const clean = username.toLowerCase().trim();

    async function fetchCreatorData() {
      try {
        // Query users by usernameNormalized
        const q = query(
          collection(db, 'users'),
          where('usernameNormalized', '==', clean)
        );
        const snap = await getDocs(q);

        if (snap.empty) {
          if (isMounted) setError(`Creator @${username} was not found on BXB Cloud.`);
          return;
        }

        const creatorProfile = snap.docs[0].data() as UserProfile;
        if (isMounted) setProfile(creatorProfile);

        // Fetch their public files
        const creatorFiles = await getUserPublicFiles(creatorProfile.username);
        if (isMounted) setFiles(creatorFiles);
      } catch (err) {
        if (isMounted) setError('Failed to load creator profile.');
      } finally {
        if (isMounted) setLoading(false);
      }
    }

    fetchCreatorData();

    return () => {
      isMounted = false;
    };
  }, [username]);

  if (loading) {
    return (
      <div className="min-h-[50vh] flex flex-col items-center justify-center p-12 text-slate-400 gap-3">
        <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
        <p className="text-xs font-mono">Loading creator profile...</p>
      </div>
    );
  }

  if (error || !profile) {
    return (
      <div className="max-w-lg mx-auto px-4 py-16 text-center animate-fade-in">
        <div className="w-16 h-16 rounded-3xl bg-slate-800 flex items-center justify-center text-slate-400 mx-auto mb-4">
          <User className="w-8 h-8" />
        </div>
        <h2 className="text-xl font-bold text-white mb-2">Creator Not Found</h2>
        <p className="text-xs text-slate-400 mb-6">{error || 'This creator page does not exist.'}</p>
        <button
          onClick={() => onNavigate('explore')}
          className="px-5 py-2.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-white transition inline-flex items-center gap-2"
        >
          <ArrowLeft className="w-4 h-4" />
          <span>Explore All Files</span>
        </button>
      </div>
    );
  }

  const totalDownloads = files.reduce((acc, f) => acc + (f.downloadStartCount || 0), 0);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in space-y-8">
      {/* Back button */}
      <button
        onClick={() => onNavigate('explore')}
        className="flex items-center gap-1.5 text-xs text-slate-400 hover:text-cyan-400 transition"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>Back to Explore</span>
      </button>

      {/* Creator Profile Header Card */}
      <div className="glass-panel-glow rounded-3xl p-6 sm:p-8 relative overflow-hidden">
        <div className="flex flex-col sm:flex-row items-start sm:items-center gap-5">
          {profile.avatarUrl ? (
            <img
              src={profile.avatarUrl}
              alt={profile.displayName}
              className="w-20 h-20 rounded-2xl object-cover border-2 border-cyan-500/40 shadow-lg shadow-cyan-500/20"
            />
          ) : (
            <div className="w-20 h-20 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 text-white flex items-center justify-center text-3xl font-extrabold shadow-lg shadow-cyan-500/20">
              {profile.username[0]?.toUpperCase()}
            </div>
          )}

          <div className="min-w-0 flex-1 space-y-1">
            <div className="flex items-center gap-2 flex-wrap">
              <h1 className="text-xl sm:text-2xl font-extrabold text-white">
                {profile.displayName}
              </h1>
              {profile.role === 'admin' && (
                <span className="px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40">
                  STAFF ADMIN
                </span>
              )}
            </div>

            <p className="text-sm font-mono text-cyan-400">@{profile.username}</p>

            <p className="text-xs text-slate-300 max-w-xl leading-relaxed pt-1">
              {profile.bio || 'Creator on BXB Cloud.'}
            </p>

            <div className="flex items-center gap-4 text-xs text-slate-400 pt-2 flex-wrap">
              <span className="flex items-center gap-1">
                <Calendar className="w-3.5 h-3.5 text-slate-500" />
                Joined {formatRelativeTime(profile.createdAt)}
              </span>
              <span>&bull;</span>
              <span className="flex items-center gap-1">
                <HardDrive className="w-3.5 h-3.5 text-purple-400" />
                {files.length} Public Releases
              </span>
              <span>&bull;</span>
              <span className="flex items-center gap-1">
                <TrendingUp className="w-3.5 h-3.5 text-emerald-400" />
                {totalDownloads} Total Downloads
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Creator Releases */}
      <div className="space-y-4">
        <h2 className="text-lg font-bold text-white flex items-center gap-2">
          <span>Published Works by @{profile.username}</span>
          <span className="text-xs font-mono text-cyan-400">({files.length})</span>
        </h2>

        {files.length === 0 ? (
          <div className="py-12 text-center glass-panel rounded-2xl border border-slate-800">
            <p className="text-xs text-slate-400">This creator has not published any public files yet.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {files.map((file) => (
              <FileCard
                key={file.id}
                file={file}
                onOpen={(f) => onNavigate('fileDetail', f.id)}
                onShare={(f) => setShareFile(f)}
              />
            ))}
          </div>
        )}
      </div>

      {shareFile && (
        <ShareModal
          file={shareFile}
          isOpen={Boolean(shareFile)}
          onClose={() => setShareFile(null)}
        />
      )}
    </div>
  );
};
