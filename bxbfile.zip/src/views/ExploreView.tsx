import React, { useState, useEffect } from 'react';
import { 
  Search, 
  Filter, 
  Smartphone, 
  Sparkles, 
  TrendingUp, 
  Clock, 
  ArrowUpDown, 
  Loader2, 
  Compass, 
  X,
  Calendar,
  Layers,
  Tag as TagIcon
} from 'lucide-react';
import { getPublicFiles } from '../services/fileService';
import { FileItem, CATEGORIES } from '../types';
import { FileCard } from '../components/files/FileCard';
import { ShareModal } from '../components/files/ShareModal';

interface ExploreViewProps {
  initialSearch?: string;
  initialCategory?: string;
  onNavigate: (view: string, param?: string) => void;
}

const POPULAR_TAGS = ['apk', 'android', 'tool', 'emulator', 'mod', 'open-source', 'windows', 'game', 'utility', 'react'];

export const ExploreView: React.FC<ExploreViewProps> = ({
  initialSearch = '',
  initialCategory = 'all',
  onNavigate,
}) => {
  const [category, setCategory] = useState(initialCategory);
  const [platform, setPlatform] = useState('all');
  const [dateFilter, setDateFilter] = useState<'all' | 'today' | 'week' | 'month'>('all');
  const [search, setSearch] = useState(initialSearch);
  const [sortBy, setSortBy] = useState<'recent' | 'downloads' | 'name'>('recent');
  const [files, setFiles] = useState<FileItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [shareFile, setShareFile] = useState<FileItem | null>(null);

  // Suggestions state
  const [showSuggestions, setShowSuggestions] = useState(false);

  useEffect(() => {
    let isMounted = true;
    setLoading(true);

    getPublicFiles({
      category: category === 'all' ? undefined : category,
      search: search.trim() || undefined,
      platform: platform === 'all' ? undefined : platform,
      dateFilter: dateFilter,
      sortBy,
      maxResults: 60,
    })
      .then((data) => {
        if (!isMounted) return;
        setFiles(data);
      })
      .catch((err) => {
        console.error('Error querying public files:', err);
      })
      .finally(() => {
        if (isMounted) setLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, [category, platform, dateFilter, search, sortBy]);

  const filteredSuggestions = search.trim().length > 1
    ? POPULAR_TAGS.filter(t => t.toLowerCase().includes(search.toLowerCase()))
    : [];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in space-y-6">
      {/* Page Title & Search Header */}
      <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-cyan-400 font-mono text-xs uppercase tracking-wider mb-1">
            <Compass className="w-4 h-4" />
            <span>Public Global Registry</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
            Explore Files, APKs &amp; Builds
          </h1>
        </div>

        {/* Search input with live suggestion drop */}
        <div className="w-full md:w-80 relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => {
              setSearch(e.target.value);
              setShowSuggestions(true);
            }}
            onFocus={() => setShowSuggestions(true)}
            onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
            placeholder="Search title, tag, creator..."
            className="w-full pl-9 pr-8 py-2 rounded-xl bg-slate-900 border border-slate-700/80 text-xs text-white placeholder-slate-400 focus:border-cyan-400 focus:outline-none"
          />
          {search && (
            <button
              onClick={() => setSearch('')}
              className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          )}

          {/* Search Suggestions Dropdown (Feature 67) */}
          {showSuggestions && filteredSuggestions.length > 0 && (
            <div className="absolute left-0 right-0 top-full mt-1.5 p-2 rounded-xl glass-panel-glow border border-slate-700/80 shadow-2xl z-30">
              <span className="text-[10px] uppercase font-bold text-slate-400 px-2 block mb-1">
                Suggested Tags
              </span>
              {filteredSuggestions.map((sug) => (
                <button
                  key={sug}
                  onClick={() => setSearch(sug)}
                  className="w-full text-left px-2.5 py-1.5 rounded-lg text-xs text-slate-200 hover:bg-slate-800 hover:text-cyan-300 font-mono flex items-center gap-1.5"
                >
                  <TagIcon className="w-3 h-3 text-cyan-400" />
                  <span>#{sug}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Category Pills Slider */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        <button
          onClick={() => setCategory('all')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold shrink-0 transition ${
            category === 'all'
              ? 'bg-cyan-500 text-black shadow-lg shadow-cyan-500/25'
              : 'bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800'
          }`}
        >
          All Categories
        </button>
        {CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setCategory(cat.id)}
            className={`px-3.5 py-2 rounded-xl text-xs font-semibold shrink-0 transition flex items-center gap-1.5 ${
              category === cat.id
                ? 'bg-cyan-500 text-black shadow-lg shadow-cyan-500/25'
                : 'bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:bg-slate-800'
            }`}
          >
            <span>{cat.name}</span>
          </button>
        ))}
      </div>

      {/* Tag-based Discovery Row (Feature 71) */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
        <span className="text-[11px] text-slate-500 uppercase font-mono mr-1">Trending:</span>
        {POPULAR_TAGS.map((tag) => (
          <button
            key={tag}
            onClick={() => setSearch(tag)}
            className={`px-2.5 py-1 rounded-lg text-[11px] font-mono shrink-0 transition ${
              search.toLowerCase() === tag
                ? 'bg-cyan-500 text-black font-bold'
                : 'bg-slate-900/60 hover:bg-slate-800 text-slate-400 hover:text-cyan-300 border border-slate-800'
            }`}
          >
            #{tag}
          </button>
        ))}
      </div>

      {/* Filter and Sort Toolbar (Feature 74, 75, 76, 77) */}
      <div className="flex flex-wrap items-center justify-between gap-3 pt-2 border-t border-slate-800/80 text-xs text-slate-400">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-1.5">
            <span>Platform:</span>
            <select
              value={platform}
              onChange={(e) => setPlatform(e.target.value)}
              className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-slate-200 focus:outline-none focus:border-cyan-400"
            >
              <option value="all">All Platforms</option>
              <option value="android">Android</option>
              <option value="windows">Windows</option>
              <option value="web">Web</option>
              <option value="universal">Universal</option>
            </select>
          </div>

          <div className="flex items-center gap-1.5">
            <span>Date:</span>
            <select
              value={dateFilter}
              onChange={(e) => setDateFilter(e.target.value as any)}
              className="bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1 text-slate-200 focus:outline-none focus:border-cyan-400"
            >
              <option value="all">All Time</option>
              <option value="today">Today</option>
              <option value="week">This Week</option>
              <option value="month">This Month</option>
            </select>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <span>Sort:</span>
          <button
            onClick={() => setSortBy('recent')}
            className={`px-2.5 py-1 rounded-lg transition ${
              sortBy === 'recent' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'hover:text-white'
            }`}
          >
            Newest
          </button>
          <button
            onClick={() => setSortBy('downloads')}
            className={`px-2.5 py-1 rounded-lg transition ${
              sortBy === 'downloads' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'hover:text-white'
            }`}
          >
            Most Downloaded
          </button>
          <button
            onClick={() => setSortBy('name')}
            className={`px-2.5 py-1 rounded-lg transition ${
              sortBy === 'name' ? 'bg-cyan-500/20 text-cyan-300 font-semibold' : 'hover:text-white'
            }`}
          >
            A-Z
          </button>
        </div>
      </div>

      {/* Grid of Files */}
      {loading ? (
        <div className="min-h-[40vh] flex flex-col items-center justify-center p-12 text-slate-400 gap-3">
          <Loader2 className="w-8 h-8 animate-spin text-cyan-400" />
          <p className="text-xs font-mono">Fetching published registry...</p>
        </div>
      ) : files.length === 0 ? (
        <div className="text-center py-16 px-4 glass-panel rounded-3xl border border-slate-800">
          <div className="w-14 h-14 rounded-2xl bg-slate-800 flex items-center justify-center text-slate-400 mx-auto mb-3">
            <Compass className="w-7 h-7" />
          </div>
          <h3 className="text-base font-bold text-white mb-1">No Files Found</h3>
          <p className="text-xs text-slate-400 max-w-sm mx-auto mb-4">
            {search || category !== 'all' || platform !== 'all' || dateFilter !== 'all'
              ? 'Try relaxing your filter criteria or searching for different keywords.'
              : 'Be the first creator to upload a file to BXB Cloud!'}
          </p>
          <button
            onClick={() => {
              setSearch('');
              setCategory('all');
              setPlatform('all');
              setDateFilter('all');
            }}
            className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-xs text-slate-200 transition"
          >
            Reset All Filters
          </button>
        </div>
      ) : (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {files.map((file) => (
              <FileCard
                key={file.id}
                file={file}
                onOpen={(f) => onNavigate('fileDetail', f.id)}
                onShare={(f) => setShareFile(f)}
                onAuthorClick={(username) => onNavigate('userProfile', username)}
              />
            ))}
          </div>

          <div className="text-center text-xs text-slate-500 pt-4">
            Showing {files.length} public release{files.length === 1 ? '' : 's'} &bull; Indexed in real-time
          </div>
        </div>
      )}

      {/* Share Modal */}
      {shareFile && (
        <ShareModal
          file={shareFile}
          isOpen={Boolean(shareFile)}
          onClose={() => setShareFile(null)}
        />
      )}
    </div>
  );
};
