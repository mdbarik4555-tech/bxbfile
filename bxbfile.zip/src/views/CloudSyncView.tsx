import React, { useState, useEffect } from 'react';
import {
  RefreshCw,
  Cloud,
  CheckCircle2,
  Smartphone,
  Monitor,
  Tablet,
  Laptop,
  HardDrive,
  Download,
  UploadCloud,
  Layers,
  Settings,
  AlertCircle,
  Copy,
  Check,
  Plus,
  ShieldCheck,
  Clock,
  ArrowRight,
  Database,
  Sliders,
  FolderArchive,
  FileCheck,
  Sparkles,
  Loader2,
  Trash2,
  Info,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import {
  cloudSync,
  SyncStatus,
  SyncedDevice,
  SyncConfiguration,
  SyncItem,
} from '../services/cloudSyncService';
import { formatRelativeTime } from '../utils/format';

interface CloudSyncViewProps {
  onNavigate: (view: string, param?: string) => void;
}

export const CloudSyncView: React.FC<CloudSyncViewProps> = ({ onNavigate }) => {
  const { user, userProfile, signIn } = useAuth();
  const [syncStatus, setSyncStatus] = useState<SyncStatus>({
    status: 'online',
    cloudHost: 'bxbfile.bxb / bxbcloud.cloud',
    connected: true,
    totalSyncedEntries: 0,
    activeDevicesCount: 1,
    lastSyncAt: null,
    revision: 1,
    cloudStorageHealth: 'optimal',
    conflictResolutionStrategy: 'smart_merge',
  });

  const [devices, setDevices] = useState<SyncedDevice[]>([]);
  const [syncConfig, setSyncConfig] = useState<SyncConfiguration>(cloudSync.getSyncConfig());
  const [pendingQueue, setPendingQueue] = useState<SyncItem[]>([]);
  const [syncHistory, setSyncHistory] = useState<SyncItem[]>([]);
  const [isSyncingNow, setIsSyncingNow] = useState(false);
  const [syncSuccessMsg, setSyncSuccessMsg] = useState<string | null>(null);
  const [syncErrorMsg, setSyncErrorMsg] = useState<string | null>(null);

  // Pairing Modal
  const [pairingModalOpen, setPairingModalOpen] = useState(false);
  const [pairingCodeInput, setPairingCodeInput] = useState('');
  const [pairingDeviceName, setPairingDeviceName] = useState('');
  const [pairingDeviceType, setPairingDeviceType] = useState<'mobile' | 'desktop' | 'tablet'>('mobile');
  const [pairingSubmitting, setPairingSubmitting] = useState(false);

  // Snapshot file input
  const fileInputRef = React.useRef<HTMLInputElement>(null);

  useEffect(() => {
    const unsub = cloudSync.subscribe(status => setSyncStatus(status));
    setPendingQueue(cloudSync.getPendingQueue());

    if (user) {
      cloudSync.fetchStatus(user.uid).then(st => setSyncStatus(st));
      cloudSync.getDevices(user.uid).then(devs => setDevices(devs));
      cloudSync.pullCloudChanges(user.uid).then(entries => setSyncHistory(entries));
    }
    return unsub;
  }, [user]);

  const handleManualSync = async () => {
    if (!user) {
      await signIn();
      return;
    }
    setIsSyncingNow(true);
    setSyncSuccessMsg(null);
    setSyncErrorMsg(null);

    try {
      // 1. Push pending local changes
      await cloudSync.pushPendingChanges(user.uid, `${navigator.platform} Browser`);
      // 2. Pull latest cloud changes
      const pulled = await cloudSync.pullCloudChanges(user.uid);
      setSyncHistory(pulled);
      // 3. Refresh status & devices
      const updatedStatus = await cloudSync.fetchStatus(user.uid);
      setSyncStatus(updatedStatus);
      const updatedDevices = await cloudSync.getDevices(user.uid);
      setDevices(updatedDevices);
      setPendingQueue(cloudSync.getPendingQueue());

      setSyncSuccessMsg(`Cloud Sync completed! All files, APKs, and settings are up to date with bxbfile.bxb.`);
      setTimeout(() => setSyncSuccessMsg(null), 4000);
    } catch (err: any) {
      setSyncErrorMsg(err.message || 'Cloud Sync failed. Please check network.');
      setTimeout(() => setSyncErrorMsg(null), 4000);
    } finally {
      setIsSyncingNow(false);
    }
  };

  const handleToggleCategory = (categoryKey: keyof SyncConfiguration['syncCategories']) => {
    const updated: SyncConfiguration = {
      ...syncConfig,
      syncCategories: {
        ...syncConfig.syncCategories,
        [categoryKey]: !syncConfig.syncCategories[categoryKey],
      },
    };
    setSyncConfig(updated);
    cloudSync.saveSyncConfig(updated);
  };

  const handlePairSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setPairingSubmitting(true);
    try {
      const newDev = await cloudSync.pairDevice(
        user.uid,
        pairingCodeInput || Math.floor(100000 + Math.random() * 900000).toString(),
        pairingDeviceName || 'New Companion Device',
        pairingDeviceType
      );
      setDevices(prev => [newDev, ...prev]);
      setPairingModalOpen(false);
      setPairingCodeInput('');
      setPairingDeviceName('');
      setSyncSuccessMsg(`Paired device "${newDev.deviceName}" added to Cloud Sync cluster.`);
      setTimeout(() => setSyncSuccessMsg(null), 3000);
    } catch (err: any) {
      setSyncErrorMsg(err.message || 'Pairing failed.');
      setTimeout(() => setSyncErrorMsg(null), 4000);
    } finally {
      setPairingSubmitting(false);
    }
  };

  const handleExportSnapshot = async () => {
    if (!user) {
      await signIn();
      return;
    }
    try {
      await cloudSync.exportSnapshot(user.uid);
      setSyncSuccessMsg('Cloud Sync Snapshot (.bxb) downloaded successfully!');
      setTimeout(() => setSyncSuccessMsg(null), 3000);
    } catch (err: any) {
      setSyncErrorMsg(err.message || 'Snapshot export failed.');
      setTimeout(() => setSyncErrorMsg(null), 4000);
    }
  };

  const handleRestoreSnapshot = async (file: File) => {
    if (!user) {
      await signIn();
      return;
    }
    setIsSyncingNow(true);
    try {
      const res = await cloudSync.restoreSnapshot(user.uid, file);
      setSyncSuccessMsg(res.message || 'Snapshot restored!');
      await handleManualSync();
    } catch (err: any) {
      setSyncErrorMsg(err.message || 'Failed to restore snapshot.');
      setTimeout(() => setSyncErrorMsg(null), 4000);
    } finally {
      setIsSyncingNow(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in text-white space-y-8">
      {/* Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-6 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 uppercase tracking-wider">
              bxbfile.bxb Core
            </span>
            <span className="text-xs text-slate-400 font-mono">Real-Time Cloud Synchronization</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-white flex items-center gap-3">
            <RefreshCw className="w-7 h-7 text-cyan-400" />
            <span>BXB Cloud Sync Hub</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1 max-w-2xl leading-relaxed">
            Synchronize your published APKs, developer libraries, offline work, and settings seamlessly across all devices with cryptographic revision checks.
          </p>
        </div>

        <div className="flex items-center gap-2.5">
          <button
            onClick={() => setPairingModalOpen(true)}
            className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-semibold text-slate-200 flex items-center gap-2 transition"
          >
            <Plus className="w-4 h-4 text-cyan-400" />
            <span>Pair Device</span>
          </button>
          <button
            onClick={handleManualSync}
            disabled={isSyncingNow}
            className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 font-bold text-xs text-white flex items-center gap-2 transition shadow-lg shadow-cyan-500/25 active:scale-95"
          >
            <RefreshCw className={`w-4 h-4 ${isSyncingNow ? 'animate-spin' : ''}`} />
            <span>{isSyncingNow ? 'Syncing Now...' : 'Sync Now'}</span>
          </button>
        </div>
      </div>

      {/* Notification Alerts */}
      {syncSuccessMsg && (
        <div className="p-4 rounded-2xl bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs flex items-center justify-between animate-fade-in font-medium">
          <div className="flex items-center gap-2.5">
            <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" />
            <span>{syncSuccessMsg}</span>
          </div>
          <button onClick={() => setSyncSuccessMsg(null)} className="text-slate-400 hover:text-white">&times;</button>
        </div>
      )}

      {syncErrorMsg && (
        <div className="p-4 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-300 text-xs flex items-center justify-between animate-fade-in font-medium">
          <div className="flex items-center gap-2.5">
            <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
            <span>{syncErrorMsg}</span>
          </div>
          <button onClick={() => setSyncErrorMsg(null)} className="text-slate-400 hover:text-white">&times;</button>
        </div>
      )}

      {/* Status Highlights Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="glass-panel rounded-2xl p-4 border border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Sync Engine State</span>
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-pulse"></span>
          </div>
          <p className="text-xl font-extrabold text-white font-mono flex items-center gap-2">
            <span>Connected</span>
          </p>
          <p className="text-[11px] text-cyan-400 mt-2 font-mono truncate">
            Host: bxbfile.bxb
          </p>
        </div>

        <div className="glass-panel rounded-2xl p-4 border border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Last Synchronized</span>
            <Clock className="w-4 h-4 text-cyan-400" />
          </div>
          <p className="text-lg font-bold text-white font-mono">
            {syncStatus.lastSyncAt ? formatRelativeTime(syncStatus.lastSyncAt) : 'Just Now'}
          </p>
          <p className="text-[11px] text-slate-500 mt-2">
            Revision #{syncStatus.revision || 1}
          </p>
        </div>

        <div className="glass-panel rounded-2xl p-4 border border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Active Cluster Devices</span>
            <Smartphone className="w-4 h-4 text-purple-400" />
          </div>
          <p className="text-xl font-extrabold text-white font-mono">
            {devices.length || 1} Device{devices.length === 1 ? '' : 's'}
          </p>
          <p className="text-[11px] text-purple-400 mt-2 font-mono">
            Multi-device sync enabled
          </p>
        </div>

        <div className="glass-panel rounded-2xl p-4 border border-slate-800">
          <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
            <span>Pending Mutations</span>
            <HardDrive className="w-4 h-4 text-amber-400" />
          </div>
          <p className="text-xl font-extrabold text-white font-mono">
            {pendingQueue.length} Pending
          </p>
          <p className="text-[11px] text-amber-300 mt-2 font-mono">
            {pendingQueue.length === 0 ? 'All local edits flushed' : 'Will sync automatically'}
          </p>
        </div>
      </div>

      {/* Main Grid: Devices + Selective Sync + Snapshots */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Col: Synced Devices & Pairing (7 cols) */}
        <div className="lg:col-span-7 space-y-6">
          <div className="p-6 rounded-3xl glass-panel-glow border border-slate-800 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Smartphone className="w-5 h-5 text-cyan-400" />
                <h3 className="font-bold text-white text-base">Linked Cluster Devices</h3>
              </div>
              <span className="text-xs text-slate-400 font-mono">
                {devices.length} registered
              </span>
            </div>

            <div className="space-y-3">
              {devices.map((dev) => (
                <div
                  key={dev.deviceId}
                  className="p-4 rounded-2xl bg-slate-900/70 border border-slate-800 flex items-center justify-between text-xs gap-3"
                >
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-cyan-400">
                      {dev.deviceType === 'mobile' ? (
                        <Smartphone className="w-5 h-5" />
                      ) : dev.deviceType === 'tablet' ? (
                        <Tablet className="w-5 h-5" />
                      ) : (
                        <Monitor className="w-5 h-5" />
                      )}
                    </div>
                    <div>
                      <div className="font-bold text-white flex items-center gap-2">
                        <span>{dev.deviceName}</span>
                        <span className="px-2 py-0.2 rounded-full text-[9px] bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 uppercase font-bold">
                          {dev.status}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-400 font-mono mt-0.5">
                        {dev.os} &bull; Paired: {new Date(dev.pairedAt).toLocaleDateString()}
                      </div>
                      <div className="text-[9px] text-slate-500 font-mono">
                        Token: {dev.syncToken?.slice(0, 16)}...
                      </div>
                    </div>
                  </div>

                  <div className="text-right shrink-0">
                    <span className="text-[10px] text-slate-500 font-mono block">Last synced:</span>
                    <span className="text-cyan-300 font-mono text-[11px] font-semibold">
                      {formatRelativeTime(dev.lastSyncAt)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Sync History / Audit Activity */}
          <div className="p-6 rounded-3xl glass-panel border border-slate-800 space-y-4">
            <h3 className="font-bold text-white text-sm flex items-center gap-2">
              <Clock className="w-4 h-4 text-cyan-400" />
              <span>Recent Cloud Sync Activity Log</span>
            </h3>

            {syncHistory.length === 0 ? (
              <p className="text-xs text-slate-500 text-center py-6">
                No recent remote changes pulled. Click "Sync Now" to verify live delta logs.
              </p>
            ) : (
              <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                {syncHistory.map((item, idx) => (
                  <div
                    key={idx}
                    className="p-3 rounded-xl bg-slate-900/50 border border-slate-800/80 flex items-center justify-between text-xs"
                  >
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
                      <span className="font-semibold text-slate-200 uppercase font-mono text-[10px]">
                        {item.entityType}
                      </span>
                      <span className="text-slate-400 truncate max-w-xs">{item.entityId}</span>
                    </div>
                    <span className="text-[10px] text-slate-500 font-mono">
                      {formatRelativeTime(item.timestamp)}
                    </span>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Right Col: Selective Sync & Snapshot Tools (5 cols) */}
        <div className="lg:col-span-5 space-y-6">
          {/* Selective Sync Options */}
          <div className="p-6 rounded-3xl glass-panel-glow border border-slate-800 space-y-4 text-xs">
            <div className="flex items-center justify-between">
              <h3 className="font-bold text-white text-sm flex items-center gap-2">
                <Sliders className="w-4 h-4 text-cyan-400" />
                <span>Selective Sync Categories</span>
              </h3>
            </div>
            <p className="text-[11px] text-slate-400">
              Choose which file categories and metadata are replicated to this client device.
            </p>

            <div className="space-y-2.5 pt-1">
              {[
                { key: 'apks' as const, label: 'Android APKs & Packages', desc: 'Sync mobile installation builds' },
                { key: 'files' as const, label: 'Published Binaries & ZIPs', desc: 'Sync full downloads catalog' },
                { key: 'folders' as const, label: 'Folders & Directories', desc: 'Sync folder tree organization' },
                { key: 'settings' as const, label: '100 Settings & Preferences', desc: 'Sync custom theme & identity' },
                { key: 'media' as const, label: 'Media Covers & Proofs', desc: 'Sync video posters & screenshots' },
              ].map((opt) => (
                <div
                  key={opt.key}
                  onClick={() => handleToggleCategory(opt.key)}
                  className="p-3 rounded-2xl bg-slate-900/60 border border-slate-800 hover:border-slate-700 transition flex items-center justify-between cursor-pointer"
                >
                  <div>
                    <h4 className="font-semibold text-white">{opt.label}</h4>
                    <p className="text-[10px] text-slate-400">{opt.desc}</p>
                  </div>
                  <div
                    className={`w-9 h-5 rounded-full transition-colors relative p-0.5 ${
                      syncConfig.syncCategories[opt.key] ? 'bg-cyan-500' : 'bg-slate-800'
                    }`}
                  >
                    <div
                      className={`w-4 h-4 rounded-full bg-white transition-transform ${
                        syncConfig.syncCategories[opt.key] ? 'translate-x-4' : 'translate-x-0'
                      }`}
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Snapshot Archive Tool (.bxb file) */}
          <div className="p-6 rounded-3xl glass-panel border border-cyan-500/30 space-y-4 text-xs">
            <div className="flex items-center gap-2">
              <FolderArchive className="w-5 h-5 text-cyan-400" />
              <div>
                <h3 className="font-bold text-white text-sm">Cloud Sync Snapshot Archive</h3>
                <p className="text-[11px] text-slate-400 font-mono">Format: .bxb snapshot</p>
              </div>
            </div>

            <p className="text-[11px] text-slate-300 leading-relaxed">
              Export an encrypted, portable snapshot of all your library records, folder structures, and preferences into a standalone <code className="text-cyan-400 font-mono">.bxb</code> file, or restore on a new machine.
            </p>

            <div className="grid grid-cols-2 gap-2 pt-1">
              <button
                onClick={handleExportSnapshot}
                className="py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-200 font-semibold flex items-center justify-center gap-1.5 transition"
              >
                <Download className="w-4 h-4 text-cyan-400" />
                <span>Export .bxb</span>
              </button>

              <button
                onClick={() => fileInputRef.current?.click()}
                className="py-2.5 px-3 rounded-xl bg-cyan-950/40 hover:bg-cyan-900/60 border border-cyan-800/60 text-cyan-300 font-semibold flex items-center justify-center gap-1.5 transition"
              >
                <UploadCloud className="w-4 h-4" />
                <span>Restore .bxb</span>
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept=".bxb,.json"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handleRestoreSnapshot(e.target.files[0]);
                  }
                }}
              />
            </div>
          </div>
        </div>
      </div>

      {/* Modal: Pair New Device with 6-Digit PIN */}
      {pairingModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
          <div className="w-full max-w-sm glass-panel-glow rounded-3xl p-6 border border-cyan-500/40 text-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="font-bold text-white text-sm flex items-center gap-2">
                <Smartphone className="w-4 h-4 text-cyan-400" />
                <span>Pair New Device to Cluster</span>
              </h3>
              <button onClick={() => setPairingModalOpen(false)} className="text-slate-400 hover:text-white">
                &times;
              </button>
            </div>

            <form onSubmit={handlePairSubmit} className="space-y-4">
              <div>
                <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                  Device Name
                </label>
                <input
                  type="text"
                  required
                  value={pairingDeviceName}
                  onChange={(e) => setPairingDeviceName(e.target.value)}
                  placeholder="e.g. Pixel 9 Pro or MacBook Air"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                  Device Hardware Type
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {(['mobile', 'desktop', 'tablet'] as const).map(t => (
                    <button
                      key={t}
                      type="button"
                      onClick={() => setPairingDeviceType(t)}
                      className={`p-2 rounded-xl border text-center transition capitalize font-semibold ${
                        pairingDeviceType === t
                          ? 'border-cyan-400 bg-cyan-950/40 text-cyan-300'
                          : 'border-slate-800 bg-slate-900 text-slate-400'
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                  6-Digit Pairing PIN (Optional)
                </label>
                <input
                  type="text"
                  maxLength={6}
                  value={pairingCodeInput}
                  onChange={(e) => setPairingCodeInput(e.target.value.replace(/[^0-9]/g, ''))}
                  placeholder="e.g. 849201"
                  className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-center font-mono text-base font-bold tracking-widest text-cyan-300 focus:outline-none focus:border-cyan-400"
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setPairingModalOpen(false)}
                  className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={pairingSubmitting || !pairingDeviceName.trim()}
                  className="px-4 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 font-bold text-white transition flex items-center gap-1.5"
                >
                  {pairingSubmitting && <Loader2 className="w-3.5 h-3.5 animate-spin" />}
                  <span>Add Device</span>
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
