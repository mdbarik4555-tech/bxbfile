import React, { useState, useRef, useEffect } from 'react';
import { 
  UploadCloud, 
  FileCheck, 
  X, 
  ShieldCheck, 
  AlertCircle, 
  Loader2, 
  Copy, 
  Check, 
  ArrowRight, 
  Image as ImageIcon, 
  Film, 
  Globe, 
  Eye,
  EyeOff, 
  Lock,
  Sparkles,
  Youtube,
  Trash2,
  FileText,
  DollarSign,
  Zap,
  RotateCw,
  Ban,
  Clock,
  Layers,
  CheckCircle2,
  ExternalLink,
  Folder,
  Calendar,
  Link as LinkIcon,
  Pause,
  Play,
  Save,
  Sliders,
  History,
  FolderPlus,
  RefreshCw
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useSiteConfig } from '../context/SiteConfigContext';
import { 
  uploadAndPublishFile, 
  UploadController,
  getFolders 
} from '../services/fileService';
import { 
  FileItem, 
  UploadProgressState, 
  UploadLifecycleState,
  VisibilityMode, 
  PublicationStatus,
  CATEGORIES,
  FolderItem 
} from '../types';
import { 
  formatBytes, 
  getFileExtension, 
  calculateSha256 
} from '../utils/format';

interface UploadViewProps {
  onNavigate: (view: string, param?: string) => void;
  onUploadSuccess: (file: FileItem) => void;
}

export interface AdvancedQueueItem {
  id: string;
  file: File;
  name: string;
  size: number;
  type: string;
  ext: string;
  title: string;
  description: string;
  category: string;
  tags: string[];
  version: string;
  platform: string;
  visibility: VisibilityMode;
  password?: string;
  hasPassword?: boolean;
  countdownSeconds?: number | null;
  expiresAt?: string | null;
  maxDownloads?: number | null;
  redirectUrl?: string | null;
  customLogoUrl?: string | null;
  folderId?: string | null;
  isPaid?: boolean;
  price?: number;
  currency?: string;
  progress: number;
  bytesTransferred: number;
  speedBps?: number;
  status: UploadLifecycleState;
  error?: string;
  result?: FileItem;
  controller?: UploadController;
  previewUrl?: string;
  checksum?: string;
}

const LOCAL_UPLOAD_DEFAULTS_KEY = 'bxb_upload_form_defaults';

export const UploadView: React.FC<UploadViewProps> = ({ onNavigate, onUploadSuccess }) => {
  const { 
    user, 
    userProfile, 
    isOwner, 
    dailyTokens, 
    uploadQuota, 
    refreshQuotas, 
    signIn,
    setAuthModalOpen 
  } = useAuth();
  const { countdownDefaults, sharingDefaults } = useSiteConfig();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const folderInputRef = useRef<HTMLInputElement>(null);
  const coverInputRef = useRef<HTMLInputElement>(null);
  const videoInputRef = useRef<HTMLInputElement>(null);
  const screenshotsInputRef = useRef<HTMLInputElement>(null);
  const logoInputRef = useRef<HTMLInputElement>(null);

  // View Mode: 'simple' single item focus or 'bulk' multi-queue manager
  const [viewMode, setViewMode] = useState<'single' | 'bulk'>('single');

  // Queue of files
  const [queue, setQueue] = useState<AdvancedQueueItem[]>([]);
  const [selectedQueueIndex, setSelectedQueueIndex] = useState<number>(0);

  // Active / Selected item form fields
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [category, setCategory] = useState<string>(CATEGORIES[0].id);
  const [tagsStr, setTagsStr] = useState('');
  const [version, setVersion] = useState('1.0.0');
  const [platform, setPlatform] = useState('Universal');
  const [visibility, setVisibility] = useState<VisibilityMode>('public');
  const [folderId, setFolderId] = useState<string>('');
  
  // Advanced Protection & Security Controls
  const [enablePassword, setEnablePassword] = useState(false);
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  
  // Countdown settings
  const [countdownMode, setCountdownMode] = useState<'disabled' | '10' | '15' | '20' | 'custom'>('15');
  const [customCountdown, setCustomCountdown] = useState<number>(15);

  // Expiration & Limits
  const [expiresAt, setExpiresAt] = useState<string>('');
  const [maxDownloads, setMaxDownloads] = useState<string>('');
  const [redirectUrl, setRedirectUrl] = useState<string>('');
  const [customLogoUrl, setCustomLogoUrl] = useState<string>('');

  // Media
  const [coverImage, setCoverImage] = useState<File | null>(null);
  const [coverPreview, setCoverPreview] = useState<string | null>(null);
  const [proofVideo, setProofVideo] = useState<File | null>(null);
  const [screenshots, setScreenshots] = useState<File[]>([]);
  const [screenshotPreviews, setScreenshotPreviews] = useState<string[]>([]);
  const [youtubeUrl, setYoutubeUrl] = useState('');
  const [creatorWebsite, setCreatorWebsite] = useState('');

  // Paid Download System
  const [isPaid, setIsPaid] = useState(false);
  const [price, setPrice] = useState(49);
  const [currency, setCurrency] = useState('INR');

  // Available user folders
  const [userFolders, setUserFolders] = useState<FolderItem[]>([]);

  // State
  const [isUploadingAll, setIsUploadingAll] = useState(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [completedFile, setCompletedFile] = useState<FileItem | null>(null);
  const [copiedLink, setCopiedLink] = useState(false);

  // Load defaults from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem(LOCAL_UPLOAD_DEFAULTS_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (parsed.visibility) setVisibility(parsed.visibility);
        if (parsed.category) setCategory(parsed.category);
        if (parsed.countdownMode) setCountdownMode(parsed.countdownMode);
        if (parsed.customCountdown) setCustomCountdown(parsed.customCountdown);
      } else {
        if (sharingDefaults?.defaultVisibility) setVisibility(sharingDefaults.defaultVisibility);
        if (countdownDefaults) {
          if (!countdownDefaults.enabled) setCountdownMode('disabled');
          else if ([10, 15, 20].includes(countdownDefaults.defaultSeconds)) {
            setCountdownMode(String(countdownDefaults.defaultSeconds) as any);
          } else {
            setCountdownMode('custom');
            setCustomCountdown(countdownDefaults.defaultSeconds);
          }
        }
      }
    } catch {}
  }, [sharingDefaults, countdownDefaults]);

  // Load user folders
  useEffect(() => {
    if (user?.uid) {
      getFolders(user.uid).then(f => setUserFolders(f)).catch(() => {});
    }
  }, [user]);

  // Save current preferences as user default
  const handleSaveDefaults = () => {
    const defaults = {
      visibility,
      category,
      countdownMode,
      customCountdown,
      platform,
    };
    try {
      localStorage.setItem(LOCAL_UPLOAD_DEFAULTS_KEY, JSON.stringify(defaults));
      setErrorMessage(null);
      alert('Default upload preferences saved to your profile!');
    } catch {
      setErrorMessage('Could not save defaults to storage.');
    }
  };

  const getEffectiveCountdown = (): number | null => {
    if (countdownMode === 'disabled') return 0;
    if (countdownMode === '10') return 10;
    if (countdownMode === '15') return 15;
    if (countdownMode === '20') return 20;
    if (countdownMode === 'custom') return Math.max(1, Math.min(120, customCountdown || 15));
    return null;
  };

  // Add files to queue (handles multiple files & folder drops)
  const addFilesToQueue = (files: File[]) => {
    const effectiveCountdown = getEffectiveCountdown();
    const newItems: AdvancedQueueItem[] = files.map((file, idx) => {
      const ext = getFileExtension(file.name);
      const rawName = file.name.replace(/\.[^/.]+$/, '');
      const cleanTitle = rawName.replace(/[-_.]+/g, ' ');
      const formattedTitle = cleanTitle.charAt(0).toUpperCase() + cleanTitle.slice(1);
      
      let detectedCategory = category;
      let detectedPlatform = platform;
      if (ext === 'apk') {
        detectedCategory = 'apk';
        detectedPlatform = 'Android 8.0+';
      } else if (['zip', 'rar', '7z', 'tar', 'gz'].includes(ext)) {
        detectedCategory = 'projects';
      } else if (['exe', 'msi'].includes(ext)) {
        detectedCategory = 'windows';
        detectedPlatform = 'Windows 10/11';
      } else if (['html', 'js', 'json'].includes(ext)) {
        detectedCategory = 'web-apps';
        detectedPlatform = 'Web';
      } else if (['mp4', 'webm', 'mov'].includes(ext)) {
        detectedCategory = 'media';
      }

      // Check duplicates in existing queue
      const isDuplicate = queue.some(q => q.name === file.name && q.size === file.size);
      const safeTitle = isDuplicate ? `${formattedTitle} (Copy ${Date.now().toString().slice(-4)})` : formattedTitle;

      let preview: string | undefined = undefined;
      if (file.type.startsWith('image/')) {
        preview = URL.createObjectURL(file);
      }

      return {
        id: `queue_${Date.now()}_${idx}_${Math.random().toString(36).substring(2, 7)}`,
        file,
        name: file.name,
        size: file.size,
        type: file.type || 'application/octet-stream',
        ext,
        title: safeTitle,
        description: '',
        category: detectedCategory,
        tags: [ext, detectedCategory].filter(Boolean),
        version: '1.0.0',
        platform: detectedPlatform,
        visibility,
        password: enablePassword ? password : '',
        hasPassword: enablePassword && Boolean(password.trim()),
        countdownSeconds: effectiveCountdown,
        expiresAt: expiresAt || null,
        maxDownloads: maxDownloads ? parseInt(maxDownloads, 10) : null,
        redirectUrl: redirectUrl || null,
        customLogoUrl: customLogoUrl || null,
        folderId: folderId || null,
        isPaid,
        price,
        currency,
        progress: 0,
        bytesTransferred: 0,
        status: 'queued',
        previewUrl: preview,
      };
    });

    setQueue(prev => {
      const merged = [...prev, ...newItems];
      if (prev.length === 0 && newItems.length > 0) {
        syncFormToItem(newItems[0]);
      }
      return merged;
    });

    if (newItems.length > 1) {
      setViewMode('bulk');
    }
  };

  const syncFormToItem = (item: AdvancedQueueItem) => {
    setTitle(item.title);
    setDescription(item.description);
    setCategory(item.category);
    setTagsStr(item.tags.join(', '));
    setVersion(item.version);
    setPlatform(item.platform);
    setVisibility(item.visibility);
    setEnablePassword(Boolean(item.hasPassword));
    setPassword(item.password || '');
    setFolderId(item.folderId || '');
    setExpiresAt(item.expiresAt || '');
    setMaxDownloads(item.maxDownloads ? String(item.maxDownloads) : '');
    setRedirectUrl(item.redirectUrl || '');
    setCustomLogoUrl(item.customLogoUrl || '');
    setIsPaid(Boolean(item.isPaid));
    setPrice(item.price || 49);
    setCurrency(item.currency || 'INR');
  };

  const syncItemToForm = (index: number) => {
    setQueue(prev => prev.map((item, i) => {
      if (i !== index) return item;
      const effectiveCountdown = getEffectiveCountdown();
      return {
        ...item,
        title,
        description,
        category,
        tags: tagsStr.split(',').map(t => t.trim().toLowerCase()).filter(Boolean),
        version,
        platform,
        visibility,
        hasPassword: enablePassword && Boolean(password.trim()),
        password: enablePassword ? password : '',
        countdownSeconds: effectiveCountdown,
        expiresAt: expiresAt || null,
        maxDownloads: maxDownloads ? parseInt(maxDownloads, 10) : null,
        redirectUrl: redirectUrl ? redirectUrl.trim() : null,
        customLogoUrl: customLogoUrl ? customLogoUrl.trim() : null,
        folderId: folderId || null,
        isPaid,
        price,
        currency,
      };
    }));
  };

  const handleSelectQueueItem = (index: number) => {
    syncItemToForm(selectedQueueIndex);
    setSelectedQueueIndex(index);
    if (queue[index]) {
      syncFormToItem(queue[index]);
    }
  };

  const handleRemoveFromQueue = (index: number) => {
    setQueue(prev => {
      const target = prev[index];
      if (target?.controller) {
        target.controller.cancel();
      }
      const updated = prev.filter((_, i) => i !== index);
      if (selectedQueueIndex >= updated.length) {
        setSelectedQueueIndex(Math.max(0, updated.length - 1));
        if (updated.length > 0) syncFormToItem(updated[Math.max(0, updated.length - 1)]);
      } else if (updated.length > 0) {
        syncFormToItem(updated[selectedQueueIndex]);
      }
      return updated;
    });
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      addFilesToQueue(Array.from(e.dataTransfer.files));
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      addFilesToQueue(Array.from(e.target.files));
    }
  };

  // Upload single item
  const uploadSingleItem = async (index: number) => {
    if (!user || !userProfile) {
      setAuthModalOpen(true);
      return;
    }

    const item = queue[index];
    if (!item || item.status === 'ready' || item.status === 'uploading') return;

    // Unlimited File Uploads - No token gates
    const controller = new UploadController();
    
    setQueue(prev => prev.map((q, i) => i === index ? { 
      ...q, 
      status: 'uploading', 
      controller,
      error: undefined 
    } : q));

    try {
      const result = await uploadAndPublishFile(
        {
          file: item.file,
          userId: user.uid,
          userEmail: user.email || undefined,
          userProfile: {
            username: userProfile.username,
            displayName: userProfile.displayName,
            avatarUrl: userProfile.avatarUrl,
          },
          title: item.title,
          description: item.description,
          category: item.category,
          tags: item.tags,
          version: item.version,
          platform: item.platform,
          visibility: item.visibility,
          publicationStatus: 'published',
          isPaid: item.isPaid,
          price: item.price,
          currency: item.currency,
          coverImage: coverImage || undefined,
          proofVideo: proofVideo || undefined,
          screenshots: screenshots.length > 0 ? screenshots : undefined,
          youtubeUrl: youtubeUrl.trim() || undefined,
          creatorWebsite: creatorWebsite.trim() || undefined,
          instructions: '',
          releaseNotes: '',
          license: 'Standard License',
          password: item.hasPassword ? item.password : undefined,
          countdownSeconds: item.countdownSeconds,
          expiresAt: item.expiresAt,
          maxDownloads: item.maxDownloads,
          redirectUrl: item.redirectUrl,
          customLogoUrl: item.customLogoUrl,
          folderId: item.folderId,
          onProgress: (pState) => {
            setQueue(prev => prev.map((q, i) => i === index ? {
              ...q,
              progress: pState.progress,
              bytesTransferred: pState.bytesTransferred,
              speedBps: pState.networkSpeedBps,
              status: pState.status,
            } : q));
          }
        },
        controller
      );

      setQueue(prev => prev.map((q, i) => i === index ? {
        ...q,
        status: 'ready',
        progress: 100,
        result,
      } : q));

      setCompletedFile(result);
      onUploadSuccess(result);
      await refreshQuotas();
    } catch (err: any) {
      if (controller.cancelled) {
        setQueue(prev => prev.map((q, i) => i === index ? {
          ...q,
          status: 'cancelled',
          error: 'Upload cancelled by user.',
        } : q));
      } else {
        setQueue(prev => prev.map((q, i) => i === index ? {
          ...q,
          status: 'failed',
          error: err.message || 'Upload failed',
        } : q));
      }
    }
  };

  // Upload whole queue sequentially
  const handleUploadAll = async () => {
    if (!user || !userProfile) {
      setAuthModalOpen(true);
      return;
    }
    syncItemToForm(selectedQueueIndex);
    setIsUploadingAll(true);
    setErrorMessage(null);

    for (let i = 0; i < queue.length; i++) {
      if (queue[i].status !== 'ready') {
        await uploadSingleItem(i);
      }
    }
    setIsUploadingAll(false);
  };

  // Overall queue metrics
  const totalQueueBytes = queue.reduce((acc, q) => acc + q.size, 0);
  const totalUploadedBytes = queue.reduce((acc, q) => acc + q.bytesTransferred, 0);
  const totalProgress = totalQueueBytes > 0 ? Math.round((totalUploadedBytes / totalQueueBytes) * 100) : 0;
  const completedCount = queue.filter(q => q.status === 'ready').length;

  const currentItem = queue[selectedQueueIndex] || null;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in text-white space-y-6">
      {/* Top Header */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 uppercase tracking-wider">
              Advanced Upload Module
            </span>
            <span className="text-xs text-slate-400 font-mono">12 GB Chunk Pipeline</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white mt-1 flex items-center gap-3">
            <UploadCloud className="w-8 h-8 text-cyan-400" />
            <span>Publish, Host &amp; Protect</span>
          </h1>
          <p className="text-xs sm:text-sm text-slate-400 mt-1">
            Batch queue uploads, password gate, countdown timer, destination URLs, and custom project branding.
          </p>
        </div>

        {/* View mode toggle & Action */}
        <div className="flex items-center gap-2.5">
          <div className="flex items-center p-1 bg-slate-900 rounded-xl border border-slate-800 text-xs">
            <button
              onClick={() => setViewMode('single')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition ${
                viewMode === 'single' ? 'bg-cyan-500 text-black font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              Focused View
            </button>
            <button
              onClick={() => setViewMode('bulk')}
              className={`px-3 py-1.5 rounded-lg font-semibold transition flex items-center gap-1.5 ${
                viewMode === 'bulk' ? 'bg-cyan-500 text-black font-bold' : 'text-slate-400 hover:text-white'
              }`}
            >
              <span>Batch Queue</span>
              {queue.length > 0 && (
                <span className="px-1.5 py-0.2 rounded-full text-[10px] bg-slate-800 text-cyan-300 font-mono">
                  {queue.length}
                </span>
              )}
            </button>
          </div>

          <button
            onClick={() => onNavigate('host_web')}
            className="px-3.5 py-2 rounded-xl bg-gradient-to-r from-purple-500 to-pink-600 hover:from-purple-400 hover:to-pink-500 text-white font-bold text-xs flex items-center gap-1.5 shadow-lg shadow-purple-500/25 transition active:scale-95"
            title="Host Web - Paste HTML, get small instant short link"
          >
            <Globe className="w-3.5 h-3.5 text-white" />
            <span>Host Web (HTML)</span>
          </button>

          <button
            onClick={handleSaveDefaults}
            className="px-3 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs text-slate-300 flex items-center gap-1.5 transition"
            title="Save current form values as your account default for future uploads"
          >
            <Save className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">Save Defaults</span>
          </button>
        </div>
      </div>

      {/* Guest Notice */}
      {!user && (
        <div className="p-4 rounded-2xl bg-cyan-950/40 border border-cyan-800/60 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <Sparkles className="w-5 h-5 text-cyan-400 shrink-0" />
            <p className="text-xs text-slate-300">
              Sign in with Google or Boss Account to claim creator handles, upload up to 12 GB, and customize password protection.
            </p>
          </div>
          <button
            onClick={() => setAuthModalOpen(true)}
            className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs shrink-0 transition shadow-lg shadow-cyan-500/20"
          >
            Sign In Now
          </button>
        </div>
      )}

      {/* Error message */}
      {errorMessage && (
        <div className="p-4 rounded-2xl bg-red-500/10 border border-red-500/30 text-red-300 text-xs flex items-center justify-between animate-fade-in">
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
            <span>{errorMessage}</span>
          </div>
          <button onClick={() => setErrorMessage(null)} className="text-slate-400 hover:text-white">&times;</button>
        </div>
      )}

      {/* Overall Queue Progress Bar (Feature 3) */}
      {queue.length > 0 && (
        <div className="p-4 rounded-2xl bg-slate-900/90 border border-slate-800 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <div className="flex items-center gap-2">
              <span className="font-bold text-slate-200">Overall Batch Queue:</span>
              <span className="text-cyan-400 font-mono font-semibold">
                {completedCount} of {queue.length} completed
              </span>
            </div>
            <span className="font-mono text-cyan-300 font-bold">{totalProgress}%</span>
          </div>
          <div className="w-full h-2 rounded-full bg-slate-950 overflow-hidden">
            <div 
              className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 transition-all duration-300"
              style={{ width: `${totalProgress}%` }}
            />
          </div>
          <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
            <span>Uploaded: {formatBytes(totalUploadedBytes)} / {formatBytes(totalQueueBytes)}</span>
            <div className="flex items-center gap-2">
              <button
                onClick={handleUploadAll}
                disabled={isUploadingAll || completedCount === queue.length}
                className="px-3 py-1 rounded-lg bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white font-bold text-[11px] flex items-center gap-1.5 transition"
              >
                {isUploadingAll ? <Loader2 className="w-3 h-3 animate-spin" /> : <Play className="w-3 h-3 fill-current" />}
                <span>Upload All Files</span>
              </button>
              <button
                onClick={() => setQueue([])}
                disabled={isUploadingAll}
                className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-red-950/40 text-slate-400 hover:text-red-300 text-[11px] transition"
              >
                Clear Queue
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Drop Zone Area (Feature 1, 2) */}
      <div
        onDragOver={(e) => e.preventDefault()}
        onDrop={handleDrop}
        onClick={() => fileInputRef.current?.click()}
        className="relative border-2 border-dashed border-slate-700/80 hover:border-cyan-400/80 rounded-3xl p-8 sm:p-10 text-center transition cursor-pointer bg-slate-900/60 hover:bg-slate-900/90 group"
      >
        <input
          ref={fileInputRef}
          type="file"
          multiple
          onChange={handleFileChange}
          className="hidden"
        />
        <input
          ref={folderInputRef}
          type="file"
          // @ts-ignore
          webkitdirectory="true"
          directory="true"
          onChange={handleFileChange}
          className="hidden"
        />

        <div className="flex flex-col items-center">
          <div className="w-14 h-14 rounded-2xl bg-slate-800 group-hover:bg-cyan-500/10 group-hover:border group-hover:border-cyan-500/30 flex items-center justify-center text-slate-400 group-hover:text-cyan-400 mb-3 transition">
            <UploadCloud className="w-7 h-7" />
          </div>
          <h3 className="text-base font-bold text-white mb-1">
            Drag &amp; drop files or <span className="text-cyan-400">choose from computer</span>
          </h3>
          <p className="text-xs text-slate-400 max-w-md mb-3">
            Supports multiple files, folder structures, Android APKs, game builds, and media up to 12 GB.
          </p>
          <div className="flex items-center gap-2 text-xs" onClick={(e) => e.stopPropagation()}>
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold"
            >
              Select Multiple Files
            </button>
            <button
              type="button"
              onClick={() => folderInputRef.current?.click()}
              className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5"
            >
              <Folder className="w-3.5 h-3.5 text-amber-400" />
              <span>Select Entire Folder</span>
            </button>
          </div>
        </div>
      </div>

      {/* Main Workspace Area */}
      {queue.length > 0 && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Left Column: Queue Manager list (4 cols) */}
          <div className="lg:col-span-4 space-y-3">
            <div className="flex items-center justify-between text-xs font-bold uppercase tracking-wider text-slate-400 px-1">
              <span>File Queue ({queue.length})</span>
              <span>Status</span>
            </div>

            <div className="space-y-2 max-h-[620px] overflow-y-auto pr-1">
              {queue.map((item, idx) => {
                const isSelected = selectedQueueIndex === idx;
                return (
                  <div
                    key={item.id}
                    onClick={() => handleSelectQueueItem(idx)}
                    className={`p-3.5 rounded-2xl border transition cursor-pointer flex flex-col gap-2 ${
                      isSelected
                        ? 'bg-cyan-950/40 border-cyan-400/80 shadow-md shadow-cyan-500/10'
                        : 'bg-slate-900/70 border-slate-800 hover:border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2 min-w-0">
                        <span className="px-2 py-0.5 rounded text-[10px] font-mono font-bold bg-slate-950 text-cyan-300 border border-slate-800 uppercase">
                          {item.ext}
                        </span>
                        <h4 className="text-xs font-bold text-white truncate max-w-[140px] sm:max-w-[180px]">
                          {item.title}
                        </h4>
                      </div>
                      
                      <div className="flex items-center gap-1">
                        <span className={`px-2 py-0.2 rounded text-[9px] font-bold uppercase ${
                          item.status === 'ready' ? 'bg-emerald-500/20 text-emerald-300' :
                          item.status === 'uploading' ? 'bg-cyan-500/20 text-cyan-300' :
                          item.status === 'failed' ? 'bg-red-500/20 text-red-300' : 'bg-slate-800 text-slate-400'
                        }`}>
                          {item.status}
                        </span>
                        <button
                          type="button"
                          onClick={(e) => {
                            e.stopPropagation();
                            handleRemoveFromQueue(idx);
                          }}
                          className="p-1 hover:text-red-400 text-slate-500 transition"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>

                    <div className="flex items-center justify-between text-[10px] text-slate-400 font-mono">
                      <span>{formatBytes(item.size)}</span>
                      {item.status === 'uploading' && (
                        <span>{item.progress}% &bull; {item.speedBps ? `${formatBytes(item.speedBps)}/s` : ''}</span>
                      )}
                    </div>

                    {/* Progress bar inside queue item */}
                    {item.status === 'uploading' && (
                      <div className="w-full h-1 bg-slate-950 rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-cyan-400 transition-all duration-200" 
                          style={{ width: `${item.progress}%` }} 
                        />
                      </div>
                    )}

                    {item.error && (
                      <p className="text-[10px] text-red-400 truncate">{item.error}</p>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right Column: Active File Configuration Form (8 cols) */}
          {currentItem && (
            <div className="lg:col-span-8 glass-panel-glow rounded-3xl p-6 sm:p-8 space-y-6 border border-slate-800">
              <div className="flex items-center justify-between pb-4 border-b border-slate-800">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <FileText className="w-4 h-4 text-cyan-400" />
                    <span>Configuring: {currentItem.name}</span>
                  </h3>
                  <p className="text-xs text-slate-400 font-mono">
                    Size: {formatBytes(currentItem.size)} &bull; MIME: {currentItem.type}
                  </p>
                </div>

                <div className="flex items-center gap-2">
                  {currentItem.status === 'ready' && currentItem.result ? (
                    <button
                      type="button"
                      onClick={() => onNavigate('fileDetail', currentItem.result!.id)}
                      className="px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center gap-1.5 transition"
                    >
                      <ExternalLink className="w-3.5 h-3.5" />
                      <span>View File Page</span>
                    </button>
                  ) : (
                    <button
                      type="button"
                      onClick={() => {
                        syncItemToForm(selectedQueueIndex);
                        uploadSingleItem(selectedQueueIndex);
                      }}
                      disabled={currentItem.status === 'uploading'}
                      className="px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 font-bold text-xs text-white flex items-center gap-1.5 transition glow-btn disabled:opacity-50"
                    >
                      {currentItem.status === 'uploading' ? (
                        <>
                          <Loader2 className="w-3.5 h-3.5 animate-spin" />
                          <span>Uploading ({currentItem.progress}%)...</span>
                        </>
                      ) : (
                        <>
                          <UploadCloud className="w-3.5 h-3.5" />
                          <span>Upload This File</span>
                        </>
                      )}
                    </button>
                  )}
                </div>
              </div>

              {/* Title & Description */}
              <div className="space-y-4 text-xs">
                <div>
                  <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                    Display Title *
                  </label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => setTitle(e.target.value)}
                    placeholder="Custom publication title"
                    className="w-full px-3.5 py-2.5 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-cyan-400 focus:outline-none"
                  />
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                      Category
                    </label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-cyan-400 focus:outline-none"
                    >
                      {CATEGORIES.map(c => (
                        <option key={c.id} value={c.id}>{c.name}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                      Folder / Subfolder
                    </label>
                    <select
                      value={folderId}
                      onChange={(e) => setFolderId(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-cyan-400 focus:outline-none"
                    >
                      <option value="">Root (No folder)</option>
                      {userFolders.map(fol => (
                        <option key={fol.id} value={fol.id}>{fol.name}</option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                      Visibility Policy
                    </label>
                    <select
                      value={visibility}
                      onChange={(e) => setVisibility(e.target.value as VisibilityMode)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-cyan-400 focus:outline-none"
                    >
                      <option value="public">Public (Indexed &amp; Explore)</option>
                      <option value="unlisted">Unlisted (Link Only)</option>
                      <option value="private">Private (Owner Only)</option>
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                    Tags (Comma-separated)
                  </label>
                  <input
                    type="text"
                    value={tagsStr}
                    onChange={(e) => setTagsStr(e.target.value)}
                    placeholder="apk, android, utility, project, build"
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-cyan-400 focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                    Description
                  </label>
                  <textarea
                    rows={2}
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    placeholder="Describe this release, installation instructions, or release notes..."
                    className="w-full px-3.5 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white focus:border-cyan-400 focus:outline-none resize-none"
                  />
                </div>
              </div>

              {/* SECTION B: DOWNLOAD COUNTDOWN SETTINGS */}
              <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="w-4 h-4 text-cyan-400" />
                    <div>
                      <h4 className="font-bold text-white">Download Countdown (Section B)</h4>
                      <p className="text-[11px] text-slate-400">Controls visitor wait time before download activates</p>
                    </div>
                  </div>

                  <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800">
                    {(['disabled', '10', '15', '20', 'custom'] as const).map(mode => (
                      <button
                        key={mode}
                        type="button"
                        onClick={() => setCountdownMode(mode)}
                        className={`px-2.5 py-1 rounded-lg capitalize transition font-medium ${
                          countdownMode === mode
                            ? 'bg-cyan-500 text-black font-bold'
                            : 'text-slate-400 hover:text-white'
                        }`}
                      >
                        {mode === 'disabled' ? 'Off' : mode === 'custom' ? 'Custom' : `${mode}s`}
                      </button>
                    ))}
                  </div>
                </div>

                {countdownMode === 'custom' && (
                  <div className="flex items-center gap-3 pt-2">
                    <label className="text-slate-400 font-medium">Custom Duration (seconds):</label>
                    <input
                      type="number"
                      min={1}
                      max={120}
                      value={customCountdown}
                      onChange={(e) => setCustomCountdown(parseInt(e.target.value, 10) || 15)}
                      className="w-24 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 font-mono font-bold text-white text-center"
                    />
                    <span className="text-[11px] text-slate-500 font-mono">(1 to 120 seconds safe range)</span>
                  </div>
                )}
              </div>

              {/* SECTION C: PASSWORD PROTECTION PANEL */}
              <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3 text-xs">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Lock className="w-4 h-4 text-purple-400" />
                    <div>
                      <h4 className="font-bold text-white">Password Protection (Section C)</h4>
                      <p className="text-[11px] text-slate-400">PBKDF2 salted hash with brute-force lockout</p>
                    </div>
                  </div>

                  <label className="relative inline-flex items-center cursor-pointer">
                    <input
                      type="checkbox"
                      checked={enablePassword}
                      onChange={(e) => setEnablePassword(e.target.checked)}
                      className="sr-only peer"
                    />
                    <div className="w-11 h-6 bg-slate-800 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-purple-600"></div>
                  </label>
                </div>

                {enablePassword && (
                  <div className="space-y-2 pt-2 border-t border-slate-800">
                    <label className="block text-slate-400 font-semibold uppercase text-[10px]">
                      Access Passphrase *
                    </label>
                    <div className="relative">
                      <input
                        type={showPassword ? 'text' : 'password'}
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        placeholder="Enter secure password (min 4 characters)"
                        className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white focus:border-purple-400 focus:outline-none font-mono"
                      />
                      <button
                        type="button"
                        onClick={() => setShowPassword(!showPassword)}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-white"
                      >
                        {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                      </button>
                    </div>
                    <p className="text-[11px] text-purple-300/80">
                      Protected on the server with 10,000 PBKDF2 rounds. Passwords are never stored in plaintext or URL strings.
                    </p>
                  </div>
                )}
              </div>

              {/* SECTION D: DESTINATION REDIRECT, EXPIRATION & LIMITS */}
              <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3 text-xs">
                <h4 className="font-bold text-white flex items-center gap-2">
                  <LinkIcon className="w-4 h-4 text-emerald-400" />
                  <span>Sharing, Redirect &amp; Expiry Controls (Section D)</span>
                </h4>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                      Link Expiry Date
                    </label>
                    <input
                      type="datetime-local"
                      value={expiresAt}
                      onChange={(e) => setExpiresAt(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:border-emerald-400"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                      Max Downloads Limit
                    </label>
                    <input
                      type="number"
                      min={1}
                      value={maxDownloads}
                      onChange={(e) => setMaxDownloads(e.target.value)}
                      placeholder="e.g. 50 (optional)"
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:border-emerald-400 font-mono"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                      Custom Project Logo URL
                    </label>
                    <input
                      type="url"
                      value={customLogoUrl}
                      onChange={(e) => setCustomLogoUrl(e.target.value)}
                      placeholder="https://...png (optional)"
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:border-emerald-400"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                    Protected Destination / Redirect URL (Optional)
                  </label>
                  <input
                    type="url"
                    value={redirectUrl}
                    onChange={(e) => setRedirectUrl(e.target.value)}
                    placeholder="https://your-domain.com/landing or target repository"
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white focus:outline-none focus:border-emerald-400"
                  />
                  <p className="text-[11px] text-slate-500 mt-1">
                    Visitor will be redirected to this destination URL only after completing password and countdown verification.
                  </p>
                </div>
              </div>

              {/* Bottom Sync Form Trigger */}
              <div className="pt-2 flex items-center justify-between">
                <button
                  type="button"
                  onClick={() => syncItemToForm(selectedQueueIndex)}
                  className="px-4 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold"
                >
                  Save Changes to Queue
                </button>

                <button
                  type="button"
                  onClick={() => uploadSingleItem(selectedQueueIndex)}
                  disabled={currentItem.status === 'uploading' || currentItem.status === 'ready'}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white font-bold text-xs flex items-center gap-2 transition shadow-lg shadow-cyan-500/20 disabled:opacity-50"
                >
                  <UploadCloud className="w-4 h-4" />
                  <span>Publish Item Now</span>
                </button>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
