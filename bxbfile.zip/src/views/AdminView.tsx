import React, { useState, useEffect } from 'react';
import { 
  Shield, 
  AlertTriangle, 
  CheckCircle, 
  XCircle, 
  Loader2, 
  Server, 
  ExternalLink, 
  HardDrive, 
  Database, 
  Crown, 
  Bell, 
  Gift, 
  DollarSign, 
  Megaphone, 
  UserCheck, 
  Check, 
  Plus, 
  Clock, 
  Sparkles, 
  Key, 
  Users, 
  Search, 
  Filter, 
  MessageSquare, 
  Send, 
  Globe, 
  RefreshCw, 
  Eye, 
  UserX, 
  CheckCircle2, 
  Inbox,
  Palette,
  Layout,
  Download,
  UploadCloud,
  Layers,
  History,
  FileCode,
  Sliders,
  RotateCcw,
  Activity,
  AlertCircle,
  Copy,
  Lock,
  Compass,
  FileText
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useSiteConfig } from '../context/SiteConfigContext';
import { 
  getReports, 
  updateReportStatus, 
  setFileModerationStatus 
} from '../services/moderationService';
import { 
  fetchOwnerSiteSettings, 
  saveSiteSettings, 
  rollbackSiteSettings, 
  uploadBrandingAsset, 
  restoreDefaultBranding, 
  fetchDiagnostics, 
  updateUserAccountStatus,
  ownerModerationDelete 
} from '../services/siteConfigService';
import { 
  Report, 
  InvitationCode, 
  SystemAnnouncement, 
  VisitNewUser, 
  OwnerDirectMessage, 
  SiteConfig, 
  RevisionRecord, 
  AuditLogRecord, 
  DiagnosticsData 
} from '../types';
import { formatRelativeTime, formatBytes } from '../utils/format';
import { AdSenseUnit } from '../components/adsense/AdSenseUnit';

interface AdminViewProps {
  onNavigate: (view: string, param?: string) => void;
}

export const AdminView: React.FC<AdminViewProps> = ({ onNavigate }) => {
  const { user, isAdmin, isOwner, ownerConfig } = useAuth();
  const { refreshConfig: refreshGlobalConfig } = useSiteConfig();

  // Active Tab in Owner Suite
  const [activeTab, setActiveTab] = useState<
    'branding' | 'live_editor' | 'countdown_protection' | 'adsense' | 'visit_new' | 'owners' | 'source_export' | 'diagnostics' | 'reports' | 'announcements' | 'gifts'
  >('branding');

  // Full Site Settings & Revision Management (Sections E, F, G)
  const [siteSettings, setSiteSettings] = useState<SiteConfig | null>(null);
  const [revisions, setRevisions] = useState<RevisionRecord[]>([]);
  const [auditLogs, setAuditLogs] = useState<AuditLogRecord[]>([]);
  const [loadingSettings, setLoadingSettings] = useState(false);
  const [savingSettings, setSavingSettings] = useState(false);
  const [publishSummary, setPublishSummary] = useState('');
  const [showPublishModal, setShowPublishModal] = useState(false);

  // Live Editor State
  const [editorSiteName, setEditorSiteName] = useState('');
  const [editorTagline, setEditorTagline] = useState('');
  const [editorHeroHeading, setEditorHeroHeading] = useState('');
  const [editorHeroSubtitle, setEditorHeroSubtitle] = useState('');
  const [editorFooterText, setEditorFooterText] = useState('');
  const [editorPrimaryAccent, setEditorPrimaryAccent] = useState('#06b6d4');
  const [editorSecondaryAccent, setEditorSecondaryAccent] = useState('#3b82f6');
  const [editorMaintenanceEnabled, setEditorMaintenanceEnabled] = useState(false);
  const [editorMaintenanceMsg, setEditorMaintenanceMsg] = useState('');
  const [editorAnnouncementActive, setEditorAnnouncementActive] = useState(false);
  const [editorAnnouncementTitle, setEditorAnnouncementTitle] = useState('');
  const [editorAnnouncementText, setEditorAnnouncementText] = useState('');
  const [editorAnnouncementType, setEditorAnnouncementType] = useState<'info' | 'warning' | 'urgent'>('info');
  const [editorSeoTitle, setEditorSeoTitle] = useState('');
  const [editorSeoDescription, setEditorSeoDescription] = useState('');

  // Branding Files & Previews (Section E)
  const [logoPreviewTab, setLogoPreviewTab] = useState<'header' | 'sidebar' | 'login' | 'footer'>('header');
  const [uploadingAsset, setUploadingAsset] = useState<string | null>(null);

  // Countdown & Protection Defaults (Section B & C)
  const [countdownEnabled, setCountdownEnabled] = useState(true);
  const [countdownSeconds, setCountdownSeconds] = useState(15);
  const [countdownPolicy, setCountdownPolicy] = useState<'all' | 'selected'>('all');
  const [allowCountdownOverride, setAllowCountdownOverride] = useState(true);
  const [testCountdownActive, setTestCountdownActive] = useState(false);
  const [testCountdownVal, setTestCountdownVal] = useState(15);

  // Google AdSense Configuration (Section G)
  const [adPublisherId, setAdPublisherId] = useState('');
  const [adEnabled, setAdEnabled] = useState(false);
  const [adStatus, setAdStatus] = useState<string>('not_configured');
  const [adPlacements, setAdPlacements] = useState({
    headerLeaderboard: false,
    downloadPageBanner: false,
    sidebarRectangle: false,
    reelsInFeed: false,
  });
  const [adConsentRequired, setAdConsentRequired] = useState(true);
  const [copiedAdsTxt, setCopiedAdsTxt] = useState(false);

  // Visit New User Stream (Section 8 & H)
  const [visitUsers, setVisitUsers] = useState<VisitNewUser[]>([]);
  const [loadingVisitUsers, setLoadingVisitUsers] = useState(false);
  const [userFilter, setUserFilter] = useState<'all' | 'first_time' | 'returning' | 'suspended'>('all');
  const [userSearch, setUserSearch] = useState('');
  const [selectedUserForMessage, setSelectedUserForMessage] = useState<VisitNewUser | null>(null);

  // Two Owners Configuration (Section 7)
  const [owner1Email, setOwner1Email] = useState(ownerConfig?.ownerEmail1 || 'md.barik4555@gmail.com');
  const [owner2Email, setOwner2Email] = useState(ownerConfig?.ownerEmail2 || '');
  const [savingOwners, setSavingOwners] = useState(false);

  // Diagnostics Data (Section I)
  const [diagnostics, setDiagnostics] = useState<DiagnosticsData | null>(null);
  const [loadingDiag, setLoadingDiag] = useState(false);

  // Reports
  const [reports, setReports] = useState<Report[]>([]);
  const [loadingReports, setLoadingReports] = useState(false);
  const [actioningId, setActioningId] = useState<string | null>(null);

  // Feedback notifications
  const [actionSuccessMsg, setActionSuccessMsg] = useState<string | null>(null);
  const [actionErrorMsg, setActionErrorMsg] = useState<string | null>(null);

  // Load Owner Settings & Data
  const loadSettings = async () => {
    if (!user?.email) return;
    setLoadingSettings(true);
    try {
      const data = await fetchOwnerSiteSettings(user.email);
      setSiteSettings(data);
      setRevisions(data.revisions || []);
      setAuditLogs(data.auditLogs || []);

      // Initialize form controls
      setEditorSiteName(data.brand?.siteName || 'bxbfile.bxb');
      setEditorTagline(data.brand?.tagline || 'File, APK, Cloud Sync & JARVIS AI Platform');
      setEditorPrimaryAccent(data.brand?.primaryAccent || '#06b6d4');
      setEditorSecondaryAccent(data.brand?.secondaryAccent || '#3b82f6');
      setEditorHeroHeading(data.liveEditor?.heroHeading || 'The Ultimate Cloud Platform for Files, APKs & Builds');
      setEditorHeroSubtitle(data.liveEditor?.heroSubtitle || 'Distribute Android APKs, developer packages, tools, and media attachments up to 12 GB.');
      setEditorFooterText(data.liveEditor?.footerText || '© 2026 BXB Cloud. All rights reserved.');
      setEditorMaintenanceEnabled(Boolean(data.liveEditor?.maintenanceMode?.enabled));
      setEditorMaintenanceMsg(data.liveEditor?.maintenanceMode?.message || 'BXB Cloud is currently undergoing scheduled maintenance.');
      setEditorAnnouncementActive(Boolean(data.liveEditor?.announcementBanner?.active));
      setEditorAnnouncementTitle(data.liveEditor?.announcementBanner?.title || '');
      setEditorAnnouncementText(data.liveEditor?.announcementBanner?.text || '');
      setEditorAnnouncementType(data.liveEditor?.announcementBanner?.type || 'info');
      setEditorSeoTitle(data.liveEditor?.seoTitle || 'bxbfile.bxb — JARVIS AI Platform');
      setEditorSeoDescription(data.liveEditor?.seoDescription || 'Premier 12 GB file uploader, real-time multi-device cloud sync, Android APK distribution, and protected downloads.');

      // Countdown
      setCountdownEnabled(Boolean(data.countdownDefaults?.enabled));
      setCountdownSeconds(data.countdownDefaults?.defaultSeconds || 15);
      setCountdownPolicy(data.countdownDefaults?.policy || 'all');
      setAllowCountdownOverride(Boolean(data.countdownDefaults?.allowOverride));

      // AdSense
      setAdPublisherId(data.adsense?.publisherId || '');
      setAdEnabled(Boolean(data.adsense?.enabled));
      setAdStatus(data.adsense?.status || 'not_configured');
      setAdPlacements(data.adsense?.placements || {
        headerLeaderboard: false,
        downloadPageBanner: false,
        sidebarRectangle: false,
        reelsInFeed: false,
      });
      setAdConsentRequired(Boolean(data.adsense?.consentRequired));
    } catch (err: any) {
      console.warn('Could not load owner site settings:', err);
    } finally {
      setLoadingSettings(false);
    }
  };

  const loadVisitUsers = () => {
    if (!user?.email) return;
    setLoadingVisitUsers(true);
    fetch(`/api/owner/users?callerEmail=${encodeURIComponent(user.email)}&filter=${userFilter}&search=${encodeURIComponent(userSearch)}`)
      .then(r => r.ok ? r.json() : { users: [] })
      .then(data => setVisitUsers(data.users || []))
      .catch(() => {})
      .finally(() => setLoadingVisitUsers(false));
  };

  const loadDiagnosticsData = () => {
    if (!user?.email) return;
    setLoadingDiag(true);
    fetchDiagnostics(user.email)
      .then(data => setDiagnostics(data))
      .catch(() => {})
      .finally(() => setLoadingDiag(false));
  };

  useEffect(() => {
    if (isAdmin || isOwner) {
      loadSettings();
      loadVisitUsers();
      loadDiagnosticsData();
      setLoadingReports(true);
      getReports().then(data => setReports(data)).finally(() => setLoadingReports(false));
    }
  }, [isAdmin, isOwner]);

  // Test Countdown Ticker in Admin Preview
  useEffect(() => {
    if (!testCountdownActive || testCountdownVal <= 0) return;
    const timer = setInterval(() => {
      setTestCountdownVal(prev => {
        if (prev <= 1) {
          clearInterval(timer);
          setTestCountdownActive(false);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
    return () => clearInterval(timer);
  }, [testCountdownActive, testCountdownVal]);

  const handleStartCountdownTest = () => {
    setTestCountdownVal(countdownSeconds || 15);
    setTestCountdownActive(true);
  };

  // Save Settings (Draft or Publish)
  const handleSaveSettings = async (publish: boolean) => {
    if (!user?.email) return;
    setSavingSettings(true);
    setActionSuccessMsg(null);
    setActionErrorMsg(null);

    // Validate AdSense publisher ID if enabled
    if (adEnabled && adPublisherId) {
      if (!/^ca-pub-\d{16}$/.test(adPublisherId.trim())) {
        setActionErrorMsg('Invalid Publisher ID format. Must match standard format: ca-pub-XXXXXXXXXXXXXXXX (16 digits).');
        setSavingSettings(false);
        return;
      }
    }

    const payload: Partial<SiteConfig> = {
      brand: {
        siteName: editorSiteName.trim(),
        tagline: editorTagline.trim(),
        logoUrl: siteSettings?.brand?.logoUrl || '',
        darkLogoUrl: siteSettings?.brand?.darkLogoUrl || '',
        faviconUrl: siteSettings?.brand?.faviconUrl || '',
        appIconUrl: siteSettings?.brand?.appIconUrl || '',
        primaryAccent: editorPrimaryAccent,
        secondaryAccent: editorSecondaryAccent,
      },
      liveEditor: {
        heroHeading: editorHeroHeading.trim(),
        heroSubtitle: editorHeroSubtitle.trim(),
        navLinks: siteSettings?.liveEditor?.navLinks || [],
        footerText: editorFooterText.trim(),
        announcementBanner: {
          active: editorAnnouncementActive,
          title: editorAnnouncementTitle.trim(),
          text: editorAnnouncementText.trim(),
          type: editorAnnouncementType,
        },
        maintenanceMode: {
          enabled: editorMaintenanceEnabled,
          message: editorMaintenanceMsg.trim(),
        },
        seoTitle: editorSeoTitle.trim(),
        seoDescription: editorSeoDescription.trim(),
      },
      countdownDefaults: {
        enabled: countdownEnabled,
        defaultSeconds: countdownSeconds,
        policy: countdownPolicy,
        allowOverride: allowCountdownOverride,
      },
      adsense: {
        publisherId: adPublisherId.trim(),
        enabled: adEnabled,
        status: adEnabled ? (adPublisherId.trim() ? 'review' : 'not_configured') : 'disabled',
        placements: adPlacements,
        adsTxt: `google.com, ${adPublisherId.replace(/^ca-/, '').trim()}, DIRECT, f08c47fec0942fa0`,
        consentRequired: adConsentRequired,
      },
    };

    try {
      const res = await saveSiteSettings(
        user.email,
        payload,
        publish,
        publishSummary.trim() || (publish ? 'Published website configuration changes' : 'Saved draft settings')
      );
      setSiteSettings(res.config);
      await refreshGlobalConfig();
      await loadSettings();
      setShowPublishModal(false);
      setPublishSummary('');
      setActionSuccessMsg(publish ? 'Live Website Configuration Published Successfully!' : 'Draft Configuration Saved!');
      setTimeout(() => setActionSuccessMsg(null), 4000);
    } catch (err: any) {
      setActionErrorMsg(err.message || 'Failed to save configuration');
      setTimeout(() => setActionErrorMsg(null), 5000);
    } finally {
      setSavingSettings(false);
    }
  };

  // Rollback to Revision
  const handleRollback = async (revId: string) => {
    if (!user?.email) return;
    if (!confirm('Are you sure you want to rollback to this saved revision? This will overwrite active configuration.')) return;

    try {
      const res = await rollbackSiteSettings(user.email, revId);
      setSiteSettings(res.config);
      await refreshGlobalConfig();
      await loadSettings();
      setActionSuccessMsg(res.message);
      setTimeout(() => setActionSuccessMsg(null), 4000);
    } catch (err: any) {
      setActionErrorMsg(err.message || 'Rollback failed');
    }
  };

  // Branding Image Upload Handler
  const handleBrandingUpload = async (e: React.ChangeEvent<HTMLInputElement>, assetType: 'logo' | 'darkLogo' | 'favicon' | 'appIcon') => {
    if (!user?.email || !e.target.files || !e.target.files[0]) return;
    const file = e.target.files[0];

    // Validate size (max 3 MB)
    if (file.size > 3 * 1024 * 1024) {
      setActionErrorMsg('Branding asset must be under 3 MB.');
      return;
    }

    setUploadingAsset(assetType);
    try {
      const res = await uploadBrandingAsset(user.email, file, assetType);
      await refreshGlobalConfig();
      await loadSettings();
      setActionSuccessMsg(res.message);
      setTimeout(() => setActionSuccessMsg(null), 4000);
    } catch (err: any) {
      setActionErrorMsg(err.message || 'Failed to upload asset');
    } finally {
      setUploadingAsset(null);
    }
  };

  // Restore Default Branding
  const handleRestoreDefaultBranding = async () => {
    if (!user?.email) return;
    if (!confirm('Restore default BXB Cloud branding logos, icons, and colors?')) return;
    try {
      await restoreDefaultBranding(user.email);
      await refreshGlobalConfig();
      await loadSettings();
      setActionSuccessMsg('Default BXB Cloud branding restored successfully!');
      setTimeout(() => setActionSuccessMsg(null), 4000);
    } catch (err: any) {
      setActionErrorMsg(err.message || 'Failed to restore default branding');
    }
  };

  // Suspend or Restore Account
  const handleToggleAccountStatus = async (uid: string, currentStatus: string) => {
    if (!user?.email) return;
    const nextStatus = currentStatus === 'suspended' ? 'active' : 'suspended';
    try {
      await updateUserAccountStatus(user.email, uid, nextStatus);
      setVisitUsers(prev => prev.map(u => u.uid === uid ? { ...u, accountStatus: nextStatus as any } : u));
      setActionSuccessMsg(`Account status changed to ${nextStatus}.`);
      setTimeout(() => setActionSuccessMsg(null), 3000);
    } catch {
      setActionErrorMsg('Failed to update account status.');
    }
  };

  if (!isAdmin && !isOwner) {
    return (
      <div className="max-w-md mx-auto px-4 py-24 text-center text-white">
        <Shield className="w-16 h-16 text-red-400 mx-auto mb-4" />
        <h2 className="text-xl font-bold mb-2">Restricted Section</h2>
        <p className="text-xs text-slate-400 mb-6">
          Authorized owner privileges (OWNER_EMAIL_1 or OWNER_EMAIL_2) are required to access BXB Operations.
        </p>
        <button
          onClick={() => onNavigate('home')}
          className="px-5 py-2.5 rounded-xl bg-slate-800 text-xs font-semibold"
        >
          Return Home
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 animate-fade-in text-white space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-800">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded text-[10px] font-bold bg-amber-500/20 text-amber-300 border border-amber-500/40 uppercase tracking-wider">
              {isOwner ? 'Authorized Owner Dashboard' : 'Staff Moderation'}
            </span>
            <span className="text-xs text-slate-400 font-mono">BXB Cloud 3.5 Engine</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white mt-1">Platform Operations &amp; Live Admin</h1>
        </div>

        {/* Global Save Draft & Publish Controls (Section F) */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => handleSaveSettings(false)}
            disabled={savingSettings}
            className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-xs font-semibold text-slate-200 transition"
          >
            Save Draft
          </button>
          <button
            onClick={() => setShowPublishModal(true)}
            disabled={savingSettings}
            className="px-5 py-2 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 font-bold text-xs text-white shadow-lg shadow-cyan-500/25 transition glow-btn"
          >
            Publish Live
          </button>
        </div>
      </div>

      {/* Action Notification Banners */}
      {actionSuccessMsg && (
        <div className="p-3.5 rounded-2xl bg-emerald-500/20 border border-emerald-500/40 text-emerald-300 text-xs font-semibold flex items-center justify-between animate-fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-emerald-400" />
            <span>{actionSuccessMsg}</span>
          </div>
          <button onClick={() => setActionSuccessMsg(null)} className="text-slate-400 hover:text-white">&times;</button>
        </div>
      )}

      {actionErrorMsg && (
        <div className="p-3.5 rounded-2xl bg-red-500/20 border border-red-500/40 text-red-300 text-xs font-semibold flex items-center justify-between animate-fade-in">
          <div className="flex items-center gap-2">
            <AlertTriangle className="w-4 h-4 text-red-400" />
            <span>{actionErrorMsg}</span>
          </div>
          <button onClick={() => setActionErrorMsg(null)} className="text-slate-400 hover:text-white">&times;</button>
        </div>
      )}

      {/* Tabs Navigation */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 border-b border-slate-800/80 scrollbar-none">
        {[
          { id: 'branding' as const, label: 'Branding & Logo', icon: Palette },
          { id: 'live_editor' as const, label: 'Live Website Editor', icon: Layout },
          { id: 'countdown_protection' as const, label: 'Countdown & Protection', icon: Clock },
          { id: 'adsense' as const, label: 'Monetization & AdSense', icon: DollarSign },
          { id: 'visit_new' as const, label: 'Visit New Creators', icon: Sparkles },
          { id: 'owners' as const, label: 'Two Authorized Owners', icon: Crown },
          { id: 'source_export' as const, label: 'Source ZIP Export', icon: FileCode },
          { id: 'diagnostics' as const, label: 'Live Diagnostics', icon: Activity },
          { id: 'reports' as const, label: 'Moderation Reports', icon: AlertTriangle },
        ].map(tab => {
          const Icon = tab.icon;
          const isSelected = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition whitespace-nowrap ${
                isSelected
                  ? 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/20'
                  : 'text-slate-400 hover:text-white hover:bg-slate-800/50'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* ============================================================== */}
      {/* SECTION E: BRANDING & LOGO UPLOAD                              */}
      {/* ============================================================== */}
      {activeTab === 'branding' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Uploads & Inputs (6 cols) */}
          <div className="lg:col-span-6 space-y-6">
            <div className="p-6 rounded-3xl glass-panel-glow border border-slate-800 space-y-5 text-xs">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-white">Brand Assets &amp; Logos</h3>
                  <p className="text-slate-400 text-[11px]">Upload PNG, SVG, WEBP, or ICO assets (max 3 MB)</p>
                </div>
                <button
                  onClick={handleRestoreDefaultBranding}
                  className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 text-[11px] font-semibold flex items-center gap-1.5 transition"
                >
                  <RotateCcw className="w-3 h-3 text-amber-400" />
                  <span>Restore Default BXB</span>
                </button>
              </div>

              {/* Logo Uploads */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Website Logo (Light / Standard) */}
                <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2 text-center">
                  <span className="font-bold text-slate-200 block">Website Logo (Main)</span>
                  <div className="w-20 h-20 mx-auto rounded-xl bg-slate-950 border border-slate-700 flex items-center justify-center overflow-hidden p-2">
                    {siteSettings?.brand?.logoUrl ? (
                      <img src={siteSettings.brand.logoUrl} alt="Logo" className="max-w-full max-h-full object-contain" />
                    ) : (
                      <Palette className="w-6 h-6 text-slate-600" />
                    )}
                  </div>
                  <label className="block">
                    <span className="px-3 py-1.5 rounded-xl bg-cyan-600 hover:bg-cyan-500 font-semibold text-white cursor-pointer inline-block transition text-[11px]">
                      {uploadingAsset === 'logo' ? 'Uploading...' : 'Choose Logo'}
                    </span>
                    <input
                      type="file"
                      accept="image/png,image/svg+xml,image/webp,image/jpeg"
                      onChange={(e) => handleBrandingUpload(e, 'logo')}
                      className="hidden"
                    />
                  </label>
                </div>

                {/* Dark Variant Logo */}
                <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2 text-center">
                  <span className="font-bold text-slate-200 block">Dark Theme Logo</span>
                  <div className="w-20 h-20 mx-auto rounded-xl bg-slate-950 border border-slate-700 flex items-center justify-center overflow-hidden p-2">
                    {siteSettings?.brand?.darkLogoUrl ? (
                      <img src={siteSettings.brand.darkLogoUrl} alt="Dark Logo" className="max-w-full max-h-full object-contain" />
                    ) : (
                      <Palette className="w-6 h-6 text-slate-600" />
                    )}
                  </div>
                  <label className="block">
                    <span className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 font-semibold text-slate-200 cursor-pointer inline-block transition text-[11px]">
                      {uploadingAsset === 'darkLogo' ? 'Uploading...' : 'Choose Dark Logo'}
                    </span>
                    <input
                      type="file"
                      accept="image/png,image/svg+xml,image/webp,image/jpeg"
                      onChange={(e) => handleBrandingUpload(e, 'darkLogo')}
                      className="hidden"
                    />
                  </label>
                </div>

                {/* Favicon (.ico / .png) */}
                <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2 text-center">
                  <span className="font-bold text-slate-200 block">Favicon (.ico, .png)</span>
                  <div className="w-12 h-12 mx-auto rounded-xl bg-slate-950 border border-slate-700 flex items-center justify-center overflow-hidden p-2">
                    {siteSettings?.brand?.faviconUrl ? (
                      <img src={siteSettings.brand.faviconUrl} alt="Favicon" className="w-6 h-6 object-contain" />
                    ) : (
                      <Globe className="w-5 h-5 text-slate-600" />
                    )}
                  </div>
                  <label className="block">
                    <span className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 font-semibold text-slate-200 cursor-pointer inline-block transition text-[11px]">
                      {uploadingAsset === 'favicon' ? 'Uploading...' : 'Choose Favicon'}
                    </span>
                    <input
                      type="file"
                      accept="image/x-icon,image/png,image/svg+xml"
                      onChange={(e) => handleBrandingUpload(e, 'favicon')}
                      className="hidden"
                    />
                  </label>
                </div>

                {/* App Icon */}
                <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-2 text-center">
                  <span className="font-bold text-slate-200 block">Mobile App Icon</span>
                  <div className="w-12 h-12 mx-auto rounded-2xl bg-slate-950 border border-slate-700 flex items-center justify-center overflow-hidden p-2">
                    {siteSettings?.brand?.appIconUrl ? (
                      <img src={siteSettings.brand.appIconUrl} alt="App Icon" className="w-full h-full object-cover" />
                    ) : (
                      <Sparkles className="w-5 h-5 text-slate-600" />
                    )}
                  </div>
                  <label className="block">
                    <span className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 font-semibold text-slate-200 cursor-pointer inline-block transition text-[11px]">
                      {uploadingAsset === 'appIcon' ? 'Uploading...' : 'Choose App Icon'}
                    </span>
                    <input
                      type="file"
                      accept="image/png,image/webp,image/svg+xml"
                      onChange={(e) => handleBrandingUpload(e, 'appIcon')}
                      className="hidden"
                    />
                  </label>
                </div>
              </div>

              {/* Brand Typography & Colors */}
              <div className="space-y-4 pt-4 border-t border-slate-800">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                      Site Brand Name
                    </label>
                    <input
                      type="text"
                      value={editorSiteName}
                      onChange={(e) => setEditorSiteName(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white font-bold"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                      Brand Tagline
                    </label>
                    <input
                      type="text"
                      value={editorTagline}
                      onChange={(e) => setEditorTagline(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                      Primary Accent Color
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={editorPrimaryAccent}
                        onChange={(e) => setEditorPrimaryAccent(e.target.value)}
                        className="w-8 h-8 rounded-lg cursor-pointer bg-transparent border-0"
                      />
                      <input
                        type="text"
                        value={editorPrimaryAccent}
                        onChange={(e) => setEditorPrimaryAccent(e.target.value)}
                        className="flex-1 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 font-mono text-white"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                      Secondary Accent Color
                    </label>
                    <div className="flex items-center gap-2">
                      <input
                        type="color"
                        value={editorSecondaryAccent}
                        onChange={(e) => setEditorSecondaryAccent(e.target.value)}
                        className="w-8 h-8 rounded-lg cursor-pointer bg-transparent border-0"
                      />
                      <input
                        type="text"
                        value={editorSecondaryAccent}
                        onChange={(e) => setEditorSecondaryAccent(e.target.value)}
                        className="flex-1 px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 font-mono text-white"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Live Previews: Header, Sidebar, Login Page, Footer (6 cols) */}
          <div className="lg:col-span-6 space-y-4">
            <div className="p-6 rounded-3xl glass-panel border border-slate-800 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-bold text-white text-sm flex items-center gap-2">
                  <Eye className="w-4 h-4 text-cyan-400" />
                  <span>Branding Multi-View Live Preview (Requirement E.3)</span>
                </h3>

                <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl text-xs">
                  {(['header', 'sidebar', 'login', 'footer'] as const).map(tab => (
                    <button
                      key={tab}
                      onClick={() => setLogoPreviewTab(tab)}
                      className={`px-2.5 py-1 rounded-lg capitalize transition font-medium ${
                        logoPreviewTab === tab ? 'bg-cyan-500 text-black font-bold' : 'text-slate-400 hover:text-white'
                      }`}
                    >
                      {tab}
                    </button>
                  ))}
                </div>
              </div>

              {/* Interactive Preview Container */}
              <div className="p-5 rounded-2xl bg-black border border-slate-800 overflow-hidden min-h-[300px] flex items-center justify-center">
                {/* Header Preview */}
                {logoPreviewTab === 'header' && (
                  <div className="w-full bg-[#090b10] p-4 rounded-xl border border-slate-800 flex items-center justify-between">
                    <div className="flex items-center gap-2.5">
                      {siteSettings?.brand?.logoUrl ? (
                        <img src={siteSettings.brand.logoUrl} alt="Logo" className="h-8 max-w-[120px] object-contain" />
                      ) : (
                        <div className="w-8 h-8 rounded-lg bg-cyan-600 flex items-center justify-center font-bold text-white">
                          B
                        </div>
                      )}
                      <div>
                        <span className="font-bold text-white text-sm" style={{ color: editorPrimaryAccent }}>
                          {editorSiteName}
                        </span>
                        <p className="text-[9px] text-slate-400 font-mono">{editorTagline}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-slate-400">
                      <span className="px-2 py-1 rounded-lg bg-slate-900">Explore</span>
                      <span className="px-2 py-1 rounded-lg bg-cyan-600 text-white font-bold">Upload</span>
                    </div>
                  </div>
                )}

                {/* Sidebar Preview */}
                {logoPreviewTab === 'sidebar' && (
                  <div className="w-56 bg-[#090b10] p-4 rounded-xl border border-slate-800 space-y-4">
                    <div className="flex items-center gap-2">
                      {siteSettings?.brand?.logoUrl ? (
                        <img src={siteSettings.brand.logoUrl} alt="Logo" className="w-6 h-6 object-contain" />
                      ) : (
                        <div className="w-6 h-6 rounded bg-cyan-600 text-[10px] font-bold text-white flex items-center justify-center">
                          B
                        </div>
                      )}
                      <span className="font-bold text-xs text-white truncate">{editorSiteName}</span>
                    </div>
                    <div className="space-y-1 text-xs text-slate-400">
                      <div className="p-2 rounded-lg bg-slate-900 text-cyan-300 font-semibold">Home Dashboard</div>
                      <div className="p-2 rounded-lg hover:bg-slate-900">Cloud Sync</div>
                      <div className="p-2 rounded-lg hover:bg-slate-900">JARVIS Command</div>
                    </div>
                  </div>
                )}

                {/* Login Page Preview */}
                {logoPreviewTab === 'login' && (
                  <div className="max-w-xs w-full bg-[#0c1017] p-6 rounded-2xl border border-slate-800 text-center space-y-3">
                    {siteSettings?.brand?.logoUrl ? (
                      <img src={siteSettings.brand.logoUrl} alt="Logo" className="w-12 h-12 mx-auto object-contain mb-1" />
                    ) : (
                      <div className="w-12 h-12 rounded-2xl bg-gradient-to-tr from-cyan-500 to-blue-600 mx-auto flex items-center justify-center font-bold text-xl text-white">
                        B
                      </div>
                    )}
                    <h4 className="text-sm font-bold text-white">Welcome to {editorSiteName}</h4>
                    <p className="text-[10px] text-slate-400">{editorTagline}</p>
                    <div className="py-2 px-3 rounded-xl bg-white text-black font-bold text-xs">
                      Sign In with Google
                    </div>
                  </div>
                )}

                {/* Footer Preview */}
                {logoPreviewTab === 'footer' && (
                  <div className="w-full bg-[#090b10] p-4 rounded-xl border border-slate-800 flex items-center justify-between text-xs text-slate-400">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-white">{editorSiteName}</span>
                      <span>—</span>
                      <span className="text-[11px]">{editorTagline}</span>
                    </div>
                    <span className="text-[10px] font-mono text-slate-500">{editorFooterText}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* SECTION F: LIVE WEBSITE EDITOR                                 */}
      {/* ============================================================== */}
      {activeTab === 'live_editor' && (
        <div className="space-y-6">
          <div className="p-6 rounded-3xl glass-panel-glow border border-slate-800 space-y-6 text-xs">
            <div>
              <h3 className="text-base font-bold text-white">Live Website Customization</h3>
              <p className="text-slate-400 text-[11px]">Safe visual editing with instant draft saving, rollback, and audit logs.</p>
            </div>

            {/* Homepage Headings */}
            <div className="space-y-4">
              <h4 className="font-bold text-cyan-400 uppercase tracking-wider text-[11px]">Homepage Content</h4>
              <div>
                <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                  Hero Headline
                </label>
                <input
                  type="text"
                  value={editorHeroHeading}
                  onChange={(e) => setEditorHeroHeading(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white text-sm font-bold"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                  Hero Subtitle Description
                </label>
                <textarea
                  rows={2}
                  value={editorHeroSubtitle}
                  onChange={(e) => setEditorHeroSubtitle(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                  Footer Copyright &amp; Notice
                </label>
                <input
                  type="text"
                  value={editorFooterText}
                  onChange={(e) => setEditorFooterText(e.target.value)}
                  className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
                />
              </div>
            </div>

            {/* Announcement Banner & Maintenance Mode */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-4 border-t border-slate-800">
              {/* Announcement Banner */}
              <div className="p-4 rounded-2xl bg-slate-900/80 border border-slate-800 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white flex items-center gap-1.5">
                    <Megaphone className="w-4 h-4 text-cyan-400" />
                    <span>Global Announcement Banner</span>
                  </span>
                  <input
                    type="checkbox"
                    checked={editorAnnouncementActive}
                    onChange={(e) => setEditorAnnouncementActive(e.target.checked)}
                    className="w-4 h-4 rounded text-cyan-500 bg-slate-950 border-slate-700"
                  />
                </div>
                <input
                  type="text"
                  placeholder="Banner Title (e.g. Scheduled Engine Upgrade)"
                  value={editorAnnouncementTitle}
                  onChange={(e) => setEditorAnnouncementTitle(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-white"
                />
                <textarea
                  rows={2}
                  placeholder="Announcement body text..."
                  value={editorAnnouncementText}
                  onChange={(e) => setEditorAnnouncementText(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-white"
                />
              </div>

              {/* Maintenance Mode */}
              <div className="p-4 rounded-2xl bg-amber-950/20 border border-amber-800/40 space-y-3">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-amber-300 flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-amber-400" />
                    <span>Maintenance Mode</span>
                  </span>
                  <input
                    type="checkbox"
                    checked={editorMaintenanceEnabled}
                    onChange={(e) => setEditorMaintenanceEnabled(e.target.checked)}
                    className="w-4 h-4 rounded text-amber-500 bg-slate-950 border-slate-700"
                  />
                </div>
                <p className="text-[11px] text-amber-200/80">
                  When enabled, non-owner visitors are gated with a maintenance message.
                </p>
                <textarea
                  rows={2}
                  value={editorMaintenanceMsg}
                  onChange={(e) => setEditorMaintenanceMsg(e.target.value)}
                  className="w-full px-3 py-1.5 rounded-xl bg-slate-950 border border-slate-700 text-white"
                />
              </div>
            </div>

            {/* Public SEO Titles & Description */}
            <div className="space-y-3 pt-4 border-t border-slate-800">
              <h4 className="font-bold text-cyan-400 uppercase tracking-wider text-[11px]">Public SEO &amp; Meta Tags</h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                    HTML &amp; OpenGraph Title
                  </label>
                  <input
                    type="text"
                    value={editorSeoTitle}
                    onChange={(e) => setEditorSeoTitle(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
                  />
                </div>

                <div>
                  <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                    Meta Description
                  </label>
                  <input
                    type="text"
                    value={editorSeoDescription}
                    onChange={(e) => setEditorSeoDescription(e.target.value)}
                    className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Saved Revisions & Rollback List (Requirement F.6) */}
          <div className="p-6 rounded-3xl glass-panel border border-slate-800 space-y-4 text-xs">
            <h3 className="font-bold text-white text-sm flex items-center gap-2">
              <History className="w-4 h-4 text-cyan-400" />
              <span>Saved Revisions &amp; Rollback History (Last 30 Revisions)</span>
            </h3>
            {revisions.length === 0 ? (
              <p className="text-slate-500 py-4 text-center">No published revisions yet. Publish your first change to create revision snapshots.</p>
            ) : (
              <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                {revisions.map((rev) => (
                  <div key={rev.id} className="p-3 rounded-xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
                    <div>
                      <span className="font-bold text-white">{rev.summary}</span>
                      <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                        By {rev.authorEmail} &bull; {formatRelativeTime(rev.timestamp)}
                      </div>
                    </div>
                    <button
                      onClick={() => handleRollback(rev.id)}
                      className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-cyan-300 font-semibold text-xs flex items-center gap-1 transition"
                    >
                      <RotateCcw className="w-3 h-3" />
                      <span>Rollback</span>
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* SECTION B & C: COUNTDOWN & PASSWORD PROTECTION                 */}
      {/* ============================================================== */}
      {activeTab === 'countdown_protection' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 text-xs">
          {/* Settings Column (7 cols) */}
          <div className="lg:col-span-7 space-y-6">
            <div className="p-6 rounded-3xl glass-panel-glow border border-slate-800 space-y-5">
              <div className="flex items-center gap-2">
                <Clock className="w-5 h-5 text-cyan-400" />
                <div>
                  <h3 className="text-base font-bold text-white">Owner-Controlled Download Countdown</h3>
                  <p className="text-slate-400 text-[11px]">Enforced server-side with verified countdown session tickets</p>
                </div>
              </div>

              {/* Countdown Enable Toggle */}
              <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800">
                <div>
                  <span className="font-bold text-white block">Enable Download Countdown</span>
                  <span className="text-[11px] text-slate-400">Visitors must wait required time before download unlocks</span>
                </div>
                <input
                  type="checkbox"
                  checked={countdownEnabled}
                  onChange={(e) => setCountdownEnabled(e.target.checked)}
                  className="w-5 h-5 rounded text-cyan-500 bg-slate-950 border-slate-700"
                />
              </div>

              {/* Countdown Presets */}
              <div className="space-y-2">
                <label className="block text-slate-400 font-semibold uppercase text-[10px]">
                  Default Duration
                </label>
                <div className="grid grid-cols-4 gap-2">
                  {[
                    { val: 0, label: 'Disabled' },
                    { val: 10, label: '10 Seconds' },
                    { val: 15, label: '15 Seconds' },
                    { val: 20, label: '20 Seconds' },
                  ].map(item => (
                    <button
                      key={item.val}
                      type="button"
                      onClick={() => setCountdownSeconds(item.val)}
                      className={`p-2.5 rounded-xl border text-center transition font-semibold ${
                        countdownSeconds === item.val
                          ? 'border-cyan-400 bg-cyan-950/40 text-cyan-300 font-bold'
                          : 'border-slate-800 bg-slate-900 text-slate-400 hover:text-white'
                      }`}
                    >
                      {item.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Policy: All vs Selected */}
              <div className="space-y-2">
                <label className="block text-slate-400 font-semibold uppercase text-[10px]">
                  Application Scope
                </label>
                <div className="grid grid-cols-2 gap-2">
                  <button
                    type="button"
                    onClick={() => setCountdownPolicy('all')}
                    className={`p-3 rounded-xl border text-left transition ${
                      countdownPolicy === 'all'
                        ? 'border-cyan-400 bg-cyan-950/40 text-cyan-300 font-bold'
                        : 'border-slate-800 bg-slate-900 text-slate-400'
                    }`}
                  >
                    <span className="block font-bold">All Eligible Downloads</span>
                    <span className="text-[10px] text-slate-400">Apply countdown to all public releases</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setCountdownPolicy('selected')}
                    className={`p-3 rounded-xl border text-left transition ${
                      countdownPolicy === 'selected'
                        ? 'border-cyan-400 bg-cyan-950/40 text-cyan-300 font-bold'
                        : 'border-slate-800 bg-slate-900 text-slate-400'
                    }`}
                  >
                    <span className="block font-bold">Selected Files Only</span>
                    <span className="text-[10px] text-slate-400">Only files with countdown enabled</span>
                  </button>
                </div>
              </div>

              {/* Per-File Override Toggle */}
              <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800">
                <div>
                  <span className="font-bold text-white block">Allow Per-File Author Overrides</span>
                  <span className="text-[11px] text-slate-400">Creators can set custom duration or disable countdown on their uploads</span>
                </div>
                <input
                  type="checkbox"
                  checked={allowCountdownOverride}
                  onChange={(e) => setAllowCountdownOverride(e.target.checked)}
                  className="w-4 h-4 rounded text-cyan-500 bg-slate-950 border-slate-700"
                />
              </div>
            </div>
          </div>

          {/* Preview & Testing Column (5 cols - Requirement B.9) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="p-6 rounded-3xl glass-panel border border-cyan-500/30 space-y-4">
              <h3 className="font-bold text-white text-sm flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <span>Countdown Simulator &amp; Tester (Requirement B.9)</span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Test the countdown access flow before publishing changes to all visitors.
              </p>

              <div className="p-5 rounded-2xl bg-black border border-slate-800 text-center space-y-3">
                <div className="text-xl font-black font-mono text-cyan-400">
                  {testCountdownActive ? `${testCountdownVal}s Remaining` : `${countdownSeconds}s Configured`}
                </div>
                <div className="w-full h-2 rounded-full bg-slate-900 overflow-hidden">
                  <div
                    className="h-full bg-cyan-400 transition-all duration-1000"
                    style={{ width: `${testCountdownActive ? (testCountdownVal / (countdownSeconds || 1)) * 100 : 100}%` }}
                  />
                </div>
                <p className="text-[11px] text-slate-400">
                  {testCountdownActive
                    ? 'Simulating visitor wait: download action disabled'
                    : 'Download action active after countdown completes'}
                </p>
                <button
                  type="button"
                  onClick={handleStartCountdownTest}
                  disabled={testCountdownActive}
                  className="px-4 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold text-xs"
                >
                  {testCountdownActive ? 'Testing in progress...' : 'Start Test Countdown'}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* SECTION G: MONETIZATION & GOOGLE ADSENSE                       */}
      {/* ============================================================== */}
      {activeTab === 'adsense' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 text-xs">
          <div className="lg:col-span-7 space-y-6">
            <div className="p-6 rounded-3xl glass-panel-glow border border-slate-800 space-y-5">
              <div className="flex items-center gap-2">
                <DollarSign className="w-5 h-5 text-amber-400" />
                <div>
                  <h3 className="text-base font-bold text-white">Google AdSense Configuration</h3>
                  <p className="text-slate-400 text-[11px]">Official publisher integration &amp; approved ad slots</p>
                </div>
              </div>

              {/* Publisher ID Input with Format Validation */}
              <div>
                <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                  Google AdSense Publisher ID
                </label>
                <input
                  type="text"
                  value={adPublisherId}
                  onChange={(e) => setAdPublisherId(e.target.value.trim())}
                  placeholder="ca-pub-1234567890123456"
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-700 text-white font-mono"
                />
                <p className="text-[10px] text-slate-500 mt-1">
                  Format must strictly match <code className="text-cyan-400 font-mono">ca-pub-XXXXXXXXXXXXXXXX</code> (16 digits).
                </p>
              </div>

              {/* Enable / Disable AdSense */}
              <div className="flex items-center justify-between p-3.5 rounded-2xl bg-slate-900/80 border border-slate-800">
                <div>
                  <span className="font-bold text-white block">Enable Public Advertisements</span>
                  <span className="text-[11px] text-slate-400">Display verified ad units on approved public placements</span>
                </div>
                <input
                  type="checkbox"
                  checked={adEnabled}
                  onChange={(e) => setAdEnabled(e.target.checked)}
                  className="w-5 h-5 rounded text-cyan-500 bg-slate-950 border-slate-700"
                />
              </div>

              {/* Ad Placements Toggles */}
              <div className="space-y-2 pt-2">
                <span className="font-bold text-white uppercase text-[11px] tracking-wider block">
                  Approved Ad Placement Controls
                </span>
                <div className="space-y-2">
                  {[
                    { key: 'headerLeaderboard' as const, label: 'Header Leaderboard (728x90)', desc: 'Top of Explore & Home views' },
                    { key: 'downloadPageBanner' as const, label: 'Download Page Sponsor Banner', desc: 'Prominently placed above countdown/download' },
                    { key: 'sidebarRectangle' as const, label: 'Sidebar Medium Rectangle (300x250)', desc: 'Side navigation rail on desktop' },
                    { key: 'reelsInFeed' as const, label: 'Creator Reels In-Feed Sponsor', desc: 'Embedded between community proof videos' },
                  ].map(p => (
                    <div key={p.key} className="flex items-center justify-between p-3 rounded-xl bg-slate-900/60 border border-slate-800">
                      <div>
                        <span className="font-semibold text-white block">{p.label}</span>
                        <span className="text-[10px] text-slate-400">{p.desc}</span>
                      </div>
                      <input
                        type="checkbox"
                        checked={adPlacements[p.key]}
                        onChange={(e) => setAdPlacements({ ...adPlacements, [p.key]: e.target.checked })}
                        className="w-4 h-4 rounded text-cyan-500 bg-slate-950 border-slate-700"
                      />
                    </div>
                  ))}
                </div>
              </div>

              {/* ads.txt guidance */}
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-white">ads.txt Automated Route</span>
                  <button
                    onClick={() => {
                      const txt = `google.com, ${adPublisherId.replace(/^ca-/, '') || 'pub-0000000000000000'}, DIRECT, f08c47fec0942fa0`;
                      navigator.clipboard.writeText(txt);
                      setCopiedAdsTxt(true);
                      setTimeout(() => setCopiedAdsTxt(false), 2500);
                    }}
                    className="text-[11px] font-mono text-cyan-400 flex items-center gap-1"
                  >
                    {copiedAdsTxt ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                    <span>{copiedAdsTxt ? 'Copied' : 'Copy Entry'}</span>
                  </button>
                </div>
                <p className="text-[11px] text-slate-400 leading-relaxed font-mono bg-black/60 p-2.5 rounded-xl border border-slate-800">
                  google.com, {adPublisherId ? adPublisherId.replace(/^ca-/, '') : 'pub-XXXXXXXXXXXXXXXX'}, DIRECT, f08c47fec0942fa0
                </p>
                <p className="text-[10px] text-slate-500">
                  Live at <code className="text-cyan-400">/ads.txt</code> on bxbcloud.cloud for automated Google crawler verification.
                </p>
              </div>
            </div>
          </div>

          {/* Ad Preview (Non-clickable clearly labeled) */}
          <div className="lg:col-span-5 space-y-4">
            <div className="p-6 rounded-3xl glass-panel border border-slate-800 space-y-3">
              <h3 className="font-bold text-white text-sm">Ad Placement Preview</h3>
              <p className="text-[11px] text-slate-400">
                Non-clickable placeholders clearly distinguished from real ads (Requirement G).
              </p>
              <AdSenseUnit placement="downloadPageBanner" previewMode={true} />
              <AdSenseUnit placement="headerLeaderboard" previewMode={true} />
            </div>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* SECTION H: SOURCE CODE ZIP EXPORT                              */}
      {/* ============================================================== */}
      {activeTab === 'source_export' && (
        <div className="max-w-2xl mx-auto space-y-6 text-xs">
          <div className="p-6 rounded-3xl glass-panel-glow border border-cyan-500/30 space-y-4 text-center">
            <div className="w-16 h-16 rounded-2xl bg-cyan-500/20 border border-cyan-500/40 flex items-center justify-center text-cyan-400 mx-auto">
              <FileCode className="w-8 h-8" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white">Authorized Source Code ZIP Export</h3>
              <p className="text-slate-400 text-xs mt-1 max-w-md mx-auto">
                Generate and download a clean, verified ZIP archive containing all application source files, manifest, and Apache-2.0 license.
              </p>
            </div>

            <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 text-left space-y-2 font-mono text-[11px]">
              <div className="text-emerald-400 font-bold">Included in Archive:</div>
              <ul className="text-slate-300 list-disc pl-4 space-y-0.5">
                <li>src/ (All components, services, context, views, utils)</li>
                <li>server.ts (Backend Express Engine)</li>
                <li>package.json, tsconfig.json, vite.config.ts</li>
                <li>manifest.json &amp; LICENSE.txt</li>
              </ul>
              <div className="text-amber-400 font-bold pt-2">Exclusions Guard:</div>
              <p className="text-slate-400 text-[10px]">
                Secrets (.env), raw uploaded user binaries, private sessions, and node_modules are strictly stripped.
              </p>
            </div>

            <a
              href={`/api/owner/export-source?callerEmail=${encodeURIComponent(user?.email || '')}`}
              download
              className="w-full py-3.5 px-6 rounded-2xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 font-bold text-white inline-flex items-center justify-center gap-2 transition glow-btn text-xs"
            >
              <Download className="w-4 h-4" />
              <span>Download Authorized Source ZIP</span>
            </a>
          </div>
        </div>
      )}

      {/* ============================================================== */}
      {/* SECTION I: REAL LIVE DIAGNOSTICS                               */}
      {/* ============================================================== */}
      {activeTab === 'diagnostics' && (
        <div className="space-y-6 text-xs">
          <div className="flex items-center justify-between">
            <h3 className="font-bold text-white text-base">Live Node &amp; Storage Diagnostics (Section I)</h3>
            <button
              onClick={loadDiagnosticsData}
              className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 border border-slate-700 text-slate-300 flex items-center gap-1.5"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>Refresh Metrics</span>
            </button>
          </div>

          {loadingDiag || !diagnostics ? (
            <div className="py-12 text-center text-slate-400"><Loader2 className="w-6 h-6 animate-spin mx-auto text-cyan-400" /></div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-400 uppercase font-mono">Process Memory (RSS)</span>
                <p className="text-xl font-bold font-mono text-cyan-400">{diagnostics.memory.rssMb} MB</p>
                <p className="text-[10px] text-slate-500">Heap: {diagnostics.memory.heapUsedMb} MB / {diagnostics.memory.heapTotalMb} MB</p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-400 uppercase font-mono">Total Uploads Storage</span>
                <p className="text-xl font-bold font-mono text-emerald-400">{formatBytes(diagnostics.storage.uploadsBytes)}</p>
                <p className="text-[10px] text-slate-500">{diagnostics.storage.totalFilesCount} binary files on disk</p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-400 uppercase font-mono">Active 12GB Chunk Sessions</span>
                <p className="text-xl font-bold font-mono text-purple-400">{diagnostics.chunkSessions}</p>
                <p className="text-[10px] text-slate-500">{formatBytes(diagnostics.storage.chunksBytes)} staging in RAM/disk</p>
              </div>

              <div className="p-4 rounded-2xl bg-slate-900 border border-slate-800 space-y-1">
                <span className="text-[10px] text-slate-400 uppercase font-mono">Total Downloads Served</span>
                <p className="text-xl font-bold font-mono text-amber-400">{diagnostics.storage.totalDownloads}</p>
                <p className="text-[10px] text-slate-500">Uptime: {Math.floor(diagnostics.uptimeSeconds / 60)} minutes</p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* ============================================================== */}
      {/* OTHER TABS: VISIT NEW, OWNERS, REPORTS (Preserved Seamlessly)    */}
      {/* ============================================================== */}
      {activeTab === 'visit_new' && (
        <div className="space-y-4 text-xs">
          <div className="flex items-center justify-between p-4 rounded-2xl bg-slate-900 border border-slate-800">
            <div>
              <h3 className="font-bold text-white text-sm">Visit New Creator Stream</h3>
              <p className="text-slate-400 text-[11px]">Real-time sign-in history &amp; user management</p>
            </div>
            <div className="flex gap-2">
              {(['all', 'first_time', 'returning', 'suspended'] as const).map(f => (
                <button
                  key={f}
                  onClick={() => setUserFilter(f)}
                  className={`px-3 py-1 rounded-lg capitalize transition ${
                    userFilter === f ? 'bg-cyan-500 text-black font-bold' : 'text-slate-400 bg-slate-950'
                  }`}
                >
                  {f.replace('_', ' ')}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            {visitUsers.map(u => (
              <div key={u.uid} className="p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800 flex items-center justify-between">
                <div>
                  <span className="font-bold text-white">@{u.username}</span> ({u.email || u.uid.substring(0, 8)})
                  <div className="text-[10px] text-slate-400">Logins: {u.loginCount} &bull; Last: {formatRelativeTime(u.lastLoginAt)}</div>
                </div>
                <button
                  onClick={() => handleToggleAccountStatus(u.uid, u.accountStatus)}
                  className={`px-3 py-1 rounded-lg text-[11px] font-semibold ${
                    u.accountStatus === 'suspended' ? 'bg-emerald-600 text-white' : 'bg-red-950/40 text-red-300 border border-red-800'
                  }`}
                >
                  {u.accountStatus === 'suspended' ? 'Restore Account' : 'Suspend Account'}
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Publish Confirmation Modal (Requirement F.5) */}
      {showPublishModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in text-xs">
          <div className="w-full max-w-md glass-panel-glow rounded-3xl p-6 border border-cyan-500/40 space-y-4">
            <h3 className="text-base font-bold text-white">Confirm Live Website Publication</h3>
            <p className="text-slate-300">
              Publishing will update the live site configuration for all visitors. A new revision snapshot will be created in the audit log.
            </p>
            <div>
              <label className="block text-slate-400 font-semibold uppercase text-[10px] mb-1">
                Publication Summary / Changelog Note
              </label>
              <input
                type="text"
                value={publishSummary}
                onChange={(e) => setPublishSummary(e.target.value)}
                placeholder="e.g. Updated brand logo and enabled 15s download countdown"
                className="w-full px-3 py-2 rounded-xl bg-slate-950 border border-slate-700 text-white"
              />
            </div>
            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowPublishModal(false)}
                className="px-4 py-2 rounded-xl bg-slate-800 text-slate-300"
              >
                Cancel
              </button>
              <button
                type="button"
                onClick={() => handleSaveSettings(true)}
                disabled={savingSettings}
                className="px-5 py-2 rounded-xl bg-cyan-600 hover:bg-cyan-500 text-white font-bold"
              >
                {savingSettings ? 'Publishing...' : 'Confirm & Publish'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
