import React, { useState, useMemo, useEffect } from 'react';
import { 
  Sparkles, 
  Search, 
  Sliders, 
  CheckCircle2, 
  XCircle, 
  Download, 
  Upload, 
  RefreshCw, 
  Zap, 
  Shield, 
  HardDrive, 
  Cloud, 
  Bot, 
  DollarSign, 
  Film, 
  Smartphone, 
  Pickaxe, 
  Palette, 
  Crown,
  ChevronLeft,
  ChevronRight,
  Filter,
  Check,
  RotateCcw,
  Globe
} from 'lucide-react';
import { 
  get1000MultiverseOptions, 
  save1000OptionsState, 
  MultiverseOptionItem 
} from '../services/multiverse1000Options';

interface Multiverse1000ViewProps {
  onNavigate: (view: string, param?: string) => void;
}

export const Multiverse1000View: React.FC<Multiverse1000ViewProps> = ({ onNavigate }) => {
  const [options, setOptions] = useState<MultiverseOptionItem[]>(() => get1000MultiverseOptions());
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [tierFilter, setTierFilter] = useState<'all' | 'free' | 'pro' | 'god_mode'>('all');
  const [statusFilter, setStatusFilter] = useState<'all' | 'enabled' | 'disabled'>('all');
  const [currentPage, setCurrentPage] = useState<number>(1);
  const pageSize = 40; // 40 items per page for silky smooth rendering of 1,000 items

  const [notification, setNotification] = useState<string | null>(null);

  // Sync to localStorage
  const handleToggle = (id: string) => {
    setOptions(prev => {
      const next = prev.map(item => item.id === id ? { ...item, enabled: !item.enabled } : item);
      const stateMap: Record<string, boolean> = {};
      for (const item of next) stateMap[item.id] = item.enabled;
      save1000OptionsState(stateMap);
      return next;
    });
  };

  const handleBulkSetCategory = (category: string, enable: boolean) => {
    setOptions(prev => {
      const next = prev.map(item => {
        if (category === 'all' || item.category === category) {
          return { ...item, enabled: enable };
        }
        return item;
      });
      const stateMap: Record<string, boolean> = {};
      for (const item of next) stateMap[item.id] = item.enabled;
      save1000OptionsState(stateMap);
      return next;
    });
    setNotification(enable ? `Enabled all options in ${category}` : `Disabled all options in ${category}`);
    setTimeout(() => setNotification(null), 3000);
  };

  const handlePreset = (presetName: string) => {
    setOptions(prev => {
      const next = prev.map(item => {
        if (presetName === 'god_mode') return { ...item, enabled: true };
        if (presetName === 'performance') {
          return { ...item, enabled: item.category === 'storage' || item.category === 'cloud_sync' };
        }
        if (presetName === 'security') {
          return { ...item, enabled: item.category === 'security' || item.category === 'jarvis_ai' };
        }
        if (presetName === 'gaming') {
          return { ...item, enabled: item.category === 'minecraft_lab' || item.category === 'apk_sandbox' || item.category === 'media_studio' };
        }
        if (presetName === 'reset') return { ...item, enabled: true };
        return item;
      });
      const stateMap: Record<string, boolean> = {};
      for (const item of next) stateMap[item.id] = item.enabled;
      save1000OptionsState(stateMap);
      return next;
    });
    setNotification(`Applied preset profile: ${presetName.toUpperCase()}`);
    setTimeout(() => setNotification(null), 3000);
  };

  const handleExportConfig = () => {
    const stateMap: Record<string, boolean> = {};
    for (const item of options) stateMap[item.id] = item.enabled;
    const blob = new Blob([JSON.stringify(stateMap, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bxbfile-1000-options-config-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    setNotification('Config JSON downloaded successfully!');
    setTimeout(() => setNotification(null), 3000);
  };

  const handleImportConfig = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const reader = new FileReader();
      reader.onload = (event) => {
        try {
          const parsed = JSON.parse(event.target?.result as string);
          setOptions(prev => {
            const next = prev.map(item => ({
              ...item,
              enabled: parsed[item.id] !== undefined ? Boolean(parsed[item.id]) : item.enabled
            }));
            save1000OptionsState(parsed);
            return next;
          });
          setNotification('Imported 1000 options profile successfully!');
          setTimeout(() => setNotification(null), 3000);
        } catch {
          setNotification('Invalid JSON configuration file');
          setTimeout(() => setNotification(null), 3000);
        }
      };
      reader.readAsText(e.target.files[0]);
    }
  };

  const categories = [
    { id: 'all', label: 'All 1,000 Options', icon: Sparkles, count: 1000 },
    { id: 'storage', label: '12 GB Storage', icon: HardDrive, count: 100 },
    { id: 'cloud_sync', label: 'Cloud Sync', icon: Cloud, count: 100 },
    { id: 'jarvis_ai', label: 'JARVIS AI', icon: Bot, count: 100 },
    { id: 'security', label: 'Security & Vault', icon: Shield, count: 100 },
    { id: 'monetization', label: 'Monetization', icon: DollarSign, count: 100 },
    { id: 'media_studio', label: 'Media Studio', icon: Film, count: 100 },
    { id: 'apk_sandbox', label: 'APK Sandbox', icon: Smartphone, count: 100 },
    { id: 'minecraft_lab', label: 'Minecraft Lab', icon: Pickaxe, count: 100 },
    { id: 'cyberpunk_ui', label: 'Cyberpunk HUD', icon: Palette, count: 100 },
    { id: 'god_mode', label: 'God-Mode Kernel', icon: Crown, count: 100 },
  ];

  const filteredOptions = useMemo(() => {
    return options.filter(item => {
      const matchCat = selectedCategory === 'all' || item.category === selectedCategory;
      const matchTier = tierFilter === 'all' || item.tier === tierFilter;
      const matchStatus = statusFilter === 'all' 
        ? true 
        : statusFilter === 'enabled' ? item.enabled : !item.enabled;
      
      const q = searchQuery.toLowerCase().trim();
      const matchQuery = !q || 
        item.id.toLowerCase().includes(q) || 
        item.title.toLowerCase().includes(q) || 
        item.description.toLowerCase().includes(q) ||
        item.categoryTitle.toLowerCase().includes(q) ||
        item.tags.some(t => t.toLowerCase().includes(q));

      return matchCat && matchTier && matchStatus && matchQuery;
    });
  }, [options, selectedCategory, tierFilter, statusFilter, searchQuery]);

  const totalPages = Math.max(1, Math.ceil(filteredOptions.length / pageSize));
  const paginatedList = useMemo(() => {
    const start = (currentPage - 1) * pageSize;
    return filteredOptions.slice(start, start + pageSize);
  }, [filteredOptions, currentPage]);

  const enabledCount = useMemo(() => options.filter(o => o.enabled).length, [options]);

  return (
    <div className="min-h-screen text-slate-100 py-6 px-3 sm:px-6 max-w-7xl mx-auto space-y-6">
      {/* Top Banner & Header */}
      <div className="glass-panel-glow rounded-3xl p-6 sm:p-8 relative overflow-hidden shadow-2xl border border-cyan-500/30">
        <div className="absolute top-0 right-0 w-96 h-96 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div>
            <div className="flex flex-wrap items-center gap-2 mb-2">
              <span className="px-3 py-1 rounded-full bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 text-xs font-mono font-bold uppercase tracking-wider flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5" />
                1,000 Multiverse Options Active
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-mono">
                1,000 Verified Directives
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-purple-500/20 text-purple-300 border border-purple-500/30 text-xs font-mono">
                Domain: bxbfile.bxb
              </span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-black text-white tracking-wide">
              Multiverse 1,000 Mega Options Center
            </h1>
            <p className="text-sm text-slate-300 mt-1 max-w-2xl">
              1,000 searchable, interactive configuration switches controlling storage, cloud sync, JARVIS AI, APK security, and god-mode architecture.
            </p>
          </div>

          {/* Quick HUD Metrics */}
          <div className="flex items-center gap-3 bg-slate-900/80 p-3 rounded-2xl border border-slate-800 shrink-0">
            <div className="text-center px-3 border-r border-slate-800">
              <p className="text-[10px] text-slate-400 font-mono uppercase">Total Loaded</p>
              <p className="text-xl font-black text-white font-mono">1,000</p>
            </div>
            <div className="text-center px-3 border-r border-slate-800">
              <p className="text-[10px] text-emerald-400 font-mono uppercase">Active</p>
              <p className="text-xl font-black text-emerald-400 font-mono">{enabledCount}</p>
            </div>
            <div className="text-center px-3">
              <p className="text-[10px] text-slate-400 font-mono uppercase">Filtered</p>
              <p className="text-xl font-black text-cyan-400 font-mono">{filteredOptions.length}</p>
            </div>
          </div>
        </div>

        {/* Notification pill */}
        {notification && (
          <div className="mt-4 p-2.5 rounded-xl bg-cyan-500/20 border border-cyan-500/40 text-cyan-200 text-xs flex items-center gap-2 animate-fade-in font-medium">
            <CheckCircle2 className="w-4 h-4 shrink-0 text-cyan-300" />
            <span>{notification}</span>
          </div>
        )}
      </div>

      {/* Preset Profiles Bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-4 glass-panel rounded-2xl border border-slate-800">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-xs font-bold text-slate-400 uppercase tracking-wider mr-2">Presets:</span>
          <button
            onClick={() => handlePreset('god_mode')}
            className="px-3 py-1.5 rounded-xl bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 text-xs font-semibold flex items-center gap-1.5 transition"
          >
            <Crown className="w-3.5 h-3.5" />
            <span>God-Mode (Enable All 1000)</span>
          </button>
          <button
            onClick={() => handlePreset('performance')}
            className="px-3 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/30 text-xs font-semibold flex items-center gap-1.5 transition"
          >
            <Zap className="w-3.5 h-3.5" />
            <span>Ultra Upload &amp; Sync</span>
          </button>
          <button
            onClick={() => handlePreset('security')}
            className="px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/30 text-xs font-semibold flex items-center gap-1.5 transition"
          >
            <Shield className="w-3.5 h-3.5" />
            <span>Fortress Privacy</span>
          </button>
          <button
            onClick={() => handlePreset('gaming')}
            className="px-3 py-1.5 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/30 text-xs font-semibold flex items-center gap-1.5 transition"
          >
            <Pickaxe className="w-3.5 h-3.5" />
            <span>Minecraft &amp; APKs</span>
          </button>
          <button
            onClick={() => handlePreset('reset')}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-semibold flex items-center gap-1.5 transition"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset All</span>
          </button>
        </div>

        {/* Config Export & Import */}
        <div className="flex items-center gap-2">
          <button
            onClick={handleExportConfig}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>Export JSON</span>
          </button>
          <label className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 border border-slate-700 text-xs font-semibold flex items-center gap-1.5 transition cursor-pointer">
            <Upload className="w-3.5 h-3.5 text-cyan-400" />
            <span>Import JSON</span>
            <input type="file" accept=".json" onChange={handleImportConfig} className="hidden" />
          </label>
        </div>
      </div>

      {/* Category Tabs (10 sectors x 100 options) */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin">
        {categories.map((cat) => {
          const Icon = cat.icon;
          const isSelected = selectedCategory === cat.id;
          return (
            <button
              key={cat.id}
              onClick={() => {
                setSelectedCategory(cat.id);
                setCurrentPage(1);
              }}
              className={`px-3.5 py-2 rounded-2xl text-xs font-bold shrink-0 transition flex items-center gap-2 border ${
                isSelected
                  ? 'bg-cyan-500 text-slate-950 border-cyan-400 shadow-lg shadow-cyan-500/20'
                  : 'bg-slate-900/80 text-slate-300 border-slate-800 hover:border-slate-700 hover:text-white'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{cat.label}</span>
              <span className={`px-1.5 py-0.2 rounded-full text-[10px] font-mono ${isSelected ? 'bg-slate-950/30 text-slate-950' : 'bg-slate-800 text-slate-400'}`}>
                {cat.count}
              </span>
            </button>
          );
        })}
      </div>

      {/* Search, Filter & Bulk Actions Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 glass-panel rounded-2xl border border-slate-800">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-500 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
            placeholder="Search all 1,000 options (e.g. SHA-256, chunk, hindi)..."
            className="w-full pl-9 pr-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500"
          />
        </div>

        <div className="flex flex-wrap items-center gap-2 w-full sm:w-auto justify-end">
          {/* Status filter */}
          <select
            value={statusFilter}
            onChange={(e) => {
              setStatusFilter(e.target.value as any);
              setCurrentPage(1);
            }}
            className="px-3 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs text-slate-300 focus:outline-none focus:border-cyan-500"
          >
            <option value="all">All States</option>
            <option value="enabled">Active Only</option>
            <option value="disabled">Disabled Only</option>
          </select>

          {/* Bulk actions */}
          <button
            onClick={() => handleBulkSetCategory(selectedCategory, true)}
            className="px-3 py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/40 text-xs font-semibold flex items-center gap-1.5 transition"
          >
            <CheckCircle2 className="w-3.5 h-3.5" />
            <span>Enable Category</span>
          </button>
          <button
            onClick={() => handleBulkSetCategory(selectedCategory, false)}
            className="px-3 py-2 rounded-xl bg-red-500/20 hover:bg-red-500/30 text-red-300 border border-red-500/40 text-xs font-semibold flex items-center gap-1.5 transition"
          >
            <XCircle className="w-3.5 h-3.5" />
            <span>Disable Category</span>
          </button>
        </div>
      </div>

      {/* Grid of Options */}
      {paginatedList.length === 0 ? (
        <div className="text-center py-16 glass-panel rounded-3xl border border-slate-800">
          <Sliders className="w-10 h-10 text-slate-600 mx-auto mb-3" />
          <h3 className="text-base font-bold text-slate-300">No Options Match Your Filter</h3>
          <p className="text-xs text-slate-500 mt-1">Try resetting search keywords or changing category filters</p>
          <button
            onClick={() => {
              setSearchQuery('');
              setSelectedCategory('all');
              setStatusFilter('all');
            }}
            className="mt-4 px-4 py-2 rounded-xl bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 text-xs font-semibold hover:bg-cyan-500/30 transition"
          >
            Reset Filters
          </button>
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3.5">
          {paginatedList.map((item) => (
            <div
              key={item.id}
              onClick={() => handleToggle(item.id)}
              className={`p-4 rounded-2xl border transition-all cursor-pointer flex flex-col justify-between group ${
                item.enabled
                  ? 'bg-slate-900/90 border-cyan-500/40 hover:border-cyan-400 shadow-md shadow-cyan-500/5'
                  : 'bg-slate-950/60 border-slate-800/80 hover:border-slate-700 opacity-65'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-2">
                  <span className="font-mono text-[10px] font-bold text-cyan-400 bg-cyan-500/10 px-1.5 py-0.5 rounded border border-cyan-500/20">
                    {item.id}
                  </span>
                  <div className="flex items-center gap-1.5">
                    {item.tier === 'god_mode' && (
                      <span className="text-[9px] font-mono px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                        GOD
                      </span>
                    )}
                    <span className={`w-2.5 h-2.5 rounded-full ${item.enabled ? 'bg-emerald-400 shadow-sm shadow-emerald-400' : 'bg-slate-600'}`} />
                  </div>
                </div>

                <h4 className="text-xs font-bold text-white group-hover:text-cyan-300 transition-colors line-clamp-1">
                  {item.title}
                </h4>
                <p className="text-[10px] text-cyan-400/80 font-medium mt-0.5 line-clamp-1">
                  {item.titleHi}
                </p>
                <p className="text-[11px] text-slate-400 mt-1.5 line-clamp-2 leading-relaxed">
                  {item.description}
                </p>
              </div>

              <div className="mt-3 pt-2.5 border-t border-slate-800/80 flex items-center justify-between text-[10px]">
                <span className="text-slate-500 font-mono">{item.categoryTitle.split(' ')[0]}</span>
                <span className={`font-semibold font-mono ${item.enabled ? 'text-emerald-400' : 'text-slate-500'}`}>
                  {item.enabled ? 'ACTIVE' : 'OFF'}
                </span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Pagination Footer */}
      {totalPages > 1 && (
        <div className="flex items-center justify-between p-4 glass-panel rounded-2xl border border-slate-800">
          <p className="text-xs text-slate-400 font-mono">
            Showing {(currentPage - 1) * pageSize + 1} - {Math.min(currentPage * pageSize, filteredOptions.length)} of {filteredOptions.length} Options
          </p>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
              disabled={currentPage === 1}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 disabled:opacity-40 text-slate-300 hover:text-white"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <span className="text-xs font-mono font-bold text-white px-2">
              Page {currentPage} of {totalPages}
            </span>
            <button
              onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
              disabled={currentPage === totalPages}
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 disabled:opacity-40 text-slate-300 hover:text-white"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
