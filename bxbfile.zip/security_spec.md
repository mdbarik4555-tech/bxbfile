# BXB Cloud Security Specification & Rules Architecture

## 1. Data Invariants
1. **User Identity Invariant**: A user document at `/users/{userId}` can only be created or modified by `request.auth.uid == userId`. Role cannot be self-escalated to 'admin'.
2. **Username Invariant**: A username reservation at `/usernames/{usernameNormalized}` must match the normalized form `^[a-z0-9_]{3,30}$` and can only be claimed if not existing and `uid == request.auth.uid`.
3. **File Ownership Invariant**: A file document at `/files/{fileId}` must have `ownerUid == request.auth.uid`. It cannot be updated or deleted by a non-owner, unless the user is an authorized admin.
4. **File Visibility Invariant**: A file document is readable by any visitor only if `visibility == 'public'` or `visibility == 'unlisted'` and `publicationStatus == 'published'`. If `visibility == 'private'`, it is strictly readable only by `request.auth.uid == resource.data.ownerUid` or admin.
5. **Download Count Invariant**: Client cannot arbitrarily rewrite file metadata fields during download event; counter increment is restricted.
6. **Media Attachment Invariant**: Subcollection `/files/{fileId}/media/{mediaId}` can only be modified by the parent file's owner (`ownerUid == request.auth.uid`).
7. **Report Invariant**: Any signed-in user can submit a report with `reporterUid == request.auth.uid`. Only admins can review or action reports.
8. **Admin Invariant**: Documents in `/admins/{adminUid}` cannot be created or modified by regular client users.

## 2. The Dirty Dozen Payloads (Targeting Rejection)
1. Impersonate File Owner on Create (`ownerUid: 'victim_123'` when signed in as `attacker_456`).
2. Privilege Escalation on User Profile (`role: 'admin'` or `isAdmin: true` during profile setup).
3. Shadow Field Injection on File Update (`{ title: 'New', ghostField: 'hacked' }`).
4. Modify Immutable CreatedAt on File Update (`createdAt: '2020-01-01'`).
5. Overwrite Another User's Claimed Username (`/usernames/admin` with attacker's UID).
6. Read Another User's Private File (`visibility: 'private'` accessed by unauthenticated or unrelated user).
7. Inject 1MB Junk String in Document ID or fields.
8. Delete Another User's Published File.
9. Modify Another User's Media Attachment in `/files/{fileId}/media/{mediaId}`.
10. Directly approve or resolve Abuse Reports without Admin role.
11. Write arbitrary admin entries into `/admins/{attackerUid}`.
12. Create a file with invalid visibility mode (e.g., `visibility: 'super-public'`).

## 3. Test Runner
Included in test suite and enforced by `firestore.rules`.
