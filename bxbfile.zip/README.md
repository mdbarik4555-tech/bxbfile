# bxbfile.bxb — Ultimate File, APK & Project Platform

bxbfile.bxb is a futuristic, full-stack online file hosting, Android APK distribution, creator publishing, and developer project sharing platform.

## Architecture

- **Frontend**: React 19, TypeScript, Tailwind CSS v4, Lucide Icons
- **Backend & Persistence**:
  - **Firebase Authentication**: Real Google Sign-In with atomic username claim reservation
  - **Cloud Firestore**: Metadata, category indexing, download counts, and abuse reporting
  - **Firebase Cloud Storage**: Resumable binary uploads with real byte tracking and direct downloads
  - **Security Rules**: Zero-Trust Attribute-Based Access Control (ABAC) with owner validation, immutable timestamps, and private file protections
  - **Cryptographic Verification**: Genuine browser-side Web Crypto API SHA-256 integrity calculation

## Core Features Implemented

1. **Google Sign-In & Onboarding**:
   - Google Authentication via Firebase Auth
   - Unique username reservation with collision protection against Firestore `usernames` collection
   - Terms of Service & Acceptable Use Policy agreement
2. **Resumable Cloud Storage Uploads**:
   - Native file picker and drag-and-drop zone
   - Real-time client-side cryptographic SHA-256 hash generation
   - Live progress indicator with bytes transferred and cancellation support
   - Multi-category support (Android APKs, Windows apps, Developer projects, Web applications, Games, Media, Documents)
3. **Unique Permanent File Pages (`/f/:id`)**:
   - Direct downloads that preserve filename and track download start metrics
   - Verified SHA-256 badge with one-click copy
   - Proof video / media attachments and screenshot previews
   - Installation instructions and release notes
   - Share modal with native Web Share API and QR code generation
   - Abuse reporting modal for malware and copyright violations
4. **Creator Discovery & Profiles (`/u/:username`)**:
   - Public creator profile pages with release archives and download stats
   - Global search by title, tags, description, and creator
   - Filtering by category and platform with sorting by newest, most downloaded, or alphabetical
5. **My Library Dashboard**:
   - Manage uploaded files with visibility controls: **Public**, **Unlisted**, **Private**
   - Live storage quota feedback against free tier limits
   - Metadata editing and atomic file deletion with cloud storage cleanup
6. **Isolated Web Sandbox**:
   - Zero-trust preview environment for HTML/JS web applications using sandboxed iframes
7. **Root Moderation Dashboard**:
   - Dedicated dashboard for platform admins (`md.barik4555@gmail.com`)
   - Abuse report review, file restriction, and system health status

## Verification & Tests

Run the test suite:
```bash
npx tsx tests/unit/validation.test.ts
npm run lint
npm run build
```
